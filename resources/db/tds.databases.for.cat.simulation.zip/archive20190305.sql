CREATE DATABASE  IF NOT EXISTS `archive` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `archive`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: archive
-- ------------------------------------------------------
-- Server version	5.7.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_dblatency`
--

DROP TABLE IF EXISTS `_dblatency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_dblatency` (
  `starttime` datetime(3) DEFAULT NULL,
  `difftime` datetime(3) DEFAULT NULL,
  `duration` bigint(20) DEFAULT NULL,
  `procname` varchar(80) DEFAULT NULL,
  `userkey` bigint(20) DEFAULT NULL,
  `host` varchar(50) DEFAULT NULL,
  `n` int(11) DEFAULT NULL,
  `_fk_testopportunity` varbinary(16) DEFAULT NULL,
  `clientname` varchar(100) DEFAULT NULL,
  `_fk_session` varbinary(16) DEFAULT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  KEY `ix_dblatency` (`procname`),
  KEY `ix_dblatency_db` (`dbname`,`starttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_dblatencyarchive`
--

DROP TABLE IF EXISTS `_dblatencyarchive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_dblatencyarchive` (
  `client` varchar(50) DEFAULT NULL,
  `starttime` datetime(3) DEFAULT NULL,
  `difftime` datetime(3) DEFAULT NULL,
  `duration` bigint(20) DEFAULT NULL,
  `procname` varchar(80) DEFAULT NULL,
  `userkey` bigint(20) DEFAULT NULL,
  `host` varchar(50) DEFAULT NULL,
  `n` int(11) DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `datearchived` datetime(3) NOT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  `_fk_session` varbinary(16) DEFAULT NULL,
  `_fk_testopportunity` varbinary(16) DEFAULT NULL,
  KEY `ix_dblatencyarchive` (`procname`,`client`),
  KEY `ix_dblatencyarchivesource` (`dbname`),
  KEY `ix_dblatencyarchivedate` (`starttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_dblatencyreports`
--

DROP TABLE IF EXISTS `_dblatencyreports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_dblatencyreports` (
  `client` varchar(50) DEFAULT NULL,
  `procname` varchar(100) DEFAULT NULL,
  `n` int(11) DEFAULT NULL,
  `minduration` int(11) DEFAULT NULL,
  `maxduration` int(11) DEFAULT NULL,
  `meanduration` int(11) DEFAULT NULL,
  `starttime` datetime(3) DEFAULT NULL,
  `endtime` datetime(3) DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `daterecorded` datetime(3) NOT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  KEY `ix_dblatencyreports` (`procname`,`client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auditaccommodations`
--

DROP TABLE IF EXISTS `auditaccommodations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditaccommodations` (
  `_fk_testopportunity` varbinary(16) NOT NULL,
  `acccode` varchar(50) NOT NULL,
  `acctype` varchar(50) NOT NULL,
  `datealtered` datetime(3) NOT NULL,
  `accvalue` varchar(250) DEFAULT NULL,
  `hostname` varchar(50) DEFAULT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  KEY `ix_auditaccommodations` (`dbname`,`_fk_testopportunity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `opportunityaudit`
--

DROP TABLE IF EXISTS `opportunityaudit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opportunityaudit` (
  `_fk_testopportunity` varbinary(16) NOT NULL,
  `dateaccessed` datetime(3) NOT NULL,
  `accesstype` varchar(50) NOT NULL,
  `_fk_session` varbinary(16) DEFAULT NULL,
  `isabnormal` bit(1) DEFAULT b'0',
  `hostname` char(50) DEFAULT NULL,
  `_fk_browser` varbinary(16) DEFAULT NULL,
  `comment` text,
  `actor` varchar(100) DEFAULT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  `satellite` varchar(200) DEFAULT NULL,
  KEY `ix_opportunityaudit` (`dbname`,`_fk_testopportunity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `opportunityclient`
--

DROP TABLE IF EXISTS `opportunityclient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opportunityclient` (
  `_fk_testopportunity` varbinary(16) NOT NULL,
  `_fk_browser` varbinary(16) NOT NULL,
  `restart` int(11) NOT NULL,
  `serverip` varchar(255) DEFAULT NULL,
  `clientip` varchar(255) DEFAULT NULL,
  `proxyip` varchar(255) DEFAULT NULL,
  `useragent` varchar(255) DEFAULT NULL,
  `screenrez` varchar(16) DEFAULT NULL,
  `issecure` bit(1) DEFAULT NULL,
  `_date` datetime(3) DEFAULT NULL,
  `macaddress` varchar(255) DEFAULT NULL,
  `localip` varchar(255) DEFAULT NULL,
  `texttospeech` varchar(100) DEFAULT NULL,
  `dbname` varchar(255) DEFAULT NULL,
  KEY `ix_opportunityclient` (`dbname`,`_fk_testopportunity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `serverlatency`
--

DROP TABLE IF EXISTS `serverlatency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serverlatency` (
  `_fk_testopportunity` varbinary(16) NOT NULL,
  `_fk_session` varbinary(16) DEFAULT NULL,
  `_fk_browser` varbinary(16) DEFAULT NULL,
  `operation` varchar(64) NOT NULL,
  `itempage` int(11) DEFAULT NULL,
  `_efk_itsitem` bigint(20) DEFAULT NULL,
  `dblatency` int(11) DEFAULT NULL,
  `serverlatency` int(11) DEFAULT NULL,
  `_date` datetime(3) DEFAULT NULL,
  `hostname` char(64) DEFAULT NULL,
  `itemtype` varchar(25) DEFAULT NULL,
  `pagelist` varchar(200) DEFAULT NULL,
  `itemlist` varchar(1000) DEFAULT NULL,
  `clientname` varchar(100) DEFAULT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  KEY `ix_serverlatency1` (`_fk_testopportunity`,`_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `serverlatencyarchive`
--

DROP TABLE IF EXISTS `serverlatencyarchive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serverlatencyarchive` (
  `client` varchar(100) DEFAULT NULL,
  `_fk_session` varbinary(16) DEFAULT NULL,
  `_fk_browser` varbinary(16) DEFAULT NULL,
  `operation` varchar(64) NOT NULL,
  `itempage` int(11) DEFAULT NULL,
  `_efk_itsitem` bigint(20) DEFAULT NULL,
  `dblatency` int(11) DEFAULT NULL,
  `serverlatency` int(11) DEFAULT NULL,
  `_date` datetime(3) DEFAULT NULL,
  `hostname` char(64) DEFAULT NULL,
  `itemtype` varchar(25) DEFAULT NULL,
  `pagelist` varchar(200) DEFAULT NULL,
  `itemlist` varchar(1000) DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `_fk_testopportunity` varbinary(16) DEFAULT NULL,
  `datearchived` datetime(3) NOT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  KEY `ix_serverlatencyarchive` (`operation`,`client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessionaudit`
--

DROP TABLE IF EXISTS `sessionaudit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessionaudit` (
  `_fk_session` varbinary(16) NOT NULL,
  `dateaccessed` datetime(3) NOT NULL,
  `accesstype` varchar(50) NOT NULL,
  `hostname` char(50) DEFAULT NULL,
  `browserkey` varbinary(16) NOT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  KEY `ix_sessionaudit` (`dbname`,`_fk_session`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemclient`
--

DROP TABLE IF EXISTS `systemclient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemclient` (
  `clientname` varchar(100) NOT NULL,
  `application` varchar(50) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `clientip` varchar(16) DEFAULT NULL,
  `proxyip` varchar(16) DEFAULT NULL,
  `useragent` varchar(255) DEFAULT NULL,
  `daterecorded` datetime(3) NOT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  KEY `ix_systemclient` (`dbname`,`clientname`,`application`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemerrors`
--

DROP TABLE IF EXISTS `systemerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemerrors` (
  `application` varchar(50) DEFAULT 'database',
  `procname` varchar(150) NOT NULL,
  `_efk_testee` bigint(20) DEFAULT NULL,
  `_efk_testid` varchar(150) DEFAULT NULL,
  `opportunity` int(11) DEFAULT NULL,
  `errormessage` text NOT NULL,
  `daterecorded` datetime(3) NOT NULL,
  `serverid` varchar(50) DEFAULT NULL,
  `ipaddress` varchar(50) DEFAULT NULL,
  `applicationcontextid` varbinary(16) DEFAULT NULL,
  `stacktrace` text,
  `_fk_testopportunity` varbinary(16) DEFAULT NULL,
  `clientname` varchar(100) DEFAULT NULL,
  `_fk_session` varbinary(16) DEFAULT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  KEY `ix_errors_db` (`dbname`,`daterecorded`),
  KEY `ix_sessionerrors` (`_fk_session`),
  KEY `ix_syserrsoppkey` (`_fk_testopportunity`),
  KEY `ix_systemerrors_2` (`application`,`procname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemerrorsarchive`
--

DROP TABLE IF EXISTS `systemerrorsarchive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemerrorsarchive` (
  `client` varchar(50) DEFAULT NULL,
  `application` varchar(50) DEFAULT NULL,
  `procname` varchar(150) NOT NULL,
  `_efk_testee` bigint(20) DEFAULT NULL,
  `_efk_testid` varchar(150) DEFAULT NULL,
  `opportunity` int(11) DEFAULT NULL,
  `errormessage` text NOT NULL,
  `daterecorded` datetime(3) NOT NULL,
  `serverid` varchar(50) DEFAULT NULL,
  `ipaddress` varchar(50) DEFAULT NULL,
  `applicationcontextid` varbinary(16) DEFAULT NULL,
  `stacktrace` text,
  `environment` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `datearchived` datetime(3) NOT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  `_fk_testopportunity` varbinary(16) DEFAULT NULL,
  `_fk_session` varbinary(16) DEFAULT NULL,
  KEY `ix_errorsarchiveclient` (`client`,`application`),
  KEY `ix_systemerrorsarchive` (`procname`,`daterecorded`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `testopportunityscores_audit`
--

DROP TABLE IF EXISTS `testopportunityscores_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testopportunityscores_audit` (
  `_fk_testopportunity` varbinary(16) NOT NULL,
  `measurelabel` varchar(100) NOT NULL,
  `value` varchar(100) DEFAULT NULL,
  `standarderror` float DEFAULT NULL,
  `measureof` varchar(150) NOT NULL,
  `isofficial` bit(1) DEFAULT NULL,
  `_date` datetime(3) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `dbname` varchar(50) DEFAULT NULL,
  KEY `ix_oppscoresaudit` (`dbname`,`_fk_testopportunity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'archive'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-05 14:53:35
