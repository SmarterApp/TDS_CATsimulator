CREATE DATABASE  IF NOT EXISTS `itembank` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `itembank`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: itembank
-- ------------------------------------------------------
-- Server version	5.7.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_dblatency`
--

DROP TABLE IF EXISTS `_dblatency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_dblatency` (
  `duration` int(11) NOT NULL,
  `endtime` datetime(3) NOT NULL,
  `procname` varchar(50) NOT NULL,
  `starttime` datetime(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_synonyms`
--

DROP TABLE IF EXISTS `_synonyms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_synonyms` (
  `dbname` varchar(200) NOT NULL,
  `_date` datetime(3) NOT NULL,
  `prefix` varchar(200) NOT NULL,
  PRIMARY KEY (`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_sys_formtestitems`
--

DROP TABLE IF EXISTS `_sys_formtestitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_sys_formtestitems` (
  `testid` varchar(100) NOT NULL,
  `bankkey` bigint(20) NOT NULL,
  `itemkey` bigint(20) NOT NULL,
  PRIMARY KEY (`testid`,`bankkey`,`itemkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_testupdate`
--

DROP TABLE IF EXISTS `_testupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_testupdate` (
  `_fk_adminsubject` varchar(250) NOT NULL,
  `configid` bigint(20) NOT NULL,
  `_date` datetime(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aa_itemcl`
--

DROP TABLE IF EXISTS `aa_itemcl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aa_itemcl` (
  `_fk_adminsubject` varchar(250) NOT NULL,
  `_fk_item` varchar(25) NOT NULL,
  `contentlevel` varchar(100) NOT NULL,
  PRIMARY KEY (`_fk_adminsubject`,`_fk_item`,`contentlevel`),
  KEY `ix_aaitemkey` (`_fk_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affinitygroup`
--

DROP TABLE IF EXISTS `affinitygroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `affinitygroup` (
  `_fk_adminsubject` varchar(250) NOT NULL,
  `groupid` varchar(100) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `minitems` int(11) NOT NULL,
  `maxitems` int(11) NOT NULL,
  `isstrictmax` bit(1) NOT NULL DEFAULT b'0',
  `weight` float NOT NULL DEFAULT '1',
  `selectioncriteria` varchar(2000) DEFAULT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  `startability` float DEFAULT NULL,
  `startinfo` float DEFAULT NULL,
  `abilityweight` float DEFAULT NULL,
  `precisiontarget` float DEFAULT NULL,
  `precisiontargetmetweight` float DEFAULT NULL,
  `precisiontargetnotmetweight` float DEFAULT NULL,
  PRIMARY KEY (`_fk_adminsubject`,`groupid`),
  CONSTRAINT `fk_affgrouptest` FOREIGN KEY (`_fk_adminsubject`) REFERENCES `tblsetofadminsubjects` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `affinitygroupitem`
--

DROP TABLE IF EXISTS `affinitygroupitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `affinitygroupitem` (
  `_fk_adminsubject` varchar(250) NOT NULL,
  `groupid` varchar(100) NOT NULL,
  `_fk_item` varchar(100) NOT NULL,
  PRIMARY KEY (`_fk_adminsubject`,`groupid`,`_fk_item`),
  CONSTRAINT `fk_itemaffinitygroup` FOREIGN KEY (`_fk_adminsubject`, `groupid`) REFERENCES `affinitygroup` (`_fk_adminsubject`, `groupid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alloweditemprops`
--

DROP TABLE IF EXISTS `alloweditemprops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alloweditemprops` (
  `propertyname` varchar(50) NOT NULL,
  PRIMARY KEY (`propertyname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `configsloaded`
--

DROP TABLE IF EXISTS `configsloaded`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configsloaded` (
  `configid` int(11) NOT NULL,
  `bankkey` bigint(20) NOT NULL,
  `clientname` varchar(200) NOT NULL,
  `contract` varchar(200) NOT NULL,
  `_date` datetime(3) NOT NULL,
  `_error` text,
  `tdsconfigs_updated` datetime(3) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `importitemcohorts`
--

DROP TABLE IF EXISTS `importitemcohorts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importitemcohorts` (
  `bankkey` varchar(150) DEFAULT NULL,
  `blueprint key` varchar(150) DEFAULT NULL,
  `testname` varchar(150) DEFAULT NULL,
  `itemid` varchar(150) DEFAULT NULL,
  `cohort number` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `importtestcohorts`
--

DROP TABLE IF EXISTS `importtestcohorts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `importtestcohorts` (
  `blueprint key` varchar(150) DEFAULT NULL,
  `testname` varchar(150) DEFAULT NULL,
  `cohort number` varchar(150) DEFAULT NULL,
  `cohort ratio` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `itemmeasurementparameter`
--

DROP TABLE IF EXISTS `itemmeasurementparameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itemmeasurementparameter` (
  `_fk_itemscoredimension` varbinary(16) NOT NULL,
  `_fk_measurementparameter` int(11) NOT NULL,
  `parmvalue` float DEFAULT NULL,
  PRIMARY KEY (`_fk_itemscoredimension`,`_fk_measurementparameter`),
  CONSTRAINT `fk_parameterscoredimension` FOREIGN KEY (`_fk_itemscoredimension`) REFERENCES `itemscoredimension` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `itemscoredimension`
--

DROP TABLE IF EXISTS `itemscoredimension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `itemscoredimension` (
  `dimension` varchar(255) NOT NULL DEFAULT '',
  `recoderule` varchar(255) DEFAULT NULL,
  `responsebankscale` varchar(150) DEFAULT NULL,
  `scorepoints` int(11) NOT NULL,
  `surrogateitemid` varchar(150) DEFAULT NULL,
  `weight` float NOT NULL,
  `_key` varbinary(16) NOT NULL,
  `_efk_surrogateitskey` bigint(20) DEFAULT NULL,
  `_fk_adminsubject` varchar(250) NOT NULL,
  `_fk_item` varchar(150) NOT NULL,
  `_fk_measurementmodel` int(11) NOT NULL,
  PRIMARY KEY (`_key`),
  KEY `ix_scoredimensionitem` (`_fk_item`),
  KEY `ix_scoredim_test` (`_fk_adminsubject`),
  CONSTRAINT `fk_itemdim_test` FOREIGN KEY (`_fk_adminsubject`) REFERENCES `tblsetofadminsubjects` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_errors`
--

DROP TABLE IF EXISTS `loader_errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_errors` (
  `testkey` varchar(250) NOT NULL,
  `testpackageversion` varchar(20) DEFAULT NULL,
  `severity` varchar(100) NOT NULL,
  `errormsg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_itemscoredimension`
--

DROP TABLE IF EXISTS `loader_itemscoredimension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_itemscoredimension` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `testitemid` varchar(150) DEFAULT NULL,
  `measuremodel` varchar(100) DEFAULT NULL,
  `measuremodelkey` int(11) DEFAULT NULL,
  `dimensionname` varchar(200) DEFAULT NULL,
  `scorepoints` int(11) DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `measurementparam` varchar(50) DEFAULT NULL,
  `measurementparamnum` int(11) DEFAULT NULL,
  `measurementvalue` float DEFAULT NULL,
  KEY `ix_loader_itemscoredimension` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_itemscoredimensionproperties`
--

DROP TABLE IF EXISTS `loader_itemscoredimensionproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_itemscoredimensionproperties` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `testitemid` varchar(150) DEFAULT NULL,
  `dimensionname` varchar(200) DEFAULT NULL,
  `propname` varchar(200) DEFAULT NULL,
  `propvalue` varchar(200) DEFAULT NULL,
  KEY `ix_loader_itemscoredimensionproperties` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_measurementparameter`
--

DROP TABLE IF EXISTS `loader_measurementparameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_measurementparameter` (
  `modelnum` float NOT NULL,
  `parmnum` float DEFAULT NULL,
  `parmname` varchar(255) DEFAULT NULL,
  `parmdescription` varchar(255) DEFAULT NULL,
  `modelname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_segment`
--

DROP TABLE IF EXISTS `loader_segment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_segment` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `segmentid` varchar(250) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `itemselection` varchar(100) DEFAULT NULL,
  `itemselectortype` varchar(100) DEFAULT NULL,
  `itemselectorid` varchar(200) DEFAULT NULL,
  `itemselectorname` varchar(200) DEFAULT NULL,
  `itemselectorlabel` varchar(200) DEFAULT NULL,
  `version` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_segmentblueprint`
--

DROP TABLE IF EXISTS `loader_segmentblueprint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_segmentblueprint` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `segmentid` varchar(250) DEFAULT NULL,
  `segmentbpelementid` varchar(150) DEFAULT NULL,
  `minopitems` int(11) DEFAULT NULL,
  `maxopitems` int(11) DEFAULT NULL,
  KEY `ix_loader_segmentblueprint` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_segmentform`
--

DROP TABLE IF EXISTS `loader_segmentform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_segmentform` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `segmentid` varchar(250) DEFAULT NULL,
  `formpartitionid` varchar(100) DEFAULT NULL,
  KEY `ix_loader_segmentform` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_segmentitemselectionproperties`
--

DROP TABLE IF EXISTS `loader_segmentitemselectionproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_segmentitemselectionproperties` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `segmentid` varchar(250) DEFAULT NULL,
  `itemselectorid` varchar(500) DEFAULT NULL,
  `bpelementid` varchar(250) DEFAULT NULL,
  `propname` varchar(200) DEFAULT NULL,
  `propvalue` varchar(100) DEFAULT NULL,
  `proplabel` varchar(500) DEFAULT NULL,
  KEY `ix_loader_segmentitemselectionproperties` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_segmentpool`
--

DROP TABLE IF EXISTS `loader_segmentpool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_segmentpool` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `segmentid` varchar(250) DEFAULT NULL,
  `itemgroupid` varchar(100) DEFAULT NULL,
  `itemgroupname` varchar(100) DEFAULT NULL,
  `maxitems` varchar(30) DEFAULT NULL,
  `maxresponses` varchar(30) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  KEY `ix_loader_segmentpool` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_segmentpoolgroupitem`
--

DROP TABLE IF EXISTS `loader_segmentpoolgroupitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_segmentpoolgroupitem` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `segmentid` varchar(250) DEFAULT NULL,
  `itemgroupid` varchar(100) DEFAULT NULL,
  `groupitemid` varchar(150) DEFAULT NULL,
  `groupposition` int(11) DEFAULT NULL,
  `adminrequired` bit(1) DEFAULT NULL,
  `responserequired` bit(1) DEFAULT NULL,
  `isfieldtest` bit(1) DEFAULT NULL,
  `isactive` bit(1) DEFAULT NULL,
  `blockid` varchar(10) DEFAULT NULL,
  KEY `ix_loader_segmentpoolgroupitem` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_segmentpoolpassageref`
--

DROP TABLE IF EXISTS `loader_segmentpoolpassageref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_segmentpoolpassageref` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `segmentid` varchar(250) DEFAULT NULL,
  `itemgroupid` varchar(100) DEFAULT NULL,
  `passageid` varchar(100) DEFAULT NULL,
  KEY `ix_loader_segmentpoolpassageref` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_setofitemstrands`
--

DROP TABLE IF EXISTS `loader_setofitemstrands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_setofitemstrands` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `_fk_item` varchar(150) DEFAULT NULL,
  `_fk_strand` varchar(150) DEFAULT NULL,
  `_fk_adminsubject` varchar(250) DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  KEY `ix_loader_setofitemstrands` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testblueprint`
--

DROP TABLE IF EXISTS `loader_testblueprint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testblueprint` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `elementtype` varchar(100) DEFAULT NULL,
  `bpelementid` varchar(250) DEFAULT NULL,
  `bpelementname` varchar(255) DEFAULT NULL,
  `bpelmentlabel` varchar(200) DEFAULT NULL,
  `minopitems` int(11) DEFAULT NULL,
  `maxopitems` int(11) DEFAULT NULL,
  `minftitems` int(11) DEFAULT NULL,
  `maxftitems` int(11) DEFAULT NULL,
  `opitemcount` int(11) DEFAULT NULL,
  `ftitemcount` int(11) DEFAULT NULL,
  `parentid` varchar(150) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `treelevel` int(11) DEFAULT NULL,
  KEY `ix_loader_testblueprint` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testformgroupitems`
--

DROP TABLE IF EXISTS `loader_testformgroupitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testformgroupitems` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `testformid` varchar(200) DEFAULT NULL,
  `formitemgroupid` varchar(200) DEFAULT NULL,
  `itemid` varchar(150) DEFAULT NULL,
  `formposition` int(11) DEFAULT NULL,
  `groupposition` int(11) DEFAULT NULL,
  `adminrequired` bit(1) DEFAULT NULL,
  `responserequired` bit(1) DEFAULT NULL,
  `isactive` bit(1) DEFAULT NULL,
  `isfieldtest` bit(1) DEFAULT NULL,
  `blockid` varchar(10) DEFAULT NULL,
  KEY `ix_loader_testformgroupitems` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testformitemgroup`
--

DROP TABLE IF EXISTS `loader_testformitemgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testformitemgroup` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `testformid` varchar(200) DEFAULT NULL,
  `formpartitionid` varchar(200) DEFAULT NULL,
  `formitemgroupid` varchar(200) DEFAULT NULL,
  `formitemgroupname` varchar(200) DEFAULT NULL,
  `formitemgrouplabel` varchar(200) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `formposition` int(11) DEFAULT NULL,
  `maxitems` varchar(30) DEFAULT NULL,
  `maxresponses` varchar(30) DEFAULT NULL,
  `passageid` varchar(100) DEFAULT NULL,
  KEY `ix_loader_testformitemgroup` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testformpartition`
--

DROP TABLE IF EXISTS `loader_testformpartition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testformpartition` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `testformid` varchar(200) DEFAULT NULL,
  `formpartitionid` varchar(200) DEFAULT NULL,
  `formpartitionname` varchar(250) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  KEY `ix_loader_testformpartition` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testformproperties`
--

DROP TABLE IF EXISTS `loader_testformproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testformproperties` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `testformid` varchar(200) DEFAULT NULL,
  `isPool` bit(1) DEFAULT NULL,
  `propname` varchar(200) DEFAULT NULL,
  `proplabel` varchar(200) DEFAULT NULL,
  `propvalue` varchar(200) DEFAULT NULL,
  `itemcount` int(11) DEFAULT NULL,
  KEY `ix_loader_testformproperties` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testforms`
--

DROP TABLE IF EXISTS `loader_testforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testforms` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `testformid` varchar(200) DEFAULT NULL,
  `testformname` varchar(200) DEFAULT NULL,
  `testformlength` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  KEY `ix_loader_testforms` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testitem`
--

DROP TABLE IF EXISTS `loader_testitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testitem` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `filepath` varchar(200) DEFAULT NULL,
  `itemtype` varchar(50) DEFAULT NULL,
  `testitemid` varchar(150) DEFAULT NULL,
  `testitemname` varchar(80) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  KEY `ix_loader_testitem` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testitempoolproperties`
--

DROP TABLE IF EXISTS `loader_testitempoolproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testitempoolproperties` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `testitemid` varchar(150) DEFAULT NULL,
  `propname` varchar(50) DEFAULT NULL,
  `propvalue` varchar(128) DEFAULT NULL,
  `proplabel` varchar(150) DEFAULT NULL,
  KEY `ix_loader_testitempoolproperties` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testitemrefs`
--

DROP TABLE IF EXISTS `loader_testitemrefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testitemrefs` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `testitemid` varchar(150) DEFAULT NULL,
  `reftype` varchar(50) DEFAULT NULL,
  `ref` varchar(150) DEFAULT NULL,
  `refcategory` varchar(250) DEFAULT NULL,
  `treelevel` int(11) DEFAULT NULL,
  KEY `ix_loader_testitemrefs` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testpackage`
--

DROP TABLE IF EXISTS `loader_testpackage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testpackage` (
  `packagekey` varchar(350) DEFAULT NULL,
  `purpose` varchar(100) DEFAULT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `publishdate` varchar(200) DEFAULT NULL,
  `packageversion` varchar(20) DEFAULT NULL,
  `testkey` varchar(250) DEFAULT NULL,
  `testname` varchar(200) DEFAULT NULL,
  `testlabel` varchar(200) DEFAULT NULL,
  `testversion` int(11) DEFAULT NULL,
  `year` varchar(50) DEFAULT NULL,
  `season` varchar(50) DEFAULT NULL,
  `clientkey` int(11) DEFAULT NULL,
  `subjectkey` varchar(100) DEFAULT NULL,
  `subjectname` varchar(100) DEFAULT NULL,
  `testadmin` varchar(250) DEFAULT NULL,
  `_efk_itembank` bigint(20) DEFAULT NULL,
  KEY `ix_loader_testpackage` (`packagekey`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testpackageproperties`
--

DROP TABLE IF EXISTS `loader_testpackageproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testpackageproperties` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `propname` varchar(200) DEFAULT NULL,
  `propvalue` varchar(200) DEFAULT NULL,
  `proplabel` varchar(200) DEFAULT NULL,
  KEY `ix_loader_testpackageproperties` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testpassages`
--

DROP TABLE IF EXISTS `loader_testpassages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testpassages` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `filename` varchar(50) DEFAULT NULL,
  `filepath` varchar(50) DEFAULT NULL,
  `passageid` varchar(150) DEFAULT NULL,
  `passagename` varchar(100) DEFAULT NULL,
  `passagevalue` varchar(200) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  KEY `ix_loader_testpassages` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_testpoolproperties`
--

DROP TABLE IF EXISTS `loader_testpoolproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_testpoolproperties` (
  `_fk_package` varchar(350) DEFAULT NULL,
  `propname` varchar(50) DEFAULT NULL,
  `propvalue` varchar(128) DEFAULT NULL,
  `proplabel` varchar(150) DEFAULT NULL,
  `itemcount` int(11) DEFAULT NULL,
  KEY `ix_loader_testpoolproperties` (`_fk_package`(250))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `measurementmodel`
--

DROP TABLE IF EXISTS `measurementmodel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `measurementmodel` (
  `modelnumber` int(11) NOT NULL,
  `modelname` varchar(50) NOT NULL,
  PRIMARY KEY (`modelnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `measurementparameter`
--

DROP TABLE IF EXISTS `measurementparameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `measurementparameter` (
  `_fk_measurementmodel` int(11) NOT NULL,
  `parmnum` int(11) NOT NULL,
  `parmname` varchar(50) NOT NULL,
  `parmdescription` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`_fk_measurementmodel`,`parmnum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `performancelevels`
--

DROP TABLE IF EXISTS `performancelevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `performancelevels` (
  `_fk_content` varchar(250) NOT NULL,
  `plevel` int(11) NOT NULL,
  `thetalo` float NOT NULL,
  `thetahi` float NOT NULL,
  `scaledlo` float DEFAULT NULL,
  `scaledhi` float DEFAULT NULL,
  PRIMARY KEY (`_fk_content`,`plevel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `_key` int(11) NOT NULL,
  `_fk_client` bigint(20) DEFAULT NULL,
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `setoftestgrades`
--

DROP TABLE IF EXISTS `setoftestgrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setoftestgrades` (
  `testid` varchar(100) NOT NULL,
  `grade` varchar(25) NOT NULL,
  `requireenrollment` bit(1) NOT NULL DEFAULT b'0',
  `_fk_adminsubject` varchar(250) NOT NULL,
  `enrolledsubject` varchar(100) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`),
  KEY `fk_testgrades_test` (`_fk_adminsubject`),
  KEY `ix_testgrades_testid` (`testid`),
  CONSTRAINT `fk_testgrades_test` FOREIGN KEY (`_fk_adminsubject`) REFERENCES `tblsetofadminsubjects` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbladminstimulus`
--

DROP TABLE IF EXISTS `tbladminstimulus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbladminstimulus` (
  `_fk_stimulus` varchar(100) NOT NULL,
  `_fk_adminsubject` varchar(250) NOT NULL,
  `numitemsrequired` int(11) NOT NULL DEFAULT '-1',
  `maxitems` int(11) NOT NULL DEFAULT '-1',
  `bpweight` float NOT NULL DEFAULT '1',
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  `groupid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`_fk_adminsubject`,`_fk_stimulus`),
  CONSTRAINT `fk_adminstimulus_adminsubject` FOREIGN KEY (`_fk_adminsubject`) REFERENCES `tblsetofadminsubjects` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbladminstrand`
--

DROP TABLE IF EXISTS `tbladminstrand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbladminstrand` (
  `_fk_adminsubject` varchar(250) NOT NULL,
  `_fk_strand` varchar(150) NOT NULL,
  `minitems` int(11) DEFAULT NULL,
  `maxitems` int(11) DEFAULT NULL,
  `adaptivecut` float DEFAULT NULL,
  `startability` float DEFAULT NULL,
  `startinfo` float DEFAULT NULL,
  `scalar` float DEFAULT NULL,
  `_fk_proflevels` bigint(20) DEFAULT NULL,
  `loaderid` varchar(150) DEFAULT NULL,
  `synthmin` int(11) DEFAULT NULL,
  `synthmax` int(11) DEFAULT NULL,
  `inheritmin` int(11) DEFAULT NULL,
  `inheritmax` int(11) DEFAULT NULL,
  `inheritratio` float DEFAULT '-1',
  `numitems` int(11) DEFAULT NULL,
  `loadmin` int(11) DEFAULT NULL,
  `loadmax` int(11) DEFAULT NULL,
  `_key` varchar(255) NOT NULL,
  `isstrictmax` bit(1) NOT NULL DEFAULT b'0',
  `bpweight` float NOT NULL DEFAULT '1',
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  `precisiontarget` float DEFAULT NULL,
  `precisiontargetmetweight` float DEFAULT NULL,
  `precisiontargetnotmetweight` float DEFAULT NULL,
  `abilityweight` float DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `ix_adminstrand_test` (`_fk_adminsubject`),
  KEY `ix_tbladminstrand` (`loaderid`),
  CONSTRAINT `fk_adminstrand_adminsubject` FOREIGN KEY (`_fk_adminsubject`) REFERENCES `tblsetofadminsubjects` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbladminsubjecttestpackage`
--

DROP TABLE IF EXISTS `tbladminsubjecttestpackage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbladminsubjecttestpackage` (
  `_fk_adminsubject` varchar(250) NOT NULL,
  `_fk_testpackage` varbinary(16) NOT NULL,
  `dateloaded` datetime(3) NOT NULL,
  PRIMARY KEY (`_fk_testpackage`,`_fk_adminsubject`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblalternatetest`
--

DROP TABLE IF EXISTS `tblalternatetest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblalternatetest` (
  `_key` bigint(20) NOT NULL AUTO_INCREMENT,
  `_fk_adminsubject` bigint(20) NOT NULL,
  `formlang` char(128) NOT NULL,
  `filepath` char(255) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblclient`
--

DROP TABLE IF EXISTS `tblclient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblclient` (
  `_key` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `homepath` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblitem`
--

DROP TABLE IF EXISTS `tblitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitem` (
  `_efk_itembank` bigint(20) NOT NULL,
  `_efk_item` bigint(20) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(50) DEFAULT NULL,
  `answer` varchar(50) DEFAULT NULL,
  `scorepoint` int(11) DEFAULT NULL,
  `filepath` varchar(50) DEFAULT NULL,
  `filename` varchar(50) DEFAULT NULL,
  `version` varchar(150) DEFAULT NULL,
  `datelastupdated` datetime(3) DEFAULT NULL,
  `itemid` varchar(80) DEFAULT NULL,
  `_key` varchar(150) NOT NULL,
  `contentsize` int(11) DEFAULT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  UNIQUE KEY `ix_tblitem` (`_efk_itembank`,`_efk_item`),
  KEY `ix_efk_item` (`_efk_item`)
) ENGINE=InnoDB AUTO_INCREMENT=126572 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblitembank`
--

DROP TABLE IF EXISTS `tblitembank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitembank` (
  `_fk_client` bigint(20) NOT NULL,
  `homepath` varchar(255) DEFAULT NULL,
  `itempath` varchar(50) DEFAULT NULL,
  `stimulipath` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `_efk_itembank` bigint(20) NOT NULL,
  `_key` bigint(20) NOT NULL,
  `contract` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `fk_itembank_client` (`_fk_client`),
  CONSTRAINT `fk_itembank_client` FOREIGN KEY (`_fk_client`) REFERENCES `tblclient` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblitemgroup`
--

DROP TABLE IF EXISTS `tblitemgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitemgroup` (
  `_fk_adminsubject` varchar(250) NOT NULL,
  `groupid` varchar(50) NOT NULL,
  `numitemsrequired` int(11) NOT NULL DEFAULT '-1',
  `maxitems` int(11) NOT NULL DEFAULT '-1',
  `bpweight` float NOT NULL DEFAULT '1',
  `ftweight` float DEFAULT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  `ftitemcount` int(11) DEFAULT NULL,
  `opitemcount` int(11) DEFAULT NULL,
  `ftweightsum` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblitemprops`
--

DROP TABLE IF EXISTS `tblitemprops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitemprops` (
  `_fk_item` varchar(150) NOT NULL,
  `propname` varchar(50) NOT NULL,
  `propvalue` varchar(128) NOT NULL,
  `propdescription` varchar(150) DEFAULT NULL,
  `_fk_adminsubject` varchar(250) NOT NULL,
  `isactive` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`_fk_adminsubject`,`_fk_item`,`propname`,`propvalue`),
  KEY `fk_tblitemprops_tblitem` (`_fk_item`),
  CONSTRAINT `fk_tblitemprops_tblitem` FOREIGN KEY (`_fk_item`) REFERENCES `tblitem` (`_key`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblitemselectionparm`
--

DROP TABLE IF EXISTS `tblitemselectionparm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblitemselectionparm` (
  `_fk_adminsubject` varchar(250) NOT NULL,
  `bpelementid` varchar(200) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(200) NOT NULL,
  `label` varchar(200) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblsetofadminitems`
--

DROP TABLE IF EXISTS `tblsetofadminitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsetofadminitems` (
  `_fk_item` varchar(150) NOT NULL,
  `_fk_adminsubject` varchar(250) NOT NULL,
  `groupid` varchar(100) DEFAULT NULL,
  `itemposition` int(11) DEFAULT NULL,
  `isfieldtest` bit(1) DEFAULT NULL,
  `isactive` bit(1) DEFAULT NULL,
  `irt_b` varchar(150) DEFAULT NULL,
  `blockid` varchar(10) DEFAULT NULL,
  `ftstartdate` datetime(3) DEFAULT NULL,
  `ftenddate` datetime(3) DEFAULT NULL,
  `isrequired` bit(1) NOT NULL DEFAULT b'0',
  `isprintable` bit(1) DEFAULT b'0',
  `_fk_testadmin` varchar(150) DEFAULT NULL,
  `responsemimetype` varchar(255) NOT NULL DEFAULT 'text/plain',
  `testcohort` int(11) NOT NULL DEFAULT '1',
  `_fk_strand` varchar(150) DEFAULT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  `groupkey` varchar(100) DEFAULT NULL,
  `strandname` varchar(150) DEFAULT NULL,
  `irt_a` float DEFAULT NULL,
  `irt_c` float DEFAULT NULL,
  `irt_model` varchar(100) DEFAULT NULL,
  `bvector` varchar(200) DEFAULT NULL,
  `notforscoring` bit(1) NOT NULL DEFAULT b'0',
  `clstring` text,
  `irt2_a` varchar(400) DEFAULT NULL,
  `irt2_b` varchar(800) DEFAULT NULL,
  `irt2_c` varchar(400) DEFAULT NULL,
  `irt2_model` varchar(800) DEFAULT NULL,
  `ftweight` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`_fk_adminsubject`,`_fk_item`),
  KEY `fk_tblsetofadminitems_tblitem` (`_fk_item`),
  KEY `ix_adminitemgroup2` (`_fk_adminsubject`,`groupid`,`blockid`),
  KEY `ix_adminitem_ftitemgroup` (`_fk_adminsubject`,`isfieldtest`,`groupkey`),
  CONSTRAINT `fk_tblsetofadminitems_tblitem` FOREIGN KEY (`_fk_item`) REFERENCES `tblitem` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tblsetofadminitems_tblsetofadminsubjects` FOREIGN KEY (`_fk_adminsubject`) REFERENCES `tblsetofadminsubjects` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblsetofadminsubjects`
--

DROP TABLE IF EXISTS `tblsetofadminsubjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsetofadminsubjects` (
  `_key` varchar(250) NOT NULL,
  `_fk_testadmin` varchar(150) NOT NULL,
  `_fk_subject` varchar(150) NOT NULL,
  `testid` varchar(255) DEFAULT NULL,
  `startability` float DEFAULT NULL,
  `startinfo` float DEFAULT NULL,
  `minitems` int(11) DEFAULT NULL,
  `maxitems` int(11) DEFAULT NULL,
  `slope` float DEFAULT NULL,
  `intercept` float DEFAULT NULL,
  `ftstartpos` int(11) DEFAULT NULL,
  `ftendpos` int(11) DEFAULT NULL,
  `ftminitems` int(11) DEFAULT NULL,
  `ftmaxitems` int(11) DEFAULT NULL,
  `sampletarget` float DEFAULT NULL,
  `selectionalgorithm` varchar(50) DEFAULT NULL,
  `formselection` varchar(100) DEFAULT NULL,
  `blueprintweight` float NOT NULL DEFAULT '5',
  `abilityweight` float NOT NULL DEFAULT '1',
  `cset1size` int(11) NOT NULL DEFAULT '20',
  `cset2random` int(11) NOT NULL DEFAULT '1',
  `cset2initialrandom` int(11) NOT NULL DEFAULT '5',
  `virtualtest` varchar(200) DEFAULT NULL,
  `testposition` int(11) DEFAULT NULL,
  `issegmented` bit(1) NOT NULL DEFAULT b'0',
  `computeabilityestimates` bit(1) NOT NULL DEFAULT b'1',
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  `itemweight` float DEFAULT '5',
  `abilityoffset` float DEFAULT '0',
  `contract` varchar(100) DEFAULT NULL,
  `its_id` varchar(200) DEFAULT NULL,
  `cset1order` varchar(50) NOT NULL DEFAULT 'ability',
  `refreshminutes` int(11) DEFAULT NULL,
  `rcabilityweight` float NOT NULL DEFAULT '1',
  `precisiontarget` float DEFAULT NULL,
  `precisiontargetmetweight` float NOT NULL DEFAULT '1',
  `precisiontargetnotmetweight` float NOT NULL DEFAULT '1',
  `adaptivecut` float DEFAULT NULL,
  `toocloseses` float DEFAULT NULL,
  `terminationoverallinfo` bit(1) NOT NULL DEFAULT b'0',
  `terminationrcinfo` bit(1) NOT NULL DEFAULT b'0',
  `terminationmincount` bit(1) NOT NULL DEFAULT b'0',
  `terminationtooclose` bit(1) NOT NULL DEFAULT b'0',
  `terminationflagsand` bit(1) NOT NULL DEFAULT b'0',
  `bpmetricfunction` varchar(25) NOT NULL DEFAULT 'bp2',
  `_efk_blueprint` bigint(20) DEFAULT NULL,
  `initialabilitytestID` varchar(100) DEFAULT NULL,
  `testtype` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `fk_tblsetofadminsubjects_tblsetofadminsubjects` (`_fk_testadmin`),
  KEY `ix_adminsubjects_testid` (`testid`),
  KEY `ix_adminsubjects_virtualtest` (`virtualtest`),
  CONSTRAINT `fk_tblsetofadminsubjects_tblsetofadminsubjects` FOREIGN KEY (`_fk_testadmin`) REFERENCES `tbltestadmin` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblsetofitemstimuli`
--

DROP TABLE IF EXISTS `tblsetofitemstimuli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsetofitemstimuli` (
  `_fk_item` varchar(150) NOT NULL,
  `_fk_stimulus` varchar(150) NOT NULL,
  `_fk_adminsubject` varchar(250) NOT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`_fk_item`,`_fk_stimulus`,`_fk_adminsubject`),
  KEY `fk_tblsetofitemstimuli_tblstimulus` (`_fk_stimulus`),
  CONSTRAINT `fk_tblsetofitemstimuli_tblitem` FOREIGN KEY (`_fk_item`) REFERENCES `tblitem` (`_key`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_tblsetofitemstimuli_tblstimulus` FOREIGN KEY (`_fk_stimulus`) REFERENCES `tblstimulus` (`_key`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblsetofitemstrands`
--

DROP TABLE IF EXISTS `tblsetofitemstrands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsetofitemstrands` (
  `_fk_item` varchar(150) NOT NULL,
  `_fk_strand` varchar(150) NOT NULL,
  `_fk_adminsubject` varchar(250) NOT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`_fk_item`,`_fk_strand`,`_fk_adminsubject`),
  CONSTRAINT `fk_tblsetofitemstrands_tblitem` FOREIGN KEY (`_fk_item`) REFERENCES `tblitem` (`_key`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblstimulus`
--

DROP TABLE IF EXISTS `tblstimulus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblstimulus` (
  `_efk_itembank` bigint(20) NOT NULL,
  `_efk_itskey` bigint(20) NOT NULL AUTO_INCREMENT,
  `clientid` varchar(100) DEFAULT NULL,
  `filepath` varchar(50) DEFAULT NULL,
  `filename` varchar(50) DEFAULT NULL,
  `version` varchar(150) DEFAULT NULL,
  `datelastupdated` datetime(3) DEFAULT NULL,
  `_key` varchar(150) NOT NULL,
  `contentsize` int(11) DEFAULT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `ix_tblstimulus_efk_itskey` (`_efk_itskey`),
  KEY `ix_tblstimulus` (`_efk_itembank`,`_efk_itskey`)
) ENGINE=InnoDB AUTO_INCREMENT=4556 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblstrand`
--

DROP TABLE IF EXISTS `tblstrand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblstrand` (
  `_fk_subject` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `scorereportname` varchar(55) DEFAULT NULL,
  `_fk_parent` varchar(150) DEFAULT NULL,
  `_key` varchar(150) NOT NULL,
  `description` varchar(512) DEFAULT NULL,
  `_fk_client` bigint(20) DEFAULT NULL,
  `treelevel` int(11) DEFAULT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `fk_tblstrand_tblstrand` (`_fk_subject`),
  KEY `ix_tblstrand` (`name`),
  CONSTRAINT `fk_tblstrand_tblstrand` FOREIGN KEY (`_fk_subject`) REFERENCES `tblsubject` (`_key`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tblsubject`
--

DROP TABLE IF EXISTS `tblsubject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsubject` (
  `name` varchar(100) NOT NULL,
  `grade` varchar(64) DEFAULT NULL,
  `_key` varchar(150) NOT NULL,
  `_fk_client` bigint(20) DEFAULT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `fk_subject_client` (`_fk_client`),
  CONSTRAINT `fk_subject_client` FOREIGN KEY (`_fk_client`) REFERENCES `tblclient` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbltestadmin`
--

DROP TABLE IF EXISTS `tbltestadmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltestadmin` (
  `schoolyear` varchar(25) NOT NULL,
  `season` varchar(10) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `_key` varchar(150) NOT NULL,
  `_fk_client` bigint(20) DEFAULT NULL,
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `fk_testadmin_client` (`_fk_client`),
  CONSTRAINT `fk_testadmin_client` FOREIGN KEY (`_fk_client`) REFERENCES `tblclient` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbltestpackage`
--

DROP TABLE IF EXISTS `tbltestpackage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbltestpackage` (
  `_key` varbinary(16) NOT NULL,
  `testpackage` longtext,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `testcohort`
--

DROP TABLE IF EXISTS `testcohort`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testcohort` (
  `_fk_adminsubject` varchar(200) NOT NULL,
  `cohort` int(11) NOT NULL,
  `itemratio` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`_fk_adminsubject`,`cohort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `testform`
--

DROP TABLE IF EXISTS `testform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testform` (
  `_fk_adminsubject` varchar(250) NOT NULL,
  `_efk_itsbank` bigint(20) NOT NULL,
  `_efk_itskey` bigint(20) NOT NULL,
  `formid` varchar(150) DEFAULT NULL,
  `language` varchar(150) DEFAULT NULL,
  `_key` varchar(100) NOT NULL,
  `itsid` varchar(150) DEFAULT NULL,
  `iteration` int(11) NOT NULL DEFAULT '0',
  `loadconfig` bigint(20) DEFAULT NULL,
  `updateconfig` bigint(20) DEFAULT NULL,
  `cohort` varchar(20) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`_key`),
  KEY `fk_testform_tblsetofadminsubjects` (`_fk_adminsubject`),
  CONSTRAINT `fk_testform_tblsetofadminsubjects` FOREIGN KEY (`_fk_adminsubject`) REFERENCES `tblsetofadminsubjects` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `testformitem`
--

DROP TABLE IF EXISTS `testformitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testformitem` (
  `_fk_item` varchar(150) NOT NULL,
  `_efk_itsformkey` bigint(20) NOT NULL,
  `formposition` int(11) NOT NULL,
  `_fk_adminsubject` varchar(250) NOT NULL,
  `_fk_testform` varchar(100) NOT NULL DEFAULT '',
  `isactive` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`_fk_item`,`formposition`,`_fk_adminsubject`,`_fk_testform`),
  UNIQUE KEY `ix_formitemposition` (`_fk_testform`,`formposition`),
  UNIQUE KEY `ix_formitemunique` (`_fk_testform`,`_fk_item`),
  KEY `ix_formitem_test` (`_fk_adminsubject`),
  CONSTRAINT `fk_formitemform` FOREIGN KEY (`_fk_testform`) REFERENCES `testform` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'itembank'
--
/*!50003 DROP FUNCTION IF EXISTS `clientitemfile` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `clientitemfile`(

	v_clientname varchar(100)
  , v_itemkey varchar(50)) RETURNS varchar(150) CHARSET utf8
begin

	
	declare v_path varchar(150);

	select concat(c.homepath, b.homepath, b.itempath, i.filepath, i.filename)
	into v_path
	from tblitembank b, tblclient c, tblitem i
	where b._efk_itembank = i._efk_itembank 
		and c.`name` = v_clientname 
		and b._fk_client = c._key 
		and i._key = v_itemkey;

	return v_path;
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `clientitemstimuluspath` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `clientitemstimuluspath`(

	v_clientname varchar(100)
  , v_testkey varchar(250)
  , v_itemkey varchar(50)
) RETURNS varchar(150) CHARSET utf8
    SQL SECURITY INVOKER
begin

	
	declare v_path varchar(150);

	select concat(c.homepath, b.homepath, b.stimulipath, s.filepath, s.filename)
	into v_path
	from tblitembank b, tblclient c, tblstimulus s, tblsetofitemstimuli i
	where i._fk_adminsubject = v_testkey 
		and i._fk_item = v_itemkey 
        and s._key = _fk_stimulus 
		and c.`name` = v_clientname
        and b._efk_itembank = s._efk_itembank 
		and b._fk_client = c._key;
        
	return v_path;
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `getinitialability` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `getinitialability`(

	v_testkey varchar(250)) RETURNS float
    SQL SECURITY INVOKER
begin

	declare v_result float;
	
    select startability into v_result
    from tblsetofadminsubjects 
	where _key = v_testkey;

    return v_result;
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `isselectable` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `isselectable`(

	v_testkey varchar(250)
) RETURNS bit(1)
    SQL SECURITY INVOKER
begin

	declare v_result bit;

    set v_result = coalesce((select 0 
							   from tblsetofadminsubjects
							  where _key = v_testkey 
							    and (virtualtest is not null
									or testid like '%student help%'))
							, 1);

    return v_result;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `itembvector` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `itembvector`(

	v_testkey varchar(200)
  , v_itemkey varchar(20)
) RETURNS varchar(1000) CHARSET utf8
    SQL SECURITY INVOKER
begin

    declare v_result varchar(1000);
    declare v_b float;
    declare v_p int;

	drop temporary table if exists tmp_b_s;
    create temporary table tmp_b_s (b float, parmnum int, _key int primary key auto_increment);
    
    insert into tmp_b_s (b, parmnum)
    select parmvalue, parmnum
      from itemscoredimension d 
	  join itemmeasurementparameter p on p._fk_itemscoredimension = d._key
	  join measurementparameter m on m._fk_measurementmodel = d._fk_measurementmodel
								 and m.parmnum = p._fk_measurementparameter
     where d._fk_adminsubject = v_testkey 
	   and d._fk_item = v_itemkey 
       and m.parmname like 'b%';

    while (exists (select * from tmp_b_s)) do
	begin
        select b, _key into v_b, v_p from tmp_b_s limit 1;
        delete from tmp_b_s where _key = v_p;
        if (v_result is null) then
            set v_result = cast(v_b as char(50));
        else 
            set v_result = concat(v_result, ';',  cast(v_b as char(50)));
		end if;
    end;
	end while;

	drop temporary table tmp_b_s;

    return v_result;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `makeclstring` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `makeclstring`(

	v_testkey varchar(250)
  , v_itemkey varchar(50)
) RETURNS text CHARSET utf8
    SQL SECURITY INVOKER
begin

	
    declare v_str text;
	declare v_cl varchar(100);
	
	drop temporary table if exists tmp_cltbl;
	create temporary table tmp_cltbl (
		cl varchar(100)
	);

    insert into tmp_cltbl (cl)
    select contentlevel 
	  from aa_itemcl 
	 where _fk_adminsubject = v_testkey 
	   and _fk_item = v_itemkey 
	order by contentlevel;

    while (exists (select * from tmp_cltbl)) do
	begin
        set v_cl = (select cl from tmp_cltbl limit 1);

        if (v_str is null) then 
			set v_str = v_cl;
        else 
			set v_str = concat(v_str, ';', v_cl);
		end if;

        delete from tmp_cltbl where cl = v_cl;
    end;
	end while;

	
	drop temporary table tmp_cltbl;

	
    return v_str;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `makesubjectkey` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `makesubjectkey`(

	v_client 	  varchar(100)
  , v_subjectname varchar(100)
  , v_grade 	  varchar(100)
) RETURNS varchar(200) CHARSET utf8
    SQL SECURITY INVOKER
begin

	declare v_key varchar(200);
    set v_key = concat(v_client, '-', v_subjectname);

    if (v_grade = '' or length(v_grade) < 1) then
		return v_key;
	end if;

    return concat(v_key, '-', v_grade);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `testbankkey` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `testbankkey`( 
	v_testkey varchar(250) 
) RETURNS bigint(20)
    SQL SECURITY INVOKER
begin
	
  declare v_bankkey bigint;
    
  select _efk_itembank into v_bankkey 
  from tblsetofadminsubjects S, tblsetofadminitems A, tblitem I
  where S._key = v_testkey and A._fk_adminsubject = S._key and I._key = A._fk_item
  limit 1;

  if (v_bankkey is null) then 
		select efk_itembank into @bankkey 
        from tblsetofadminsubjects S, tblsetofadminitems A, tblitem I
        where S.virtualtest = v_testkey and A._fk_adminsubject = S._key and I._key = A._fk_item
		limit 1;
	end if;

  return  v_bankkey;
  
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `testsubject` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `testsubject`(

	v_testkey varchar(250)
) RETURNS varchar(100) CHARSET utf8
    SQL SECURITY INVOKER
begin

	declare v_result varchar(100);

    set v_result = (select s.`name`
					  from tblsubject s, tblsetofadminsubjects a
					 where a._key = v_testkey and s._key = a._fk_subject);

    return v_result;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `_maketestgradelabel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `_maketestgradelabel`(

	v_testkey varchar(200)
) RETURNS varchar(100) CHARSET utf8
    SQL SECURITY INVOKER
begin

    declare v_result 		varchar(100);
    declare v_grade 		varchar(25);
    declare v_numgrades 	int;
    declare v_numintgrades  int;
    declare v_intgrade 		int;
	declare v_mingrade 		int;
    declare v_maxgrade 		int;

	drop temporary table if exists tmp_grades;

    create temporary table tmp_grades(
		grade varchar(25)
	  , g int
	);

    insert into tmp_grades (grade, g)
    select grade
		 , case when grade regexp'^([+-]?[0-9]+\.?[0-9]*e?[0-9]+)|(0x[0-9A-F]+)$' is not null then cast(grade as unsigned) else null end
      from setoftestgrades 
	 where _fk_adminsubject = v_testkey;

    set v_numgrades 	= (select count(*) from tmp_grades);
    set v_numintgrades  = (select count(*) from tmp_grades where g is not null);

    if (v_numgrades = 0) then return ''; end if;

    if (v_numgrades = 1) then
        select grade, g into v_grade, v_intgrade
		  from tmp_grades;
        
		if (v_intgrade is null) then 
			return v_grade ;
        else 
			return concat('Grade ', v_grade);
		end if;
    end if;
    
    if (v_numintgrades = v_numgrades) then 
	begin
        select min(g), max(g) into v_mingrade, v_maxgrade
		  from tmp_grades;

        if (v_mingrade = 9 and v_maxgrade = 12 and v_numgrades = 4) then 
			return 'High School'; 
		end if;
        if (v_maxgrade - v_mingrade + 1 = v_numintgrades) then
            return concat('Grades ', cast(v_mingrade as char(10)), ' - ', cast(v_maxgrade as char(10)));
		end if;
        
		set v_result = concat('Grades ', cast(v_mingrade as char(10)));

        delete from tmp_grades where g = v_mingrade;

        while (exists (select * from tmp_grades)) do
		begin
            set v_mingrade = (select min(g) from tmp_grades);
            delete from tmp_grades where g = v_mingrade;
            
			set v_result = concat(v_result, ', ', cast(v_mingrade as char(10)));
        end;
		end while;
	
        return v_result;
	end;
	end if;

	set v_grade  = (select min(grade) from tmp_grades);
	set v_result = v_grade;

	delete from tmp_grades where grade = v_grade;

    while (exists (select * from tmp_grades)) do 
	begin
		set v_grade = (select min(grade) from tmp_grades);
        delete from tmp_grades where grade = v_grade;

        set v_result = concat(v_result, ', ', v_grade);
	end;
	end while;

	return v_result;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `_maketestlabel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `_maketestlabel`(

	v_testkey varchar(200)
) RETURNS varchar(100) CHARSET utf8
    SQL SECURITY INVOKER
begin

    declare v_subject varchar(100);
    set v_subject = (select `name`
					   from tblsetofadminsubjects a
					   join tblsubject s on a._fk_subject = s._key
					  where a._key = v_testkey);

    return concat(_maketestgradelabel(v_testkey), ' ', v_subject);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_clear` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_clear`(

	v_packagekey varchar(350)
)
begin

	delete from `loader_measurementparameter`;
    
	delete from `loader_setofitemstrands` where _fk_package = v_packagekey;

	delete from `loader_itemscoredimension` where _fk_package = v_packagekey;
	delete from `loader_itemscoredimensionproperties` where _fk_package = v_packagekey;
	delete from `loader_segment` where _fk_package = v_packagekey;
 	delete from `loader_segmentblueprint` where _fk_package = v_packagekey;
	delete from `loader_segmentform` where _fk_package = v_packagekey;
	delete from `loader_segmentitemselectionproperties` where _fk_package = v_packagekey; 
	delete from `loader_segmentpool` where _fk_package = v_packagekey;
	delete from `loader_segmentpoolgroupitem` where _fk_package = v_packagekey;
	delete from `loader_segmentpoolpassageref` where _fk_package = v_packagekey;
	delete from `loader_testblueprint` where _fk_package = v_packagekey; 
	delete from `loader_testformgroupitems` where _fk_package = v_packagekey;
	delete from `loader_testformitemgroup` where _fk_package = v_packagekey;
	delete from `loader_testformpartition` where _fk_package = v_packagekey;
	delete from `loader_testformproperties` where _fk_package = v_packagekey;
	delete from `loader_testforms` where _fk_package = v_packagekey;
	delete from `loader_testitem` where _fk_package = v_packagekey;
	delete from `loader_testitemrefs` where _fk_package = v_packagekey;
	delete from `loader_testitempoolproperties` where _fk_package = v_packagekey;
	delete from `loader_testpackageproperties` where _fk_package = v_packagekey;
	delete from `loader_testpassages` where _fk_package = v_packagekey;
	delete from `loader_testpoolproperties` where _fk_package = v_packagekey;

	delete from `loader_testpackage` where packagekey = v_packagekey;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_extractxml` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_extractxml`(

	v_xml  longtext
  , out v_testpackagekey varchar(350)
)
proc: begin

    declare errorexit condition for sqlstate '45000'; 

	
	declare v_root    varchar(100);
	declare v_path 	  varchar(100);
	declare v_testkey varchar(150);

	
	declare v_testblueprintpath 	 varchar(300);
	declare v_testpackageproppath 	 varchar(300);
	declare v_testpoolpropertiespath varchar(300);
	declare v_testitempoolpath		 varchar(300);
	declare v_testformpath			 varchar(300);
	declare v_segmentpath			 varchar(300);

	declare v_testblueprintxml	longtext;
	declare v_testitempoolxml	longtext;
	declare v_adminsegxml		longtext;

	declare v_testformcount int;
	declare v_segmentcount  int;

	declare v_counter  int default 1;
	declare v_strindex int default 2;

	
	
	

 	set v_root = 'testspecification/';
 	set v_path = 'testspecification/administration/';
 
	set v_testkey = (extractvalue(v_xml, concat(v_root, 'identifier/attribute::uniqueid')));

	
	set v_testpackagekey = v_testkey;

	if exists (select * from loader_testpackage where packagekey = v_testpackagekey) then
		signal errorexit
			set message_text = 'A record with same packagekey value already exists in the loader_testpackage table.';
		
	end if;
	
	
	insert into loader_testpackage(packagekey, purpose, publisher, publishdate, packageversion, testkey, testname, testlabel, testversion)
	select v_testpackagekey
		 , extractvalue(v_xml, concat(v_root, 'attribute::purpose'))
		 , extractvalue(v_xml, concat(v_root, 'attribute::publisher'))
		 , extractvalue(v_xml, concat(v_root, 'attribute::publishdate'))
		 , extractvalue(v_xml, concat(v_root, 'attribute::version'))
		 , v_testkey
		 , extractvalue(v_xml, concat(v_root, 'identifier/attribute::name'))
		 , extractvalue(v_xml, concat(v_root, 'identifier/attribute::label'))
		 , extractvalue(v_xml, concat(v_root, 'identifier/attribute::version'))
	;

	
		
	
	set v_testpackageproppath = concat(v_root, 'property');
	call loader_testpackageproperties(v_testpackagekey, v_xml, v_testpackageproppath);

	
	set v_testblueprintpath = 'testblueprint/bpelement';
	set v_testblueprintxml = substring(v_xml, locate('<testblueprint>', v_xml), (locate('</testblueprint>', v_xml) - locate('<testblueprint>', v_xml)) + length('</testblueprint>') + 1);
	call loader_testblueprint(v_testpackagekey, v_testblueprintxml, v_testblueprintpath);

	
	set v_testpoolpropertiespath = concat(v_path, 'poolproperty');
	call loader_testpoolproperties(v_testpackagekey, v_xml, v_testpoolpropertiespath);

	
	set v_testitempoolpath = 'itempool/';
	set v_testitempoolxml = substring(v_xml, locate('<itempool>', v_xml), (locate('</itempool>', v_xml) - locate('<itempool>', v_xml)) + length('</itempool>') + 1);
	call loader_testitempool(v_testpackagekey, v_testitempoolxml, v_testitempoolpath);

	
	
	set v_testformpath  = concat(v_path, 'testform');
	set v_testformcount = extractvalue(v_xml, concat('count(', v_testformpath, ')'));

	while v_counter <= v_testformcount do
		call loader_testforms(v_testpackagekey, v_xml, concat(v_testformpath, '[', v_counter, ']'));

		
		set v_counter = v_counter + 1;
	end while;

	
	
	set v_counter = 1;

	set v_segmentpath = concat(v_path, 'adminsegment');
	set v_segmentcount = extractvalue(v_xml, concat('count(', v_segmentpath, ')'));

	while v_counter <= v_segmentcount do
		if v_counter = 1 then 
			set v_adminsegxml = concat('<adminsegment ', substring_index(substring_index(substring_index(v_xml, '<adminsegment', v_strindex), '<adminsegment', -1), '</adminsegment>', 1), '</adminsegment>');
							 
		elseif v_counter = v_segmentcount then 
			set v_adminsegxml = concat(substring_index(substring_index(substring_index(v_xml, '<adminsegment', v_strindex), '</adminsegment>', -2), '</adminsegment>', 1), '</adminsegment>');
		else 
			set v_adminsegxml = substring_index(substring_index(v_xml, '<adminsegment', v_strindex), '</adminsegment>', -2);
		end if;

		call loader_segment(v_testpackagekey, v_adminsegxml, 'adminsegment');

		
		set v_counter = v_counter + 1;
		set v_strindex = v_strindex + 1;

	end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_itemscoredimension` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_itemscoredimension`(

	v_testpackagekey varchar(350)
  ,	v_xml  		 longtext
  , v_path 		 varchar(300)
  , v_testitemid varchar(150)
)
begin

	declare v_isdloop int;
	declare v_isploop int;	
	declare v_isdcounter int default 1;
	declare v_ispcounter int default 1;

	declare v_dimension     varchar(130);
	declare v_measuremodel  varchar(100);
	declare v_scorepoints 	int;
	declare v_weight 		float;

	
	set v_isdloop 		   = extractvalue(v_xml, concat('count(', v_path, ')') );


	while v_isdcounter <= v_isdloop do
	begin

		set v_measuremodel = extractvalue(v_xml, concat(v_path, '[', v_isdcounter, ']/attribute::measurementmodel'));
		set v_dimension    = extractvalue(v_xml, concat(v_path, '[', v_isdcounter, ']/attribute::dimension'));
		set v_scorepoints  = extractvalue(v_xml, concat(v_path, '[', v_isdcounter, ']/attribute::scorepoints'));
		set v_weight 	   = extractvalue(v_xml, concat(v_path, '[', v_isdcounter, ']/attribute::weight'));

		set v_isploop 	   = extractvalue(v_xml, concat('count(', concat(v_path, '[', v_isdcounter, ']/itemscoreparameter'), ')') );
		set v_ispcounter   = 1;
	
		if v_isploop = 0 then
		begin
			
			insert into loader_itemscoredimension (_fk_package, testitemid, measuremodel, dimensionname, scorepoints, weight)
			select v_testpackagekey
				 , v_testitemid
				 , v_measuremodel
				 , v_dimension
				 , v_scorepoints
				 , v_weight
			;
		end;
		else 
		begin
			while v_ispcounter <= v_isploop do
				insert into loader_itemscoredimension (_fk_package, testitemid, measuremodel, dimensionname, scorepoints, weight, measurementparam, measurementvalue)
				select v_testpackagekey
					 , v_testitemid
					 , v_measuremodel
					 , v_dimension
					 , v_scorepoints
					 , v_weight
					 , extractvalue(v_xml, concat(v_path, '[', v_isdcounter, ']', '/itemscoreparameter', '[', v_ispcounter, ']/attribute::measurementparameter'))
					 , extractvalue(v_xml, concat(v_path, '[', v_isdcounter, ']', '/itemscoreparameter', '[', v_ispcounter, ']/attribute::value'))
				;

				
				set v_ispcounter = v_ispcounter + 1;
		   end while;

			
			
			
			

			insert into loader_itemscoredimensionproperties
			select v_testpackagekey
				 , v_testitemid
				 , v_dimension 
				 , extractvalue(v_xml, concat(v_path, '[', v_isdcounter, ']', '/property/attribute::name'))
				 , extractvalue(v_xml, concat(v_path, '[', v_isdcounter, ']', '/property/attribute::value'));

		end;
		end if;
	
		set v_isdcounter = v_isdcounter + 1;
	end;
	end while;





end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_main` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_main`(

	v_xml  longtext
)
begin

	
	declare v_testpackagekey varchar(350);


	call loader_extractxml(v_xml, v_testpackagekey  );
	


	
	
	call load_measurementparameters(NULL);

	update loader_testpackage
	   set clientkey = (select _key from tblclient where `name` = publisher)
	 where packagekey = v_testpackagekey;

	update loader_testpackage tp
	  join tblitembank ib on ib._fk_client = tp.clientkey
	   set tp._efk_itembank = ib._efk_itembank
	 where packagekey = v_testpackagekey;

	update loader_testpackage 
	   set testadmin  = publisher
	 where packagekey = v_testpackagekey;

	update loader_testpackage tp
	  join loader_testpackageproperties	tpp on tpp._fk_package = tp.packagekey and tpp.propname = 'subject'
	   set tp.subjectkey  = concat(tp.publisher, '-', tpp.propvalue)
		 , tp.subjectname = tpp.propvalue
	 where packagekey = v_testpackagekey;

	update loader_testblueprint
	   set treelevel = case when elementtype in ('strand', 'contentlevel') 
							then length(bpelementid) - length(replace(bpelementid, '|', '')) + 1
							else -1 
						end
	 where _fk_package = v_testpackagekey;

	update loader_testpassages
	   set filepath = concat(substring_index(filename, '.', 1), '/')
	 where _fk_package = v_testpackagekey;

	update loader_testitem
	   set filepath = concat(substring_index(filename, '.', 1), '/')
	 where _fk_package = v_testpackagekey;

	update loader_testitemrefs tir
	  join loader_testblueprint tbp on tbp._fk_package = tir._fk_package and tbp.bpelementid = tir.ref and tbp.elementtype <> 'test'
	   set tir.refcategory = tbp.elementtype
		 , tir.treelevel = tbp.treelevel
	 where tir._fk_package = v_testpackagekey;	

	update loader_itemscoredimension dim
	  join measurementmodel m on m.modelname = dim.measuremodel
	   set dim.measuremodelkey = m.modelnumber
	 where _fk_package = v_testpackagekey;

	update loader_itemscoredimension dim
	  join measurementparameter mp on mp._fk_measurementmodel = dim.measuremodelkey and mp.parmname = dim.measurementparam
	   set dim.measurementparamnum = mp.parmnum
	 where _fk_package = v_testpackagekey;


	



	

				

	call load_subject(v_testpackagekey);
	call load_strands(v_testpackagekey);
	
	call load_stimuli(v_testpackagekey);
	call load_items(v_testpackagekey);

	call load_linkitemstostrands(v_testpackagekey);
	call load_linkitemstostimuli(v_testpackagekey);
	call load_itemproperties(v_testpackagekey);

	
	call load_testadmin(v_testpackagekey);
	call load_adminsubjects(v_testpackagekey);
	call load_adminstrands(v_testpackagekey);
	call load_adminitems(v_testpackagekey);

	call load_adminitemmeasurementparms(v_testpackagekey);
	call load_adminStimuli(v_testpackagekey);
	call load_adminforms(v_testpackagekey);
	call load_adminformitems(v_testpackagekey);
	call load_affinitygroups(v_testpackagekey);

	
	
 	call updatetdsconfigs(v_testpackagekey);


	
	call loader_clear(v_testpackagekey);


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_segment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_segment`(

	v_testpackagekey varchar(350)
  ,	v_xml  	longtext
  , v_path 	varchar(300)
)
begin
	declare v_counter				int default 1;
	declare v_segmentid 			varchar(250);
	declare v_itemselectorid 		varchar(200);
	declare v_itemselectortype		varchar(50);
	declare v_segmentblueprintpath 	varchar(300);
	declare v_segmentblueprintcount int;
	
	
	set v_segmentid 	   = extractvalue(v_xml, concat(v_path, '/attribute::segmentid'));
	set v_itemselectorid   = extractvalue(v_xml, concat(v_path, '/itemselector/identifier/attribute::uniqueid'));
	set v_itemselectortype = extractvalue(v_xml, concat(v_path, '/itemselector/attribute::type'));

	insert into loader_segment(_fk_package, segmentid, position, itemselection, itemselectortype, itemselectorid, itemselectorname, itemselectorlabel, version)
	select v_testpackagekey
		 , v_segmentid
		 , extractvalue(v_xml, concat(v_path, '/attribute::position'))
		 , extractvalue(v_xml, concat(v_path, '/attribute::itemselection'))
		 , v_itemselectortype
		 , v_itemselectorid
		 , extractvalue(v_xml, concat(v_path, '/itemselector/identifier/attribute::name'))
		 , extractvalue(v_xml, concat(v_path, '/itemselector/identifier/attribute::label'))
		 , extractvalue(v_xml, concat(v_path, '/itemselector/identifier/attribute::version'))
	;

	
	set v_segmentblueprintpath = concat(v_path, '/segmentblueprint/segmentbpelement');
	call loader_segmentblueprint (v_testpackagekey, v_xml, v_segmentblueprintpath, v_segmentid);

	
	
	
	set v_segmentblueprintpath  = concat(v_path, '/itemselector/itemselectionparameter');
	set v_segmentblueprintcount = extractvalue(v_xml, concat('count(', v_segmentblueprintpath, ')'));

	while v_counter <= v_segmentblueprintcount do
		call loader_segmentitemselectionproperties(v_testpackagekey, v_xml, concat(v_segmentblueprintpath, '[', v_counter, ']'), v_segmentid, v_itemselectorid);

		
		set v_counter = v_counter + 1;
	end while;


	if (v_itemselectortype like 'adaptive%') then
		call loader_segmentpool(v_testpackagekey, v_xml, concat(v_path, '/segmentpool/itemgroup'), v_segmentid);
	end if;

	if (v_itemselectortype = 'fixedform') then
		call loader_segmentform(v_testpackagekey, v_xml, concat(v_path, '/segmentform'), v_segmentid);
	end if;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_segmentblueprint` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_segmentblueprint`(

	v_testpackagekey varchar(350)
  ,	v_xml  		longtext
  , v_path 		varchar(300)
  , v_segmentid varchar(250)
)
begin

	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		insert into loader_segmentblueprint(_fk_package, segmentid, segmentbpelementid, minopitems, maxopitems)
		select v_testpackagekey
			 , v_segmentid
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::bpelementid'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::minopitems'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::maxopitems'))
		;

		
		set v_counter = v_counter + 1;
	end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_segmentform` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_segmentform`(

	v_testpackagekey varchar(350)
  ,	v_xml  		longtext
  , v_path 		varchar(300)
  , v_segmentid varchar(250)
)
begin

	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		insert into loader_segmentform (_fk_package, segmentid, formpartitionid)
		select v_testpackagekey
			 , v_segmentid
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::formpartitionid'))
		;

		
		set v_counter = v_counter + 1;

	end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_segmentitemselectionproperties` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_segmentitemselectionproperties`(

	v_testpackagekey varchar(350)
  ,	v_xml  			 longtext
  , v_path 			 varchar(300)
  , v_segmentid 	 varchar(250)
  , v_itemselectorid varchar(200)
)
begin

	declare v_loop 	  	  int;
	declare v_counter 	  int default 1;
	declare v_bpelementid varchar(250);

	
	
	set v_bpelementid = extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::bpelementid'));

	
	set v_path = concat(v_path, '/property');
	set v_loop = extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		insert into loader_segmentitemselectionproperties(_fk_package, segmentid, itemselectorid, bpelementid, propname, propvalue, proplabel)
		select v_testpackagekey
			 , v_segmentid
			 , v_itemselectorid
			 , v_bpelementid
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::name'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::value'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::label'))
		;

		
		set v_counter = v_counter + 1;
	end while;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_segmentpool` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_segmentpool`(

	v_testpackagekey varchar(350)
  ,	v_xml  			 longtext
  , v_path 			 varchar(300)
  , v_segmentid 	 varchar(250)
)
begin

	declare v_loop 	  	    int;
	declare v_counter 	    int default 1;
	declare v_itemgroupid   varchar(100);
	declare v_groupitempath varchar(300);

	
	set v_loop = extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		set v_itemgroupid = extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::uniqueid'));
		
		insert into loader_segmentpool(_fk_package, segmentid, itemgroupid, itemgroupname, maxitems, maxresponses, version)
		select v_testpackagekey
			 , v_segmentid
			 , v_itemgroupid
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::name'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::maxitems'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::maxresponses'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::version'))
		;
		
		
		
		insert into loader_segmentpoolpassageref (_fk_package, segmentid, itemgroupid, passageid)
		select v_testpackagekey
			 , v_segmentid
			 , v_itemgroupid
             , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/passageref'))
		;

		
		
		
		set v_groupitempath = concat(v_path, '[', v_counter, ']/groupitem');
		call loader_segmentpoolgroupitem (v_testpackagekey, v_xml, v_groupitempath, v_segmentid, v_itemgroupid);
		
		
		set v_counter = v_counter + 1;

	end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_segmentpoolgroupitem` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_segmentpoolgroupitem`(

	v_testpackagekey varchar(350)
  ,	v_xml  		  longtext
  , v_path 		  varchar(300)
  , v_segmentid   varchar(250)
  , v_itemgroupid varchar(100)
)
begin

	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop = extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do		
		insert into loader_segmentpoolgroupitem(_fk_package, segmentid, itemgroupid, groupitemid, groupposition, adminrequired, responserequired, isfieldtest, isactive, blockid)
		select v_testpackagekey
			 , v_segmentid
			 , v_itemgroupid
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::itemid'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::groupposition'))
			 , case extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::adminrequired'))
					when 'true' then 1
					when 'false' then 0
			   end 
			 , case extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::responserequired'))
					when 'true' then 1
					when 'false' then 0
			   end 
			 , case extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::isfieldtest'))
					when 'true' then 1
					when 'false' then 0
			   end 
			 , case extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::isactive'))
					when 'true' then 1
					when 'false' then 0
			   end 
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::blockid'))
		;

		
		set v_counter = v_counter + 1;

 	end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testblueprint` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testblueprint`(

	v_testpackagekey varchar(350)
  ,	v_xml  			 longtext
  , v_path 			 varchar(300)
)
begin
    
	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		insert into loader_testblueprint (_fk_package, elementtype, bpelementid, bpelementname, minopitems, maxopitems, minftitems, maxftitems, opitemcount, ftitemcount, parentid, version)
		select v_testpackagekey
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::elementtype'))
             , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::uniqueid'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::name'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::minopitems'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::maxopitems'))
			 , case when extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::minftitems')) = '' then 0 else extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::minftitems')) end
			 , case when extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::maxftitems')) = '' then 0 else extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::maxftitems')) end
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::opitemcount'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::ftitemcount'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::parentid'))
             , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::version'))
		;
		
		
		set v_counter = v_counter + 1;

   end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testformgroupitems` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testformgroupitems`(

	v_testpackagekey  varchar(350)
  ,	v_xml  		 	  longtext
  , v_path 		 	  varchar(300)
  , v_testformid 	  varchar(200)
  , v_formitemgroupid varchar(200)
  , INOUT v_sequentiallyformposition int
)
begin
    
	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		insert into loader_testformgroupitems (_fk_package, testformid, formitemgroupid, itemid, formposition, groupposition, adminrequired, responserequired, isactive, isfieldtest, blockid)
		select v_testpackagekey
			 , v_testformid
			 , v_formitemgroupid
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::itemid'))
			 
			 , v_sequentiallyformposition 
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::groupposition'))
			 , case extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::adminrequired'))
					when 'true' then 1
					when 'false' then 0
			   end 
			 , case extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::responserequired'))
					when 'true' then 1
					when 'false' then 0
			   end 
			 , case extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::isactive'))
					when 'true' then 1
					when 'false' then 0
			   end 
			 , case extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::isfieldtest'))
					when 'true' then 1
					when 'false' then 0
			   end 
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::blockid')) 
		;

		
		set v_counter = v_counter + 1;

		set v_sequentiallyformposition = v_sequentiallyformposition + 1;

	end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testformitemgroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testformitemgroup`(

	v_testpackagekey varchar(350)
  ,	v_xml  		 longtext
  , v_path 		 varchar(300)
  , v_testformid varchar(200)
  , v_formpartitionid varchar(200)
)
begin
    
	declare v_loop 	  int;
	declare v_counter int default 1;
	declare v_formitemgroupid varchar(200);
	declare v_sequentiallyformposition int default 1;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		set v_formitemgroupid = extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::uniqueid'));
		
		insert into loader_testformitemgroup(_fk_package, testformid, formpartitionid, formitemgroupid, formitemgroupname, version, formposition, maxitems, maxresponses, passageid)
		select v_testpackagekey
			 , v_testformid
			 , v_formpartitionid
			 , v_formitemgroupid
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::name'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::version'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::formposition'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::maxitems'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::maxresponses'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/passageref'))
		;

		
		
		call loader_testformgroupitems(v_testpackagekey, v_xml, concat(v_path, '[', v_counter, ']/groupitem'), v_testformid, v_formitemgroupid, v_sequentiallyformposition);

		
		set v_counter = v_counter + 1;

	end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testformpartition` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testformpartition`(

	v_testpackagekey varchar(350)
  ,	v_xml  		 longtext
  , v_path 		 varchar(300)
  , v_testformid varchar(200)
)
begin
    
	declare v_loop 	  int;
	declare v_counter int default 1;
	declare v_formpartitionid varchar(200);

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		set v_formpartitionid = extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::uniqueid'));

		insert into loader_testformpartition (_fk_package, testformid, formpartitionid, formpartitionname, version)
		select v_testpackagekey
			 , v_testformid
			 , v_formpartitionid
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::name'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::version'))
		;





		
		call loader_testformitemgroup(v_testpackagekey, v_xml, concat(v_path, '[', v_counter, ']/itemgroup'), v_testformid, v_formpartitionid);

		
		set v_counter = v_counter + 1;

	end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testformproperties` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testformproperties`(

	v_testpackagekey varchar(350)
  ,	v_xml  		 longtext
  , v_path 		 varchar(300)
  , v_testformid varchar(200)
  , v_ispool 	 bit
)
begin
    
	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		insert into loader_testformproperties (_fk_package, testformid, ispool, propname, proplabel, propvalue, itemcount)
		select v_testpackagekey
			 , v_testformid
             , v_ispool
			 
			 , case when v_ispool = 0 
					then extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::name'))
					else extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::property'))
				end
             , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::label'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::value'))
			
			 , case when v_ispool = 0 
					then null	
					else extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::itemcount'))
				end
		;

		
		set v_counter = v_counter + 1;

	end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testforms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testforms`(

	v_testpackagekey varchar(350)
  ,	v_xml  longtext
  , v_path varchar(300)
)
begin
    
	declare v_testformid varchar(200);
	declare v_testformpropertiespath varchar(300);
	declare v_testformpartitionpath	 varchar(300);

	set v_testformid = extractvalue(v_xml, concat(v_path, '/identifier/attribute::uniqueid'));

	insert into loader_testforms (_fk_package, testformid, testformname, testformlength, version)
	select v_testpackagekey
		 , v_testformid
	     , extractvalue(v_xml, concat(v_path, '/identifier/attribute::name'))
		 , extractvalue(v_xml, concat(v_path, '/attribute::length'))
		 , extractvalue(v_xml, concat(v_path, '/identifier/attribute::version'))
	;

	
	
	
	set v_testformpropertiespath  = concat(v_path, '/property');
	call loader_testformproperties (v_testpackagekey, v_xml, v_testformpropertiespath, v_testformid, 0);

	
	
	set v_testformpropertiespath  = concat(v_path, '/poolproperty');
	call loader_testformproperties (v_testpackagekey, v_xml, v_testformpropertiespath, v_testformid, 1);

	
	set v_testformpartitionpath = concat(v_path, '/formpartition');
	call loader_testformpartition (v_testpackagekey, v_xml, v_testformpartitionpath, v_testformid);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testitem` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testitem`(

	v_testpackagekey varchar(350)
  ,	v_xml  			 longtext
  , v_path 			 varchar(300)
)
begin
    
	declare v_loop 	   		int;
	declare v_counter  		int default 1;
	declare v_strindex 		int default 2;
	declare v_testitemid 	varchar(150);
	declare v_testitemxml 	longtext;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );
	set v_path = 'testitem';

	while v_counter <= v_loop do

		if v_counter = 1 then 
			set v_testitemxml = substring_index(substring_index(v_xml, '<testitem', v_strindex), '<itempool>', -1);
		elseif v_counter = v_loop then 
			set v_testitemxml = substring_index(substring_index(substring_index(v_xml, '<testitem', v_strindex), '</testitem>', -2), '</itempool>', 1);
		else 
			set v_testitemxml = substring_index(substring_index(v_xml, '<testitem', v_strindex), '</testitem>', -2);
		end if;

		
		set v_testitemid = (extractvalue(v_testitemxml, concat(v_path, '/identifier/attribute::uniqueid')));

		insert into loader_testitem (_fk_package, filename, itemtype, testitemid, testitemname, version)
		select v_testpackagekey
			 , extractvalue(v_testitemxml, concat(v_path, '/attribute::filename'))
             , extractvalue(v_testitemxml, concat(v_path, '/attribute::itemtype'))
			 , v_testitemid
             , extractvalue(v_testitemxml, concat(v_path, '/identifier/attribute::name'))
			 , extractvalue(v_testitemxml, concat(v_path, '/identifier/attribute::version'))
		;

		call loader_testitemrefs (v_testpackagekey, v_testitemxml, 'bp', concat(v_path, '/bpref'), v_testitemid);
		call loader_testitemrefs (v_testpackagekey, v_testitemxml, 'passage', concat(v_path, '/passageref'), v_testitemid);
		call loader_testitempoolproperties (v_testpackagekey, v_testitemxml, concat(v_path, '/poolproperty'), v_testitemid);
		call loader_itemscoredimension (v_testpackagekey, v_testitemxml, concat(v_path, '/itemscoredimension'), v_testitemid);

		
		set v_counter = v_counter + 1;
		set v_strindex = v_strindex + 1;

	end while;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testitempool` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testitempool`(

	v_testpackagekey varchar(350)
  ,	v_xml  			 longtext
  , v_path 			 varchar(300)
)
begin
    
	declare v_testpassages varchar(300);
	declare v_testitem varchar(300);

	
	set v_testpassages = concat(v_path, 'passage');
	call loader_testpassages(v_testpackagekey, v_xml, v_testpassages);

	set v_testitem = concat(v_path, 'testitem');
	call loader_testitem(v_testpackagekey, v_xml, v_testitem);


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testitempoolproperties` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testitempoolproperties`(

	v_testpackagekey varchar(350)
  ,	v_xml  		 longtext
  , v_path 		 varchar(300)
  , v_testitemid varchar(150)
)
begin
    
	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );


	while v_counter <= v_loop do
		insert into loader_testitempoolproperties (_fk_package, testitemid, propname, propvalue, proplabel)
		select v_testpackagekey
			 , v_testitemid
             , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::property'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::value'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::label'))
		;
		
		
		set v_counter = v_counter + 1;

   end while;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testitemrefs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testitemrefs`(

	v_testpackagekey varchar(350)
  ,	v_xml  		 longtext
  , v_reftype    varchar(100)
  , v_path 		 varchar(300)
  , v_testitemid varchar(150)
)
begin

	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop = extractvalue(v_xml, concat('count(', v_path, ')'));

	while v_counter <= v_loop do
		
		insert into loader_testitemrefs (_fk_package, testitemid, reftype, ref)
		select v_testpackagekey
			 , v_testitemid
			 , v_reftype
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']'));

		
		set v_counter = v_counter + 1;

	end while;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testpackageproperties` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testpackageproperties`(

	v_testpackagekey varchar(350)
  ,	v_xml  	  		 longtext
  , v_path 	  		 varchar(300)
)
begin

	declare v_loop		int;
	declare v_counter	int default 1;

	
	set v_loop = extractvalue(v_xml, concat('count(', v_path, ')'));

	while v_counter <= v_loop do
		insert into loader_testpackageproperties (_fk_package, propname, propvalue, proplabel)
		select v_testpackagekey
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::name'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::value'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::label'))
		;

		
		set v_counter = v_counter + 1;
	end while;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testpassages` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testpassages`(

	v_testpackagekey varchar(350)
  ,	v_xml  			 longtext
  , v_path 			 varchar(300)
)
begin
    
	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		insert into loader_testpassages (_fk_package, filename, passageid, passagename, version)
		select v_testpackagekey
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::filename'))
             , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::uniqueid'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::name'))
             , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/identifier/attribute::version'))
		;
		
		
		set v_counter = v_counter + 1;
   end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testpoolproperties` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testpoolproperties`(

	v_testpackagekey varchar(350)
  ,	v_xml  			 longtext
  , v_path 			 varchar(300)
)
begin
    
	declare v_loop 	  int;
	declare v_counter int default 1;

	
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	while v_counter <= v_loop do
		insert into loader_testpoolproperties (_fk_package, propname, propvalue, proplabel, itemcount)
		select v_testpackagekey
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::property'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::value'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::label'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::itemcount'))
		;
		
		
		set v_counter = v_counter + 1;
   end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_testproperties` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_testproperties`(
	v_xml  longtext)
begin
    
	declare v_loop 	  int;
	declare v_counter int;
	declare v_path     varchar(500);
	declare v_uniqueid varchar(170);

	set v_path = 'testspecification/complete/poolproperty';
	set v_loop =  extractvalue(v_xml, concat('count(', v_path, ')') );

	
	set v_uniqueid = (extractvalue(v_xml, 'testspecification/identifier/attribute::uniqueid'));

	
	set v_counter = 1;

	while v_counter <= v_loop do
		insert into loader_testproperties (propertyname, propertyvalue, label, itemcount, uniqueid)
		select extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::property'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::value'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::label'))
			 , extractvalue(v_xml, concat(v_path, '[', v_counter, ']/attribute::itemcount'))
			 , v_uniqueid
		;
		
		
		set v_counter = v_counter + 1;
   end while;


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `loader_validate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `loader_validate`(

	v_testpackagekey varchar(350)
)
begin

	create temporary table tmp_errormsgs (
		packagekey varchar(350)
	  , severity   varchar(20)
	  
	  , err  	   text
	);

	create temporary table tmp_items (
		test varchar(100)
	  , obj  varchar(100)
	  , cnt  int
	  , req  int
	  , mn	 float
	  , mx	 float
	);

	insert into tmp_errormsgs
	select v_testpackagekey
		 , 'FATAL ERROR'
		 , 'Test package with purpose = administration can be used to load test data.' 
	  from loader_testpackage
	 where packagekey = v_testpackagekey
	   and purpose <> 'administration';
	
	insert into tmp_errormsgs
	select v_testpackagekey
		 , 'FATAL ERROR'
		 , 'Blank or NULL TestName/TestKey in loader_testpackage' 
	  from loader_testpackage
	 where packagekey = v_testpackagekey
	   and ((testname is null and testname <> '')
			or (testkey is null and testkey <> ''));
	
	insert into tmp_errormsgs
	select v_testpackagekey
		 , 'FATAL ERROR'
		 , 'Tespackage property name/value field cannot be null or blank' 
	  from loader_testpackageproperties
	 where _fk_package = v_testpackagekey
	   and ((propname is NULL and propname <> '')
			or (propvalue is NULL and propvalue <> ''));

	if exists (select count(*) cnt from loader_testpackageproperties
				where _fk_package = v_testpackagekey and propname = 'subject' 
				group by _fk_package) = 0
	then 
		insert into tmp_errormsgs 
		select v_testpackagekey, 'FATAL ERROR', 'Atleast one subject property must be present for a given test';
	end if;

	if exists (select count(*) cnt from loader_testpackageproperties
				where _fk_package = v_testpackagekey and propname = 'grade' 
				group by _fk_package) = 0
	then 
		insert into tmp_errormsgs 
		select v_testpackagekey, 'FATAL ERROR', 'Atleast one gradelevel property must be present for a given test';
	end if;

	
	delete from tmp_items;
	insert into tmp_items (obj)
	select propvalue
	  from loader_testpackageproperties
	 where _fk_package = v_testpackagekey 
	   and propname = 'grade' 
	   and isnumeric(propvalue) = 0;
	
	if exists(select * from tmp_items) then
		insert into tmp_errormsgs
		select v_testpackagekey, 'WARNING', concat(obj, ': ', 'Test has a non-numeric grade')
		  from tmp_items;
	end if;


	
	if exists (select * from loader_testblueprint
				where _fk_package = v_testpackagekey and elementtype not in ('test', 'segment', 'affinitygroup', 'strand', 'contentlevel') )
	then 
		insert into tmp_errormsgs 
		select v_testpackagekey, 'FATAL ERROR', 'Invalid test blueprint element type';
	end if;


	delete from tmp_items;
	insert into tmp_items (obj)
	select distinct bpelementid
	  from loader_testblueprint
	 where _fk_package = v_testpackagekey and elementtype = 'test';

	if exists (select count(*) from tmp_items) > 1 then
		insert into tmp_errormsgs
		select v_testpackagekey, 'FATAL ERROR', 'Only one test should be present per test package';
	end if;


	delete from tmp_items;
	insert into tmp_items (obj, cnt)
	select bpelementid, count(*)
	  from loader_testblueprint
	 where _fk_package = v_testpackagekey and elementtype = 'segment'
	group by bpelementid;

	if exists (select * from tmp_items where cnt > 1) then
		insert into tmp_errormsgs
		select v_testpackagekey, 'FATAL ERROR', concat('Duplicate segment ID: ', obj)
		  from tmp_items;
	end if;

	delete from tmp_items;
	insert into tmp_items (obj, cnt)
	select bpelementid, count(*)
	  from loader_testblueprint
	 where _fk_package = v_testpackagekey and elementtype = 'strand'
	group by bpelementid;

	if exists (select * from tmp_items where cnt > 1) then
		insert into tmp_errormsgs
		select v_testpackagekey, 'FATAL ERROR', concat('Duplicate strand ID: ', obj)
		  from tmp_items;
	end if;


	delete from tmp_items;
	insert into tmp_items (obj, cnt)
	select bpelementid, count(*)
	  from loader_testblueprint
	 where _fk_package = v_testpackagekey and elementtype = 'contentlevel'
	group by bpelementid;

	if exists (select * from tmp_items where cnt > 1) then
		insert into tmp_errormsgs
		select v_testpackagekey, 'FATAL ERROR', concat('Duplicate content level ID: ', obj)
		  from tmp_items;
	end if;


	delete from tmp_items;
	insert into tmp_items (obj, cnt)
	select bpelementid, count(*)
	  from loader_testblueprint
	 where _fk_package = v_testpackagekey and elementtype = 'affinitygroup'
	group by bpelementid;

	if exists (select * from tmp_items where cnt > 1) then
		insert into tmp_errormsgs
		select v_testpackagekey, 'FATAL ERROR', concat('Duplicate affinity group ID: ', obj)
		  from tmp_items;
	end if;


	
	if exists (select * from loader_testblueprint
				where _fk_package = v_testpackagekey and elementtype = 'test' 
				  and (minopitems > maxopitems or minftitems > maxftitems) )
	then 
		insert into tmp_errormsgs 
		select v_testpackagekey, 'FATAL ERROR', 'Test has min items > max items, operational or field test';
	end if;

	if exists (select * from loader_testblueprint
				where _fk_package = v_testpackagekey and elementtype = 'segment' 
				  and (minopitems > maxopitems or minftitems > maxftitems) )
	then 
		insert into tmp_errormsgs 
		select v_testpackagekey, 'FATAL ERROR', 'Segment has min items > max items, operational or field test';
	end if;

	if exists (select * from loader_testblueprint
				where _fk_package = v_testpackagekey and elementtype = 'strand' 
				  and minopitems > maxopitems )
	then 
		insert into tmp_errormsgs 
		select v_testpackagekey, 'FATAL ERROR', 'Strand has min items > max items';
	end if;

	if exists (select * from loader_testblueprint
				where _fk_package = v_testpackagekey and elementtype = 'contentlevel' 
				  and minopitems > maxopitems )
	then 
		insert into tmp_errormsgs 
		select v_testpackagekey, 'FATAL ERROR', 'Content level has min items > max items';
	end if;

	if exists (select * from loader_testblueprint
				where _fk_package = v_testpackagekey and elementtype = 'affinitygroup' 
				  and minopitems > maxopitems )
	then 
		insert into tmp_errormsgs 
		select v_testpackagekey, 'FATAL ERROR', 'Affinity group has min items > max items';
	end if;


	insert into tmp_errormsgs
	select v_testpackagekey, 'FATAL ERROR', concat('Content level is missing parent id: ', parentid)
	  from loader_testblueprint
	 where _fk_package = v_testpackagekey and elementtype = 'contentlevel' 
	   and (parentid is null or parentid = '');

	insert into tmp_errormsgs
	select v_testpackagekey, 'FATAL ERROR', concat('Parent blue print element id does not exist: ', bp1.bpelementid)	
	  from loader_testblueprint bp1
	  left join loader_testblueprint bp2 on bp2.bpelementid = bp1.parentid 
										and bp2._fk_package = bp1._fk_package
	 where bp1._fk_package = v_testpackagekey
	   and bp1.elementtype = 'contentlevel' 
	   and bp2.bpelementid is null;



	


end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_adminformitems` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_adminformitems`(

	v_testpackagekey varchar(350)
)
begin

	drop temporary table if exists tmp_formitem;
	create temporary table tmp_formitem (
		select fgi.itemid
			 , coalesce(substring_index(tfp.formpartitionid, '-', -1), 0)		as itsformkey
			 , fgi.formposition
			 , sf.segmentid 		as adminsubject
			 , tfp.formpartitionid
			 , fgi.isactive
		  from loader_testforms tf 
		  join loader_testformpartition tfp on tfp.testformid = tf.testformid
										   and tfp._fk_package = tf._fk_package	 	
		  join loader_testformitemgroup tfig on tfig.testformid = tfp.testformid
											and tfig.formpartitionid = tfp.formpartitionid
										    and tfig._fk_package = tfp._fk_package	 	
		  join loader_testformgroupitems fgi on fgi.testformid = tfig.testformid
									        and fgi.formitemgroupid = tfig.formitemgroupid
											and fgi._fk_package = tfig._fk_package 
		  join loader_segmentform sf on sf.formpartitionid = tfp.formpartitionid
									and sf._fk_package = tfp._fk_package
		 where tf._fk_package = v_testpackagekey
	);

	insert into testformitem(_fk_item, _efk_itsformkey, formposition, _fk_adminsubject, _fk_testform, isactive)
	select distinct *
	  from tmp_formitem tmp
	 where not exists (select 1
						 from testformitem tfi
						where tmp.itemid = tfi._fk_item and tmp.formposition = tfi.formposition and tmp.formpartitionid = tfi._fk_testform and tmp.adminsubject = tfi._fk_adminsubject);


	update testformitem tfi
	  join tmp_formitem tmp on tmp.itemid = tfi._fk_item and tmp.formposition = tfi.formposition and tmp.formpartitionid = tfi._fk_testform and tmp.adminsubject = tfi._fk_adminsubject
	   set tfi.isactive = tmp.isactive;


	
	drop temporary table tmp_formitem;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_adminforms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_adminforms`(

	v_testpackagekey varchar(350)
)
begin

	
	
	drop temporary table if exists tmp_testform;
	create temporary table tmp_testform (
		select sf.segmentid				as adminsubject		
			 , coalesce(substring_index(substring_index(tfp.testformid, ':', -1), '-', 1), 'Default') 	as cohort
			 , prop.propvalue			as lang				
			 , tfp.formpartitionid
			 , tfp.formpartitionname
			 , coalesce(substring_index(tfp.formpartitionid, '-', -1), pkg._efk_itembank)	as itsbankkey 
			 , coalesce(substring_index(tfp.formpartitionid, '-', -1), 0)					as itskey 			 
			 , tfp.version
		  from loader_testpackage pkg 
		  join loader_testformpartition tfp on tfp._fk_package = pkg.packagekey
		  join loader_segmentform sf on sf.formpartitionid = tfp.formpartitionid
									and sf._fk_package = tfp._fk_package
		  left join loader_testformproperties prop on prop.testformid = tfp.testformid
												  and prop._fk_package = tfp._fk_package
		 where prop.propname = 'language'
		   and prop.ispool = 0
		   and tfp._fk_package = v_testpackagekey
	);


	
	
	delete tf
	  from testform tf
	  join tmp_testform tmp on tmp.adminsubject = tf._fk_adminsubject
	 where not exists (select * from loader_testformpartition tfp where tfp._fk_package = v_testpackagekey and tfp.formpartitionid = tf._key);


	
	update testform tf
	  join tmp_testform tmp on tf._fk_adminsubject = tmp.adminsubject 
						   and tf._key = tmp.formpartitionid
	   set tf.cohort = tmp.cohort 
		 , tf.`language` = tmp.lang
		 , tf.formid = tmp.formpartitionname
		 , tf.updateconfig = tmp.version; 


	
	insert into testform (_fk_adminsubject, cohort, `language`, _key, formid, _efk_itsbank, _efk_itskey, loadconfig)
	select *
	  from tmp_testform tmp
	 where not exists (select 1 
						 from testform tf
						where tf._fk_adminsubject = tmp.adminsubject 
						  and tf._key = tmp.formpartitionid);
		
	
	
	
	
	
	
	

	
	drop temporary table tmp_testform;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_adminitemmeasurementparms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_adminitemmeasurementparms`(

	v_testpackagekey varchar(350)
)
begin

	drop temporary table if exists tmp_itemdimension;
	create temporary table tmp_itemdimension (
		  _key 					varbinary(16)
		, _fk_adminsubject 		varchar(250) 
		, _fk_item 				varchar(150)
		, _fk_measurementmodel  int 
		, dimension				varchar(255)
		, recoderule			varchar(255)
		, scorepoints 			int
		, weight 				float
	)engine = memory;

	insert into tmp_itemdimension (_fk_adminsubject, _fk_item, _fk_measurementmodel, scorepoints, weight, dimension, recoderule)
	select distinct ais._fk_adminsubject
		 , ais._fk_item
		 , measuremodelkey
		 , isd.scorepoints
		 , isd.weight
		 , case when isd.dimensionname is null then '' else isd.dimensionname end
		 , case when prop.propvalue is null then '' else prop.propvalue end 
	  from loader_setofitemstrands ais
	  join loader_itemscoredimension isd on isd._fk_package = ais._fk_package 
										and isd.testitemid = ais._fk_item
	  left join loader_itemscoredimensionproperties prop on prop._fk_package = isd._fk_package
														and prop.testitemid = isd.testitemid 
														and prop.dimensionname = isd.dimensionname
														and propname = 'recoderule'
     where isd._fk_package = v_testpackagekey;

	
	update tmp_itemdimension
	set _key = unhex(REPLACE(UUID(), '-', '')); 
	
	

	
	
	delete isd
	  from itemscoredimension  isd
	 where exists (select * 
				     from tmp_itemdimension id
					where id._fk_item = isd._fk_item and id._fk_adminsubject = isd._fk_adminsubject);

	
    insert into itemscoredimension (_key, _fk_item, _fk_adminsubject, dimension, scorepoints, weight, _fk_measurementmodel, recoderule)
    select _key
		 , _fk_item
		 , _fk_adminsubject
		 , dimension
		 , scorepoints
		 , weight
		 , coalesce(_fk_measurementmodel, 0)
		 , recoderule
    from tmp_itemdimension;

	insert into itemmeasurementparameter
	select distinct _key
		 , measurementparamnum
		 , measurementvalue
	  from loader_setofitemstrands ais
	  join loader_itemscoredimension isd on isd._fk_package = ais._fk_package 
										and isd.testitemid = ais._fk_item
	  join tmp_itemdimension id on id._fk_item = isd.testitemid 
							   and id._fk_adminsubject = ais._fk_adminsubject
							   and id.dimension = isd.dimensionname
	 where isd._fk_package = v_testpackagekey
	   and (measurementparamnum is not null or measurementvalue is not null);


    update tblsetofadminitems 
	   set bvector = coalesce(itembvector(_fk_adminsubject, _fk_item), irt_b)
     where _fk_adminsubject in (select distinct _fk_adminsubject from tmp_itemdimension);




































	
	drop temporary table tmp_itemdimension;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_adminitems` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_adminitems`(

	v_testpackagekey varchar(350)
)
begin
	
	drop temporary table if exists tmp_adminitems;
	create temporary table tmp_adminitems (
		_fk_item varchar(150)
	  , _fk_adminsubject varchar(250)
	  , groupid varchar(100)
	  , itemposition int(11)
	  , isfieldtest bit(1)
	  , isactive bit(1)
	  , blockid varchar(10)
	  , isrequired bit(1)
	  , _fk_testadmin varchar(150)
	  , _fk_strand varchar(150)
	  , groupkey varchar(100)
	  , strandname varchar(150)
	  , irt_a float
	  , irt_b varchar(150)
	  , irt_c float
	  , irt_model varchar(100)
	  , clstring text
	  , version bigint
	);

	drop temporary table if exists tmp_irt;
	create temporary table tmp_irt (
		testitemid	varchar(150)
	  , measuremodel varchar(100)
	  , irt_a float
	  , irt_b varchar(150)
	  , irt_c float
	)engine = memory;


	
	insert into tmp_adminitems (_fk_item, _fk_adminsubject, _fk_testadmin, _fk_strand, strandname, version)
	select _fk_item
		 , _fk_adminsubject
		 , tp.testadmin
		 , _fk_strand
		 , tir.ref
		 , s.version
	  from loader_setofitemstrands s
	  join loader_testitemrefs tir on tir.testitemid = s._fk_item 
								  and tir._fk_package = s._fk_package
	  join loader_testpackage tp on tp.packagekey = s._fk_package
	 where tir.refcategory = 'strand' 
	   and s._fk_package = v_testpackagekey;

	
	insert into tmp_irt
	select testitemid
		 , measuremodel
		 , max(case when measurementparam = 'a' then measurementvalue else null end) 
		 , avg(case when measurementparam like 'b%' then measurementvalue else null end)
		 , max(case when measurementparam = 'c' then measurementvalue else null end)
	  from loader_itemscoredimension
	 where _fk_package = v_testpackagekey
	group by testitemid, measuremodel;


	
	update tmp_adminitems ai
	  join tmp_irt irt on irt.testitemid = ai._fk_item
	   set ai.irt_model = irt.measuremodel
		 , ai.irt_a = coalesce(irt.irt_a, 1)
		 , ai.irt_b = coalesce(irt.irt_b, -9999)
		 , ai.irt_c = coalesce(irt.irt_c, 0)
	;
  
	
	update tmp_adminitems ai
	  join loader_testformgroupitems l on l.itemid = ai._fk_item
	   set ai.groupid 		= substring_index(formitemgroupid, ':', -1)
		 , ai.itemposition 	= l.groupposition
		 , ai.isfieldtest 	= l.isfieldtest
		 , ai.isactive 		= l.isactive
		 , ai.blockid 		= l.blockid
		 , ai.isrequired    = l.responserequired
		 , ai.groupkey		= concat(substring_index(formitemgroupid, ':', -1), '_', l.blockid)
	 where _fk_package = v_testpackagekey;


	update tmp_adminitems ai
	  join loader_segmentpoolgroupitem sp on sp.groupitemid  = ai._fk_item
	   set ai.groupid 		= sp.itemgroupid 
		 , ai.itemposition 	= sp.groupposition
		 , ai.isfieldtest 	= sp.isfieldtest
		 , ai.isactive 		= sp.isactive
		 , ai.blockid 		= sp.blockid
		 , ai.isrequired    = sp.responserequired
		 , ai.groupkey		= concat(sp.itemgroupid, '_', sp.blockid)
	 where _fk_package = v_testpackagekey;


	
	update tmp_adminitems ai
	  join loader_segment s on s.segmentid = ai._fk_adminsubject 
						   and itemselection like 'adaptive%'
	   set clstring = makeclstring(ai._fk_adminsubject, ai._fk_item)
	 where _fk_package = v_testpackagekey;
	
	

	
	delete ai
	  from tblsetofadminitems ai
	  join tmp_adminitems tmp on ai._fk_adminsubject = tmp._fk_adminsubject
	 where not exists (select * from loader_testitem ti where ti._fk_package = v_testpackagekey and ti.testitemid = ai._fk_item);

	
	insert into tblsetofadminitems (_fk_item, _fk_adminsubject, loadconfig, _fk_strand, _fk_testadmin)
	select _fk_item, _fk_adminsubject, version, _fk_strand, _fk_testadmin
      from tmp_adminitems tmp 
	 where not exists (select 1 
						 from tblsetofadminitems i 
						where i._fk_adminsubject = tmp._fk_adminsubject 
						  and i._fk_item = tmp._fk_item
					);

	
	update tblsetofadminitems i
	  join tmp_adminitems tmp on tmp._fk_adminsubject = i._fk_adminsubject 
						     and tmp._fk_item = i._fk_item
	   set i.groupid 	= tmp.groupid 
		 , i.itemposition = tmp.itemposition
		 , i.isfieldtest  = coalesce(tmp.isfieldtest, 0)
		 , i.isactive 	  = coalesce(tmp.isactive, 1)
		 , i.blockid 	  = tmp.blockid
		 , i.isrequired	  = coalesce(tmp.isrequired, 1)
		 , i.groupkey	  = tmp.groupkey 
		 , i.strandname   = tmp.strandname
		 , i.irt_a 		  = tmp.irt_a
		 , i.irt_b 		  = tmp.irt_b
		 , i.irt_c 		  = tmp.irt_c
		 , i.irt_model	  = tmp.irt_model
		 , i.clstring 	  = tmp.clstring
		 , i.updateconfig = tmp.version;


	
	drop temporary table tmp_adminitems;
	drop temporary table tmp_irt;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_adminstimuli` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_adminstimuli`(

	v_testpackagekey varchar(350)
)
proc: begin

	
	if not exists (select * from loader_testpassages where _fk_package = v_testpackagekey) then
		leave proc;
	end if;	

	drop temporary table if exists tmp_tblstimulus;
	create temporary table tmp_tblstimulus (
		_fk_stimulus 	 varchar(100)
	  , _fk_adminsubject varchar(250)
	  , numitemsrequired int
	  , maxitems 		 int

	  , version 		 bigint
	  , groupid 		 varchar(50)
	)engine = memory;

	
	insert into tmp_tblstimulus (_fk_stimulus, _fk_adminsubject, numitemsrequired, maxitems, version, groupid)
	select distinct passageid
		 , segmentid
		 , case when maxresponses = 'ALL' then -1 else maxresponses end		as numitemsrequired
		 , case when maxitems = 'ALL' then -1 else maxitems end				as maxitems
		 , version
		 , substring_index(tfig.formitemgroupid, ':', -1)  					as groupid
	  from loader_testformitemgroup tfig 
	  join loader_segmentform sf on sf.formpartitionid = tfig.formpartitionid
								and sf._fk_package = tfig._fk_package
	 where passageid is not null
	   and passageid <> ''
	   and tfig._fk_package = v_testpackagekey;


	insert into tmp_tblstimulus (_fk_stimulus, _fk_adminsubject, numitemsrequired, maxitems, version, groupid) 
	select spref.passageid
		 , sp.segmentid
		 , case when sp.maxresponses = 'ALL' then -1 else sp.maxresponses end
		 , case when sp.maxitems = 'ALL' then -1 else sp.maxitems end
		 , sp.version
		 , sp.itemgroupid 
	  from loader_segmentpool sp
	  join loader_segmentpoolpassageref spref on spref.segmentid = sp.segmentid
											 and spref.itemgroupid = sp.itemgroupid
											 and spref._fk_package = sp._fk_package	
	 where spref.passageid is not null 
	   and spref.passageid <> ''
	   and sp._fk_package = v_testpackagekey;


	
	delete st
	  from tbladminstimulus st
	  join tmp_tblstimulus tmp on tmp._fk_adminsubject = st._fk_adminsubject
	 where not exists (select * from loader_testpassages tp where tp._fk_package = v_testpackagekey and tp.passageid = st._fk_stimulus);


	insert into tbladminstimulus (_fk_stimulus, _fk_adminsubject, numitemsrequired, maxitems, loadconfig, groupid) 
	select distinct *
	  from tmp_tblstimulus tmp
	where not exists (select 1
						from tbladminstimulus st
					   where st._fk_stimulus = tmp._fk_stimulus
						 and st._fk_adminsubject = tmp._fk_adminsubject);


	update tbladminstimulus st
	  join tmp_tblstimulus tmp on st._fk_stimulus = tmp._fk_stimulus
						      and st._fk_adminsubject = tmp._fk_adminsubject
	   set st.numitemsrequired = tmp.numitemsrequired
		 , st.maxitems = tmp.maxitems
		 , st.updateconfig = tmp.version;


	
	drop temporary table tmp_tblstimulus;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_adminstrands` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_adminstrands`(

	v_testpackagekey varchar(350)
)
begin
    
	declare v_issegmented bit;

	
	drop temporary table if exists tmp_tbladminstrand;
	create temporary table tmp_tbladminstrand (
		_key 				varchar(255)
	  , _fk_adminsubject 	varchar(250)
	  , _fk_strand 			varchar(150)
	  , minitems 			int 
	  , maxitems 			int
	  , bpweight 			float
	  , adaptivecut 		float
	  , startability 		float
	  , startinfo 			float 
	  , scalar 				float
      , loadmin             int
      , loadmax             int    
	  , isstrictmax			bit
	  , precisiontarget				float
	  , precisiontargetmetweight	float
	  , precisiontargetnotmetweight float
	  , abilityweight				float
	  , version 			bigint
      , elementtype         varchar(100)
	  , _fk_package 		varchar(350)
	)engine = memory;

    
    
    set v_issegmented = (select case when cnt > 1 then 1 else 0 end
						 from (
							select count(*) cnt
							  from loader_testblueprint

							where elementtype = 'segment'	
								and _fk_package = v_testpackagekey
							) t
                        );

	
	
	insert into tmp_tbladminstrand (_key, _fk_adminsubject, _fk_strand, minitems, maxitems, version, elementtype, _fk_package)
	select distinct concat(test.bpelementid, '-', strand.bpelementid)
		 , test.bpelementid
	     , strand.bpelementid
		 , case when strand.minopitems is null or strand.minopitems < 0 then 0 else strand.minopitems end
		 , case when strand.maxopitems is null or strand.maxopitems < 0 then 0 else strand.maxopitems end
		 , strand.version
		 , strand.elementtype
		 , strand._fk_package
	  from loader_testblueprint test 	
	  join loader_testblueprint strand on strand._fk_package = test._fk_package 
	 where test.elementtype = 'test'
	   and strand.elementtype in ('strand', 'contentlevel')
	   and test._fk_package = v_testpackagekey;

	if v_issegmented = 1 then
		
		
		insert into tmp_tbladminstrand (_key, _fk_adminsubject, _fk_strand, minitems, maxitems, loadmin, loadmax, version, elementtype, _fk_package)
		select distinct concat(segp.segmentid, '-', bp.bpelementid)
			 , segp.segmentid
			 , bp.bpelementid
			 , case when segp.minopitems is null or segp.minopitems < 0 then 0 else segp.minopitems end
			 , case when segp.maxopitems is null or segp.maxopitems < 0 then 0 else segp.maxopitems end
			 , case when segp.minopitems is null or segp.minopitems < 0 then 0 else segp.minopitems end
			 , case when segp.maxopitems is null or segp.maxopitems < 0 then 0 else segp.maxopitems end
			 , version
			 , elementtype
			 , bp._fk_package
		  from loader_testblueprint bp 	
		  join loader_segmentblueprint segp on segp.segmentbpelementid = bp.bpelementid		
										   and segp._fk_package = bp._fk_package
		 where elementtype in ('strand', 'contentlevel')
		   and bp._fk_package = v_testpackagekey;
	end if;

	
	drop temporary table if exists tmp_tblstrandproperties;	
	create temporary table tmp_tblstrandproperties as (
		select tmp._key
			 , max(if(sisp.propname = 'isstrictmax', (case sisp.propvalue when 'true' then 1 else 0 end), null)) as isstrictmax
			 , max(if(sisp.propname = 'bpweight', sisp.propvalue, null)) as bpweight
			 , max(if(sisp.propname = 'adaptivecut', sisp.propvalue, null)) as adaptivecut
			 , max(if(sisp.propname = 'startability', sisp.propvalue, null)) as startability
			 , max(if(sisp.propname = 'startinfo', sisp.propvalue, null)) as startinfo
			 , max(if(sisp.propname = 'scalar', sisp.propvalue, null)) as scalar
			
			 , max(if(sisp.propname = 'precisiontargetmetweight', sisp.propvalue, null)) as precisiontargetmetweight
			 , max(if(sisp.propname = 'precisiontargetnotmetweight', sisp.propvalue, null)) as precisiontargetnotmetweight
			 , max(if(sisp.propname = 'precisiontarget', sisp.propvalue, null)) as precisiontarget
			 , max(if(sisp.propname = 'abilityweight', sisp.propvalue, null)) as abilityweight
		  from tmp_tbladminstrand tmp
		  join loader_segmentitemselectionproperties sisp on sisp.segmentid = tmp._fk_adminsubject 
														 and sisp.bpelementid = tmp._fk_strand
														 and sisp._fk_package = tmp._fk_package		
		 where tmp.elementtype = 'strand'
		   and sisp._fk_package = v_testpackagekey
		 group by tmp._key
	);

	drop temporary table if exists tmp_tblcontentproperties;
	create temporary table tmp_tblcontentproperties as (
		select tmp._key
			 , max(if(sisp.propname = 'isstrictmax', (case sisp.propvalue when 'true' then 1 else 0 end), null)) as isstrictmax
			 , max(if(sisp.propname = 'bpweight', sisp.propvalue, null)) as bpweight
		  from tmp_tbladminstrand tmp
		  join loader_segmentitemselectionproperties sisp on sisp.segmentid = tmp._fk_adminsubject 
														 and sisp.bpelementid = tmp._fk_strand
														 and sisp._fk_package = tmp._fk_package	
		 where tmp.elementtype = 'contentlevel'
		   and sisp._fk_package = v_testpackagekey
		group by tmp._key
	);

	
	update tmp_tbladminstrand tmp
	  join tmp_tblstrandproperties p on p._key = tmp._key
	   set tmp.bpweight 	 = p.bpweight
		 , tmp.adaptivecut 	 = p.adaptivecut	
		 , tmp.startability  = p.startability
		 , tmp.startinfo	 = p.startinfo
		 , tmp.scalar   	 = p.scalar
		 , tmp.isstrictmax	 = p.isstrictmax
		 , tmp.abilityweight   = p.abilityweight
		 , tmp.precisiontarget = p.precisiontarget
		 , tmp.precisiontargetmetweight    = p.precisiontargetmetweight
		 , tmp.precisiontargetnotmetweight = p.precisiontargetnotmetweight;

	
	update tmp_tbladminstrand tmp
	  join tmp_tblcontentproperties p on p._key = tmp._key
	   set tmp.bpweight    = p.bpweight
		 , tmp.isstrictmax = p.isstrictmax;

	
	update tmp_tbladminstrand tmp
	   set tmp.bpweight     = coalesce(tmp.bpweight, 1)
		 , tmp.isstrictmax	= coalesce(tmp.isstrictmax, 0);

	
	update tbladminstrand sas
	  join tmp_tbladminstrand tmp on sas._fk_adminsubject = tmp._fk_adminsubject and sas._fk_strand = tmp._fk_strand
	   set sas._fk_adminsubject = tmp._fk_adminsubject
		 , sas._fk_strand 	= tmp._fk_strand
		 , sas.minitems 	= tmp.minitems
		 , sas.maxitems 	= tmp.maxitems
		 , sas.bpweight 	= tmp.bpweight
		 , sas.adaptivecut 	= tmp.adaptivecut
		 , sas.startability = tmp.startability
		 , sas.startinfo 	= tmp.startinfo
		 , sas.scalar 		= tmp.scalar
		 , sas.isstrictmax  = tmp.isstrictmax
		 , sas.updateconfig = tmp.version
		 , sas.loadmin		= tmp.loadmin
		 , sas.loadmax		= tmp.loadmax
		 , sas.precisiontarget 				= tmp.precisiontarget
		 , sas.precisiontargetmetweight 	= tmp.precisiontargetmetweight
		 , sas.precisiontargetnotmetweight  = tmp.precisiontargetnotmetweight
		 , sas.abilityweight 				= tmp.abilityweight
	;

	
	insert into tbladminstrand (_key, _fk_adminsubject, _fk_strand, minitems, maxitems, isstrictmax, bpweight, adaptivecut, startability, startinfo, scalar, loadconfig, loadmin, loadmax, precisiontarget, precisiontargetmetweight, precisiontargetnotmetweight, abilityweight)
	select _key, _fk_adminsubject, _fk_strand, minitems, maxitems, isstrictmax, bpweight, adaptivecut, startability, startinfo, scalar, version, loadmin, loadmax, precisiontarget, precisiontargetmetweight, precisiontargetnotmetweight, abilityweight
	  from tmp_tbladminstrand tmp
	 where not exists ( select 1 
						  from tbladminstrand sas
						 where sas._fk_adminsubject = tmp._fk_adminsubject
						   and sas._fk_strand = tmp._fk_strand);


	
	drop temporary table tmp_tbladminstrand;
	drop temporary table tmp_tblstrandproperties;
	drop temporary table tmp_tblcontentproperties;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_adminsubjects` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_adminsubjects`(

	v_testpackagekey varchar(350)
)
begin
    
	declare v_issegmented bit;

	drop temporary table if exists tmp_tblalgprop;
	create temporary table tmp_tblalgprop (
		propname varchar(1000)
	)engine = memory;

	insert into tmp_tblalgprop values ('ftstartpos');
	insert into tmp_tblalgprop values ('ftendpos');
	insert into tmp_tblalgprop values ('bpweight');
	insert into tmp_tblalgprop values ('startability');
	insert into tmp_tblalgprop values ('startinfo');
	insert into tmp_tblalgprop values ('cset1size');
	insert into tmp_tblalgprop values ('cset1order');
	insert into tmp_tblalgprop values ('cset2random');
	insert into tmp_tblalgprop values ('cset2initialrandom');
	insert into tmp_tblalgprop values ('abilityoffset');
	insert into tmp_tblalgprop values ('itemweight');
	insert into tmp_tblalgprop values ('precisiontarget');
	insert into tmp_tblalgprop values ('adaptivecut');
	insert into tmp_tblalgprop values ('toocloseses');
	insert into tmp_tblalgprop values ('slope');
	insert into tmp_tblalgprop values ('intercept');
	insert into tmp_tblalgprop values ('abilityweight');
	insert into tmp_tblalgprop values ('computeabilityestimates');
	insert into tmp_tblalgprop values ('rcabilityweight');
	insert into tmp_tblalgprop values ('precisiontargetmetweight');
	insert into tmp_tblalgprop values ('precisiontargetnotmetweight');
	insert into tmp_tblalgprop values ('terminationoverallinfo');
	insert into tmp_tblalgprop values ('terminationrcinfo');
	insert into tmp_tblalgprop values ('terminationmincount');
	insert into tmp_tblalgprop values ('terminationtooclose');
	insert into tmp_tblalgprop values ('terminationflagsand');


	
	drop temporary table if exists tmp_tblsetofadminsubjects;
	create temporary table tmp_tblsetofadminsubjects (
		_key varchar(250)
	  , _fk_testadmin 	varchar(150)
	  , _fk_subject 	varchar(150)
	  , testid 			varchar(255)
	  , startability 	float
	  , startinfo 		float 
	  , minitems 		int 
	  , maxitems 		int
	  , slope 			float
	  , intercept 		float
	  , ftstartpos 		int
	  , ftendpos 		int
	  , ftminitems 		int
	  , ftmaxitems 		int
	  , selectionalgorithm varchar(50)
	  , blueprintweight float
	  , cset1size 		int
	  , cset2random 	int
	  , cset2initialrandom int
	  , virtualtest 	varchar(200)
	  , testposition 	int
	  , issegmented 	bit
	  , itemweight 		float
	  , abilityoffset 	float
	  , cset1order 		varchar(50)
	  , version 		bigint
	  , contract 		varchar(100)
	  , testtype 		varchar(60)
	  , precisiontarget	float
	  , adaptivecut		float
	  , toocloseses		float
	  , abilityweight				float
	  , computeabilityestimates		bit
	  , rcabilityweight				float
	  , precisiontargetmetweight	float
	  , precisiontargetnotmetweight float
	  , terminationoverallinfo		bit
	  , terminationrcinfo			bit
	  , terminationmincount			bit
	  , terminationtooclose			bit
	  , terminationflagsand			bit
	  , bpmetricfunction 			varchar(10)
	);


	
	
	set v_issegmented = (select case when cnt > 1 then 1 else 0 end
						 from (
							select count(*) cnt
							  from loader_testblueprint

							  where elementtype = 'segment'	
								and _fk_package = v_testpackagekey
							) t
						);
	
	
	
	insert into tmp_tblsetofadminsubjects (_key, _fk_testadmin, _fk_subject, testid, minitems, maxitems, ftminitems, ftmaxitems, selectionalgorithm, issegmented, version, contract, testtype)
	select bpelementid
		 , testadmin
	     , subjectkey
		 , bpelementname
		 , minopitems
		 , maxopitems
		 , minftitems
		 , maxftitems
		 , 'virtual'
		 , v_issegmented
		 , version
		 , tp.publisher
		 , (select propvalue from loader_testpackageproperties tpp where tpp.propname = 'type' and tpp._fk_package = tp.packagekey)
	  from loader_testblueprint bp
	  join loader_testpackage tp on tp.packagekey = bp._fk_package
	 where elementtype = 'test'
	   and tp.packagekey = v_testpackagekey;

	
	if v_issegmented = 1 then
		insert into tmp_tblsetofadminsubjects (_key, _fk_testadmin, _fk_subject, testid, minitems, maxitems, ftminitems, ftmaxitems, testposition, selectionalgorithm, virtualtest, issegmented, version, contract)
		select bpelementid
			 , testadmin
			 , subjectkey
			 , bpelementname
			 , minopitems
			 , maxopitems
			 , minftitems
			 , maxftitems
			 , position
			 , itemselection 
			 , (select bpelementid from loader_testblueprint where elementtype = 'test' and _fk_package = tp.packagekey) as virtualtest
			 , 0
			 , tbp.version
			 , tp.publisher
		  from loader_testblueprint tbp
		  join loader_segment s on s._fk_package = tbp._fk_package
							   and s.segmentid = tbp.bpelementid
		  join loader_testpackage tp on tp.packagekey = tbp._fk_package
		 where elementtype = 'segment'
	       and tp.packagekey = v_testpackagekey;

	end if;

	
	drop temporary table if exists tmp_testproperties;
	create temporary table tmp_testproperties as (
		select sisp.bpelementid
			 , max(if(sisp.propname = 'ftstartpos', sisp.propvalue, null)) as ftstartpos
			 , max(if(sisp.propname = 'ftendpos', sisp.propvalue, null)) as ftendpos
			 , max(if(sisp.propname = 'bpweight', sisp.propvalue, null)) as bpweight
			 , max(if(sisp.propname = 'startability', sisp.propvalue, null)) as startability
			 , max(if(sisp.propname = 'startinfo', sisp.propvalue, null)) as startinfo
			 , max(if(sisp.propname = 'cset1size', sisp.propvalue, null)) as cset1size
			 , max(if(sisp.propname = 'cset1order', sisp.propvalue, null)) as cset1order
			 , max(if(sisp.propname = 'cset2random', sisp.propvalue, null)) as cset2random
			 , max(if(sisp.propname = 'cset2initialrandom', sisp.propvalue, null)) as cset2initialrandom
			 , max(if(sisp.propname = 'abilityoffset', sisp.propvalue, null)) as abilityoffset
			 , max(if(sisp.propname = 'itemweight', sisp.propvalue, null)) as itemweight
			 , max(if(sisp.propname = 'slope', sisp.propvalue, null)) as slope
			 , max(if(sisp.propname = 'intercept', sisp.propvalue, null)) as intercept
			 , max(if(sisp.propname = 'precisiontarget', sisp.propvalue, null)) as precisiontarget
			 , max(if(sisp.propname = 'adaptivecut', sisp.propvalue, null)) as adaptivecut
			 , max(if(sisp.propname = 'toocloseses', sisp.propvalue, null)) as toocloseses
		
			 , max(if(sisp.propname = 'abilityweight', sisp.propvalue, null)) as abilityweight
			 , max(if(sisp.propname = 'computeabilityestimates', (case sisp.propvalue when 'true' then 1 else 0 end), null)) as computeabilityestimates
			 , max(if(sisp.propname = 'rcabilityweight', sisp.propvalue, null)) as rcabilityweight
			 , max(if(sisp.propname = 'precisiontargetmetweight', sisp.propvalue, null)) as precisiontargetmetweight
			 , max(if(sisp.propname = 'precisiontargetnotmetweight', sisp.propvalue, null)) as precisiontargetnotmetweight
			 , max(if(sisp.propname = 'terminationoverallinfo', (case sisp.propvalue when 'true' then 1 else 0 end), null)) as terminationoverallinfo
			 , max(if(sisp.propname = 'terminationrcinfo', (case sisp.propvalue when 'true' then 1 else 0 end), null)) as terminationrcinfo
			 , max(if(sisp.propname = 'terminationmincount', (case sisp.propvalue when 'true' then 1 else 0 end), null)) as terminationmincount
			 , max(if(sisp.propname = 'terminationtooclose', (case sisp.propvalue when 'true' then 1 else 0 end), null)) as terminationtooclose
			 , max(if(sisp.propname = 'terminationflagsand', (case sisp.propvalue when 'true' then 1 else 0 end), null)) as terminationflagsand
		  from tmp_tblsetofadminsubjects tmp
		  join loader_segmentitemselectionproperties sisp on sisp.segmentid = tmp._key and tmp.testid = sisp.bpelementid
		 where sisp._fk_package = v_testpackagekey
		group by sisp.bpelementid
	);

	update tmp_tblsetofadminsubjects tmp
	  join tmp_testproperties tp on tp.bpelementid = tmp.testid
	   set tmp.ftstartpos 	   				= tp.ftstartpos 
		 , tmp.ftendpos 	   				= tp.ftendpos
		 , tmp.blueprintweight 				= tp.bpweight
		 , tmp.startability    				= tp.startability
		 , tmp.startinfo	  				= tp.startinfo
		 , tmp.cset1size	   				= tp.cset1size
		 , tmp.cset1order	   				= tp.cset1order
		 , tmp.cset2random	   				= tp.cset2random
		 , tmp.cset2initialrandom 			= tp.cset2initialrandom
		 , tmp.abilityoffset   				= tp.abilityoffset
		 , tmp.itemweight	   				= tp.itemweight
		 , tmp.slope						= tp.slope
		 , tmp.intercept					= tp.intercept
		 , tmp.precisiontarget  			= tp.precisiontarget
		 , tmp.adaptivecut					= tp.adaptivecut
		 , tmp.toocloseses					= tp.toocloseses
		 , tmp.abilityweight				= tp.abilityweight
		 , tmp.computeabilityestimates 		= tp.computeabilityestimates
		 , tmp.rcabilityweight 				= tp.rcabilityweight				
		 , tmp.precisiontargetmetweight 	= tp.precisiontargetmetweight
		 , tmp.precisiontargetnotmetweight 	= tp.precisiontargetnotmetweight
		 , tmp.terminationoverallinfo 		= tp.terminationoverallinfo
		 , tmp.terminationrcinfo 			= tp.terminationrcinfo			
		 , tmp.terminationmincount 			= tp.terminationmincount
		 , tmp.terminationtooclose 			= tp.terminationtooclose
		 , tmp.terminationflagsand 			= tp.terminationflagsand			
	;


	update tmp_tblsetofadminsubjects tmp
	  join loader_segment s on s.segmentid = tmp._key
	   set tmp.selectionalgorithm = s.itemselection 
	 where s._fk_package = v_testpackagekey;

	
	if v_issegmented = 1 then
		drop temporary table if exists tmp_testdefaults;
		create temporary table tmp_testdefaults as (
			select startability, startinfo, slope, intercept, toocloseses, rcabilityweight, precisiontarget, adaptivecut
			  from tmp_tblsetofadminsubjects
			 where testposition = 1
		);

		update tmp_tblsetofadminsubjects s, tmp_testdefaults d
		   set s.startability = d.startability
			 , s.startinfo = d.startinfo
			 , s.slope = d.slope
			 , s.intercept = d.intercept
			 , s.toocloseses = d.toocloseses
			 , s.rcabilityweight = d.rcabilityweight
			 , s.precisiontarget = d.precisiontarget
			 , s.adaptivecut = d.adaptivecut
		where s.testposition is null;		
	end if;

	
	
	update tmp_tblsetofadminsubjects
	   set startability 	  = coalesce(startability, 0) 
		 , startinfo 		  = coalesce(startinfo, 1)
		 , slope	 		  = coalesce(slope, 1)
		 , intercept 		  = coalesce(intercept, 1)
		 , bpmetricfunction   = 'bp1'
		 , blueprintweight    = coalesce(blueprintweight, 5.0)
		 , itemweight	      = coalesce(itemweight, 5.0)
		 , cset1order	      = coalesce(cset1order, 'ABILITY')
		 , abilityoffset   	  = coalesce(abilityoffset, 0.0)
		 , cset2initialrandom = coalesce(cset2initialrandom, 5)
		 , cset1size	   	  = coalesce(cset1size, 20)
		 , cset2random	      = coalesce(cset2random, 1)
		 , abilityweight				= coalesce(abilityweight, 1)
		 , computeabilityestimates 		= coalesce(computeabilityestimates, 1)
		 , rcabilityweight 				= coalesce(rcabilityweight, 1)				
		 , precisiontargetmetweight 	= coalesce(precisiontargetmetweight, 1)	
		 , precisiontargetnotmetweight 	= coalesce(precisiontargetnotmetweight, 1)
		 , terminationoverallinfo 		= coalesce(terminationoverallinfo, 0)		
		 , terminationrcinfo 			= coalesce(terminationrcinfo, 0)			
		 , terminationmincount 			= coalesce(terminationmincount, 0)			
		 , terminationtooclose 			= coalesce(terminationtooclose, 0)		
		 , terminationflagsand 			= coalesce(terminationflagsand, 0)
	;

	
	update tblsetofadminsubjects sas
	  join tmp_tblsetofadminsubjects tmp on tmp._key = sas._key
	   set sas._fk_testadmin = tmp._fk_testadmin
		 , sas._fk_subject = tmp._fk_subject
		 , sas.testid = tmp.testid
		 , sas.startability = tmp.startability
		 , sas.startinfo = tmp.startinfo
		 , sas.minitems = tmp.minitems
		 , sas.maxitems = tmp.maxitems
		 , sas.slope = tmp.slope
		 , sas.intercept = tmp.intercept
		 , sas.ftstartpos = tmp.ftstartpos
		 , sas.ftendpos = tmp.ftendpos
		 , sas.ftminitems = tmp.ftminitems
		 , sas.ftmaxitems = tmp.ftmaxitems
		 , sas.selectionalgorithm = tmp.selectionalgorithm
		 , sas.blueprintweight = tmp.blueprintweight
		 , sas.cset1size = tmp.cset1size
		 , sas.cset2random = tmp.cset2random
		 , sas.cset2initialrandom = tmp.cset2initialrandom
		 , sas.virtualtest = tmp.virtualtest
		 , sas.testposition = tmp.testposition
		 , sas.issegmented = tmp.issegmented
		 , sas.itemweight = tmp.itemweight
		 , sas.abilityoffset = tmp.abilityoffset
		 , sas.cset1order = tmp.cset1order
		 , sas.updateconfig = tmp.version 
		 , sas.contract = tmp.contract
		 , sas.testtype = tmp.testtype
		 , sas.precisiontarget = tmp.precisiontarget
		 , sas.adaptivecut = tmp.adaptivecut
		 , sas.toocloseses = tmp.toocloseses
		 , sas.abilityweight	= tmp.abilityweight
		 , sas.computeabilityestimates = tmp.computeabilityestimates
		 , sas.rcabilityweight = tmp.rcabilityweight				
		 , sas.precisiontargetmetweight = tmp.precisiontargetmetweight
		 , sas.precisiontargetnotmetweight = tmp.precisiontargetnotmetweight
		 , sas.terminationoverallinfo = tmp.terminationoverallinfo		
		 , sas.terminationrcinfo = tmp.terminationrcinfo	
		 , sas.terminationmincount = tmp.terminationmincount
		 , sas.terminationtooclose = tmp.terminationtooclose
		 , sas.terminationflagsand = tmp.terminationflagsand
		 , sas.bpmetricfunction = tmp.bpmetricfunction
	;


	
	insert into tblsetofadminsubjects (_key, _fk_testadmin, _fk_subject, testid, startability, startinfo, minitems, maxitems, slope, intercept, ftstartpos, ftendpos, ftminitems, ftmaxitems, selectionalgorithm, blueprintweight, cset1size, cset2random, cset2initialrandom, virtualtest, testposition, issegmented, itemweight, abilityoffset, cset1order, loadconfig, contract, testtype, precisiontarget, adaptivecut, toocloseses, abilityweight, computeabilityestimates, rcabilityweight, precisiontargetmetweight, precisiontargetnotmetweight, terminationoverallinfo, terminationrcinfo, terminationmincount, terminationtooclose, terminationflagsand, bpmetricfunction)
	select _key, _fk_testadmin, _fk_subject, testid, startability, startinfo, minitems, maxitems, slope, intercept, ftstartpos, ftendpos, ftminitems, ftmaxitems, selectionalgorithm, blueprintweight, cset1size, cset2random, cset2initialrandom, virtualtest, testposition, issegmented, itemweight, abilityoffset, cset1order, version, contract, testtype, precisiontarget, adaptivecut, toocloseses, abilityweight, computeabilityestimates, rcabilityweight, precisiontargetmetweight, precisiontargetnotmetweight, terminationoverallinfo, terminationrcinfo, terminationmincount, terminationtooclose, terminationflagsand, bpmetricfunction 
	  from tmp_tblsetofadminsubjects tmp
	 where not exists ( select 1 
						  from tblsetofadminsubjects sas
						 where sas._key = tmp._key);


	
	insert into _testupdate (_fk_adminsubject, configid, _date)
    select _key, version, now(3)
      from tmp_tblsetofadminsubjects;


 	call load_testgrades(v_testpackagekey);


    insert into testcohort (_fk_adminsubject, cohort, itemratio)
    select _key, 1, 1.0
      from tmp_tblsetofadminsubjects 
     where selectionalgorithm like 'adaptive%' 
	   and not exists ( select * 
						  from testcohort 
						 where _fk_adminsubject = _key);

	
	delete isp
	from tblitemselectionparm isp
	join tmp_tblsetofadminsubjects tmp on tmp._key = isp._fk_adminsubject;


	
	
	insert into tblitemselectionparm
	select tmp._key
		 , tmp.testid
		 , sisp.propname
		 , sisp.propvalue
		 , sisp.proplabel
		 , unhex(REPLACE(UUID(), '-', ''))
	  from tmp_tblsetofadminsubjects tmp
	  join loader_segmentitemselectionproperties sisp on sisp.segmentid = tmp._key and tmp._key = sisp.bpelementid
	 where propname not in (select propname from tmp_tblalgprop)
	   and selectionalgorithm like 'adaptive%';


	
	drop temporary table tmp_tblsetofadminsubjects;
	drop temporary table tmp_testproperties;
	drop temporary table tmp_tblalgprop;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_affinitygroups` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_affinitygroups`(

	v_testpackagekey varchar(350)
)
begin

	declare v_issegmented bit;
	declare v_testkey varchar(250);

	drop temporary table if exists tmp_affinitygroup;
	create temporary table tmp_affinitygroup (
	  	_fk_adminsubject varchar(250)
	  , groupid 		 varchar(100)
	  , minitems 		 int
	  , maxitems 		 int
	  , bpweight 		 float
	  , isstrictmax		 bit
	  , precisiontarget	 float
	  , abilityweight	 float
	  , loadconfig 		 bigint
	  , updateconfig 	 bigint
	  , startability 		float
	  , startinfo 			float 
	  , precisiontargetmetweight	float
	  , precisiontargetnotmetweight float
	  , _fk_package 	 varchar(350)
	)engine = memory;

	drop temporary table if exists tmp_affinitygroupitem;
	create temporary table tmp_affinitygroupitem (
		_fk_adminsubject varchar(250)
	  , groupid 		 varchar(100)
	  , _fk_item 		 varchar(100)
	)engine = memory;

    
    
    set v_issegmented = (select case when cnt = 0 then 1 else 0 end
                         from (
                            select count(*) cnt
                              from loader_testblueprint tbp1
                              join loader_testblueprint tbp2 on tbp1.bpelementid = tbp2.bpelementid
                                                            and tbp1._fk_package = tbp2._fk_package
                             where tbp1.elementtype = 'test'
                               and tbp2.elementtype = 'segment'
                               and tbp2._fk_package = v_testpackagekey
                            ) t
                        );

	
	insert into tmp_affinitygroup (_fk_adminsubject, groupid, minitems, maxitems, loadconfig, updateconfig, _fk_package)
	select test.bpelementid
	     , ag.bpelementid
		 , case when ag.minopitems is null or ag.minopitems < 0 then 0 else ag.minopitems end
		 , case when ag.maxopitems is null or ag.maxopitems < 0 then 0 else ag.maxopitems end
		 , ag.version
		 , ag.version
		 , ag._fk_package
	  from loader_testblueprint test 	
	  join loader_testblueprint ag on ag._fk_package = test._fk_package 
	 where test.elementtype = 'test'
	   and ag.elementtype = 'affinitygroup'
	   and test._fk_package = v_testpackagekey;

	set v_testkey = (select bpelementid from loader_testblueprint where elementtype = 'test' and _fk_package = v_testpackagekey);

	insert into tmp_affinitygroupitem (_fk_adminsubject, groupid, _fk_item)
	select v_testkey, ref, testitemid
	  from loader_testitemrefs 
	 where refcategory = 'affinitygroup'
	   and _fk_package = v_testpackagekey;


	if v_issegmented = 1 then
		
		insert into tmp_affinitygroup (_fk_adminsubject, groupid, minitems, maxitems, loadconfig, updateconfig, _fk_package)
		select segp.segmentid
			 , bp.bpelementid
			 , case when segp.minopitems is null or segp.minopitems < 0 then 0 else segp.minopitems end
			 , case when segp.maxopitems is null or segp.maxopitems < 0 then 0 else segp.maxopitems end
			 , version
			 , version
			 , bp._fk_package
		  from loader_testblueprint bp 	
		  join loader_segmentblueprint segp on segp.segmentbpelementid = bp.bpelementid		
										   and segp._fk_package = bp._fk_package
		 where elementtype = 'affinitygroup'
		   and bp._fk_package = v_testpackagekey;

		insert into tmp_affinitygroupitem (_fk_adminsubject, groupid, _fk_item)
		select ref1.ref, ref2.ref, ref2.testitemid
		  from loader_testitemrefs ref1
		  join loader_testitemrefs ref2 on ref2._fk_package = ref1._fk_package and ref1.testitemid = ref2.testitemid
		 where ref1.refcategory = 'segment'
		   and ref2.refcategory = 'affinitygroup'
		   and ref1._fk_package = v_testpackagekey;
	end if;

	drop temporary table if exists tmp_tblaffinityproperties;
	create temporary table tmp_tblaffinityproperties as (
		select tmp._fk_adminsubject 
			 , tmp.groupid
			 , max(if(sisp.propname = 'isstrictmax', (case sisp.propvalue when 'true' then 1 else 0 end), null)) as isstrictmax
			 , max(if(sisp.propname = 'bpweight', sisp.propvalue, null)) as bpweight
			 , max(if(sisp.propname = 'startability', sisp.propvalue, null)) as startability
			 , max(if(sisp.propname = 'startinfo', sisp.propvalue, null)) as startinfo
			 , max(if(sisp.propname = 'abilityweight', sisp.propvalue, null)) as abilityweight
			 , max(if(sisp.propname = 'precisiontarget', sisp.propvalue, null)) as precisiontarget
			 , max(if(sisp.propname = 'precisiontargetmetweight', sisp.propvalue, null)) as precisiontargetmetweight
			 , max(if(sisp.propname = 'precisiontargetnotmetweight', sisp.propvalue, null)) as precisiontargetnotmetweight
		  from tmp_affinitygroup tmp
		  join loader_segmentitemselectionproperties sisp on sisp.segmentid = tmp._fk_adminsubject 
														 and sisp.bpelementid = tmp.groupid
														 and sisp._fk_package = tmp._fk_package	
		 where sisp._fk_package = v_testpackagekey
		 group by tmp.groupid
	);

	update tmp_affinitygroup tmp
	  join tmp_tblaffinityproperties p on p._fk_adminsubject = tmp._fk_adminsubject
									  and p.groupid = tmp.groupid
	   set tmp.bpweight    		= p.bpweight
		 , tmp.isstrictmax 		= p.isstrictmax
		 , tmp.startability     = p.startability
		 , tmp.startinfo	    = p.startinfo
		 , tmp.abilityweight   = p.abilityweight
		 , tmp.precisiontarget  = p.precisiontarget
		 , tmp.precisiontargetmetweight    = p.precisiontargetmetweight
		 , tmp.precisiontargetnotmetweight = p.precisiontargetnotmetweight;


	
	update tmp_affinitygroup tmp
	   set tmp.bpweight     = coalesce(tmp.bpweight, 1)
		 , tmp.isstrictmax	= coalesce(tmp.isstrictmax, 0);


	
	delete ag
	  from affinitygroup ag
	  join tmp_affinitygroup tmp on tmp._fk_adminsubject = ag._fk_adminsubject;

	delete ag
	  from affinitygroupitem ag
	  join tmp_affinitygroupitem tmp on tmp._fk_adminsubject = ag._fk_adminsubject;

	
	insert into affinitygroup (_fk_adminsubject, groupid, minitems, maxitems, weight, isstrictmax, loadconfig, updateconfig, abilityweight, precisiontarget, startability, startinfo, precisiontargetmetweight, precisiontargetnotmetweight)
	select _fk_adminsubject, groupid, minitems, maxitems, bpweight, isstrictmax, loadconfig, updateconfig, abilityweight, precisiontarget, startability, startinfo, precisiontargetmetweight, precisiontargetnotmetweight
	  from tmp_affinitygroup;

	insert into affinitygroupitem (_fk_adminsubject, groupid, _fk_item)
	select _fk_adminsubject, groupid, _fk_item
	  from tmp_affinitygroupitem;

	
	
	drop temporary table tmp_tblaffinityproperties;
	drop temporary table tmp_affinitygroup;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_itemproperties` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_itemproperties`(

	v_testpackagekey varchar(350)
)
begin

	create temporary table tmp_segments (
		testitemid	varchar(150)
	  , segments    varchar(250)
	)engine = memory;

	create temporary table tmp_itemprops (
		_fk_item 		 varchar(150)
	  , propname 		 varchar(50)
	  , propvalue 		 varchar(128)
	  , propdescription  varchar(150)
	  , _fk_adminsubject varchar(250)
	);

	
	insert into tmp_segments
	select distinct testitemid
		 , ref
	  from loader_testitemrefs
	 where reftype = 'bp'
	   and refcategory = 'segment'
	   and _fk_package = v_testpackagekey;

	insert into tmp_itemprops
	select tip.testitemid
		 , tip.propname
		 , tip.propvalue
		 , tip.proplabel
		 , seg.segments
	  from loader_testitempoolproperties tip
	  join tmp_segments seg on seg.testitemid = tip.testitemid
 	 where _fk_package = v_testpackagekey;

	
	
	insert into tmp_itemprops
	select ti.testitemid
		 , '--ITEMTYPE--'
		 , ti.itemtype
		 , ti.itemtype
		 , seg.segments
	  from loader_testitem ti
	  join tmp_segments seg on seg.testitemid = ti.testitemid
	 where _fk_package = v_testpackagekey;


    insert into tblitemprops(_fk_item, propname, propvalue, _fk_adminsubject, isactive)
	select distinct tmp._fk_item, tmp.propname, tmp.propvalue, tmp._fk_adminsubject
		 , 1 as isactive
	from tmp_itemprops tmp
	where not exists ( select 1
						 from tblitemprops ip
						where ip._fk_Item = tmp._fk_Item 
						  and ip.propname = tmp.propname 
						  and ip.propvalue = tmp.propvalue
						  and ip._fk_adminsubject = tmp._fk_adminsubject
					);
    update tblitemprops ip, tmp_itemprops tmp 
    set ip.propdescription = tmp.propdescription
     where ip._fk_item = tmp._fk_item
      and ip.propname = tmp.propname
      and ip.propvalue = tmp.propvalue
      and ip._fk_adminsubject = tmp._fk_adminsubject;
      
	
	update tblitemprops ip
	  left join tmp_itemprops tmp on ip._fk_Item = tmp._fk_Item
								 and ip.propname = tmp.propname 
								 and ip.propvalue = tmp.propvalue
	   set isactive = case when tmp._fk_Item is null then 0 else 1 end
	 where ip._fk_adminsubject = tmp._fk_adminsubject;


	









	
	drop temporary table tmp_segments;
	drop temporary table tmp_itemprops;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_items` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_items`(

	v_testpackagekey varchar(350)
)
begin

	

	create temporary table tmp_scorepoints (
		testitemid  varchar(150)
	  , scorepoints int
	)engine = memory;

	
	insert into tblitem (_efk_itembank, _efk_Item, itemtype, filepath, filename, datelastupdated, itemid, _key, loadconfig)
	select coalesce(substring_index(testitemid, '-', 1), pkg._efk_itembank)
		 , coalesce(substring_index(testitemid, '-', -1), 0)
		 , itemtype
		 , filepath
		 , filename
		 , now(3)
		 , testitemname
		 , testitemid
		 , version
	  from loader_testitem ti
	  join loader_testpackage pkg on pkg.packagekey = ti._fk_package 
	 where not exists (select * 
						 from tblitem 
					    where _Key = testitemid)
	   and _fk_package = v_testpackagekey;

	insert into tmp_scorepoints
	select distinct testitemid, scorepoints 
	  from loader_itemscoredimension
	 where _fk_package = v_testpackagekey;

	update tblitem i
	  join tmp_scorepoints sp on sp.testitemid = i._key
	  join loader_testitem ti on ti.testitemid = i._key
	   set i.scorepoint = sp.scorepoints
		 , i.updateconfig = ti.version;

	

	
	drop temporary table tmp_scorepoints;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_linkitemstostimuli` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_linkitemstostimuli`(

	v_testpackagekey varchar(350)
)
begin

	create temporary table tmp_segments (
		testitemid	varchar(150)
	  , segments    varchar(250)
	)engine = memory;

	create temporary table tmp_passages (
		testitemid	varchar(150)
	  , passages   	varchar(150)
	)engine = memory;

	
	insert into tmp_segments
	select distinct testitemid
		 , ref
	  from loader_testitemrefs
	 where reftype = 'bp'
	   and refcategory = 'segment'
	   and _fk_package = v_testpackagekey;

	insert into tmp_passages (testitemid, passages)
	select distinct testitemid
		 , ref
	  from loader_testitemrefs
	 where reftype = 'passage'
	   and _fk_package = v_testpackagekey;

	
	delete s
	  from tblsetofitemstimuli s 
	  join tmp_segments seg on seg.segments = s._fk_adminsubject;

	insert into tblsetofitemstimuli
	select p.testitemid
		 , p.passages
		 , seg.segments
		 , version
	  from tmp_passages p
	  join tmp_segments seg on seg.testitemid = p.testitemid
	  join loader_testitem ti on ti.testitemid = seg.testitemid
	 where _fk_package = v_testpackagekey;
	
	
	drop temporary table tmp_segments;
	drop temporary table tmp_passages;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_linkitemstostrands` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_linkitemstostrands`(

	v_testpackagekey varchar(350)
)
begin

	delete 
	  from loader_setofitemstrands
	 where _fk_package = v_testpackagekey;

	drop temporary table if exists tmp_segments;
	create temporary table tmp_segments (
		testitemid	varchar(150)
	  , segments    varchar(250)
	)engine = memory;

	drop temporary table if exists tmp_strands;
	create temporary table tmp_strands (
		testitemid	varchar(150)
	  , strands   	varchar(150)
	  , lvl			int
	)engine = memory;

	drop temporary table if exists tmp_affinity;
	create temporary table tmp_affinity (
		testitemid	varchar(150)
	  , affinity   	varchar(150)
	)engine = memory;

	drop temporary table if exists tmp_maxlvlstrands;
	create temporary table tmp_maxlvlstrands (
		testitemid	varchar(150)
	  , max_lvl		int
	)engine = memory;

	
	insert into tmp_segments
	select distinct testitemid
		 , ref
	  from loader_testitemrefs
	 where reftype = 'bp'
	   and refcategory = 'segment'
	   and _fk_package = v_testpackagekey;

	insert into tmp_strands (testitemid, strands, lvl)
	select distinct testitemid
		 , ref
		 , treelevel
	  from loader_testitemrefs 
	 where reftype = 'bp'
	   and refcategory in ('strand', 'contentlevel')
	   and _fk_package = v_testpackagekey; 

	insert into tmp_affinity (testitemid, affinity)
	select distinct testitemid
		 , ref
	  from loader_testitemrefs 
	 where reftype = 'bp'
	   and refcategory = 'affinitygroup'
	   and _fk_package = v_testpackagekey; 

	insert into tmp_maxlvlstrands
	select testitemid, max(lvl) max_lvl
	  from tmp_strands
	group by testitemid;

    delete cl
	  from aa_itemcl cl
	  join tmp_segments seg on seg.segments = cl._fk_adminsubject and seg.testitemid = cl._fk_item;

	insert into aa_itemcl
	select seg.segments
		 , s.testitemid
		 , s.strands
	  from tmp_strands s
	  join tmp_segments seg on seg.testitemid = s.testitemid;

	insert into aa_itemcl
	select seg.segments
		 , a.testitemid
		 , a.affinity
	  from tmp_affinity a
	  join tmp_segments seg on seg.testitemid = a.testitemid;


	delete s
	  from tmp_strands s
	  join tmp_maxlvlstrands ms on ms.testitemid = s.testitemid and ms.max_lvl <> s.lvl;


	insert into loader_setofitemstrands
	select ti._fk_package
		 , s.testitemid
		 , s.strands
		 , seg.segments
		 , version
	  from tmp_strands s
	  join tmp_segments seg on seg.testitemid = s.testitemid
	  join loader_testitem ti on ti.testitemid = s.testitemid
	 where ti._fk_package = v_testpackagekey;

	
	
	delete s
	  from tblsetofitemstrands s 
	  join tmp_segments seg on seg.testitemid = s._fk_item and seg.segments = s._fk_adminsubject;


	insert into tblsetofitemstrands
	select _fk_item
		 , _fk_strand
		 , _fk_adminsubject
		 , version
	  from loader_setofitemstrands
	 where _fk_package = v_testpackagekey;
	
	
	drop temporary table tmp_segments;
	drop temporary table tmp_strands;
	drop temporary table tmp_maxlvlstrands;
	drop temporary table tmp_affinity;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_measurementparameters` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_measurementparameters`(

	v_overwrite bit
)
begin

    declare v_nmodels int;
    declare v_nparms  int;
    declare v_models  int;
    declare v_parms   int;

	if v_overwrite is null then set v_overwrite = 0; end if;

	
	
	

	update measurementparameter set parmname = 'b0', parmdescription = 'Difficulty cut 0 (b0)'
	 where _fk_measurementmodel = 2 and parmnum = 0;

	
	update measurementparameter set parmname = 'a', parmdescription = 'Slope (a)' 
	 where _fk_measurementmodel = 1 and parmnum = 0;
	update measurementparameter set parmname = 'b', parmdescription = 'Difficulty (b)' 
	 where _fk_measurementmodel = 1 and parmnum = 1;

	
	
    delete from loader_measurementparameter;    
	
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(1.0, 0.0, 'a', 'Slope (a)', 'IRT3pln');

    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(1.0, 1.0, 'b', 'Difficulty (b)', 'IRT3pln');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(1.0, 2.0, 'c', 'Guessing (c)', 'IRT3pln');
   
	
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(2.0, 0.0, 'b0', 'Difficulty cut 0 (b0)', 'IRTPCL');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(2.0, 1.0, 'b1', 'Difficulty cut 1 (b1)', 'IRTPCL');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(2.0, 2.0, 'b2', 'Difficulty cut 2 (b2)', 'IRTPCL');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(2.0, 3.0, 'b3', 'Difficulty cut 3 (b3)', 'IRTPCL');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(2.0, 4.0, 'b4', 'Difficulty cut 4 (b4)', 'IRTPCL');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(2.0, 5.0, 'b5', 'Difficulty cut 5 (b5)', 'IRTPCL');

    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values (3, null, null, 'Raw (not IRT) scoring model', 'raw');

    
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(4, 0.0, 'a', 'Slope (a)', 'IRT3PL');

    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(4, 1.0, 'b', 'Difficulty (b)', 'IRT3PL');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(4, 2.0, 'c', 'Guessing (c)', 'IRT3PL');



    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(5, 0.0, 'a', 'Slope (a)', 'IRTGPC');

    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(5, 1.0, 'b0', 'Difficulty cut 0 (b0)', 'IRTGPC');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(5, 2.0, 'b1', 'Difficulty cut 1 (b1)', 'IRTGPC');

    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(5, 3.0, 'b2', 'Difficulty cut 2 (b2)', 'IRTGPC');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(5, 4.0, 'b3', 'Difficulty cut 3 (b3)', 'IRTGPC');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(5, 5.0, 'b4', 'Difficulty cut 4 (b4)', 'IRTGPC');
   
    insert into loader_measurementparameter(modelnum, parmnum, parmname, parmdescription, modelname)
      values(5, 6.0, 'b5', 'Difficulty cut 5 (b5)', 'IRTGPC');


    set v_nmodels = (select count(distinct modelnum) from loader_measurementparameter);
    set v_nparms  = (select count(*) from loader_measurementparameter);
    set v_models  = (select count(*) from measurementmodel);
    set v_parms   = (select count(*) from measurementparameter);
        
    if (v_overwrite = 1 or v_nmodels <> v_models or v_nparms <> v_parms) then 
	begin   
        delete from measurementparameter;
        delete from measurementmodel;

        insert into measurementmodel(modelnumber, modelname) 
        select distinct modelnum, modelname 
          from loader_measurementparameter;

        insert into measurementparameter(_fk_measurementmodel, parmnum, parmname, parmdescription) 
        select modelnum, parmnum, parmname, parmdescription
          from loader_measurementparameter 
		 where parmnum is not null;
    end;
	end if;
   
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_stimuli` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_stimuli`(

	v_testpackagekey varchar(350)
)
begin

	

	
	insert into tblstimulus (_efk_itembank, _efk_itskey, clientid, filepath, filename, datelastupdated, _key, loadconfig)
	select coalesce(substring_index(passageid, '-', 1), pkg._efk_itembank)
		 , coalesce(substring_index(passageid, '-', -1), 0)
		 , null
		 , filepath
		 , filename
		 , now(3)
		 , passageid
		 , version
	  from loader_testpassages p
	  join loader_testpackage pkg on pkg.packagekey = p._fk_package 
	 where not exists (select 1
						 from tblstimulus 
						where passageid = _key)
	   and _fk_package = v_testpackagekey;


	

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_strands` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_strands`(

	v_testpackagekey varchar(350)
)
begin
	
	
	
	
	insert into tblstrand (_fk_subject, `name`, _fk_parent, _key, _fk_client, treelevel, loadconfig) 
	select distinct subjectkey
		 , bpelementname
		 , case when parentid is null or parentid = '' 
				then null 
				else parentid 
		   end
		 , bpelementid
		 , clientkey
		 , treelevel
		 , version
	  from loader_testblueprint tbp
	  join loader_testpackage tp on tp.packagekey = tbp._fk_package	
	 where elementtype in ('strand', 'contentlevel')
	   and bpelementid not in (select _key from tblstrand)
	   and tbp._fk_package = v_testpackagekey;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_subject` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_subject`(

	v_testpackagekey varchar(350)
)
begin

	insert into tblsubject (`name`, grade, _key, _fk_client, loadconfig)
	select tp.subjectname
		 , '' as grade
		 , subjectkey
		 , clientkey
		 , tp.testversion
	  from loader_testpackage tp
	  
	 where not exists ( select 1
						  from tblsubject s
						 where s._key = tp.subjectkey )
	   and packagekey = v_testpackagekey;



end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_testadmin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_testadmin`(

	v_testpackagekey varchar(350)
)
begin
    
	
	declare v_clientname varchar(50);
	declare v_adminkey   varchar(150);
	declare v_purpose 	 varchar(300);
	declare v_version    int;
	declare v_clientkey	 int;


	select clientkey
		 , testadmin
		 , purpose
		 , testversion
	  into v_clientkey, v_adminkey, v_purpose, v_version
	  from loader_testpackage t
	 where packagekey = v_testpackagekey;


	
	if (not exists (select * from tbltestadmin
					 where _key = v_adminkey and _fk_client = v_clientkey))
	then
		insert into tbltestadmin (_key, schoolyear, season, _fk_client, description, loadConfig) values 
			(v_adminkey,  '', '', v_clientkey, concat(v_adminkey, ' ', v_purpose) , v_version);
	else
		update tbltestadmin
		   set updateconfig = v_version
		 where _key = v_adminkey;
	end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_testgrades` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_testgrades`(

	v_testpackagekey varchar(350)
)
begin

	declare v_testid varchar(150);

	create temporary table tmp_gradelist (
		gradename  varchar(100)
	  , gradelabel varchar(200)
	)engine = memory;

	create temporary table tmp_testkeys (
		testkey varchar(250)
	  , testid  varchar(255)
	)engine = memory;
		
	
	insert into tmp_gradelist
	select propvalue, proplabel
	  from loader_testpackageproperties
	 where propname = 'grade'
	   and _fk_package = v_testpackagekey;

	insert into tmp_testkeys
	select distinct bpelementid
		 , bpelementname
	  from loader_testblueprint
	 where elementtype in ('test', 'segment')
	  and _fk_package = v_testpackagekey;

	set v_testid = (select bpelementname from loader_testblueprint
					 where elementtype = 'test'
					   and _fk_package = v_testpackagekey);
	
	
    delete g
	  from setoftestgrades g
	  join tmp_testkeys t on t.testkey = g._fk_adminsubject;


	insert into setoftestgrades
	select v_testid
		 , gl.gradename
		 , 0
		 , tk.testkey
		 , null
		 , unhex(REPLACE(UUID(), '-', ''))
	  from tmp_testkeys tk
	  join tmp_gradelist gl on 1 = 1;


	
	drop temporary table tmp_gradelist;
	drop temporary table tmp_testkeys;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `load_testpackagerecord` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `load_testpackagerecord`(

	v_xml  longtext,
	v_testkey varchar(350)
)
begin
	declare v_simtestpackagekey varbinary(16)	;
	set v_simtestpackagekey = unhex(REPLACE(UUID(), '-', ''));
	
	insert into tbltestpackage (_key, testpackage) 
	values (v_simtestpackagekey, v_xml) ;
	
	insert into tbladminsubjecttestpackage (_fk_adminsubject, _fk_testpackage, dateloaded) 
	values (v_testkey, v_simtestpackagekey, NOW()) ;
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `testlanguages` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `testlanguages`(

  	v_test varchar(200)
)
    SQL SECURITY INVOKER
proc: begin

    declare v_segmented bit;
	declare v_algorithm varchar(50);


    select issegmented, selectionalgorithm 
	into v_segmented, v_algorithm
	from tblsetofadminsubjects
    where _key = v_test;

    if (v_segmented = 0) then 
	begin
        if (v_algorithm = 'fixedform') then
            insert into `session`.tblout_testlanguages (`code`, label)
            select distinct propvalue, propdescription
            from tblitemprops p, testform f
            where p._fk_adminsubject = v_test and propname = 'language' and f._fk_adminsubject = v_test and f.`language` = p.propvalue
                and p.isactive = 1;
        else 
            insert into `session`.tblout_testlanguages (`code`, label)
            select distinct  propvalue, propdescription
            from  tblitemprops p
            where p._fk_adminsubject = v_test and propname = 'language' and isactive = 1;
        end if;
    end;
    else
        insert into `session`.tblout_testlanguages (`code`, label)
        select distinct propvalue, propdescription
        from tblsetofadminitems a, tblitemprops p, tblsetofadminsubjects s
        where s.virtualtest = v_test and a._fk_adminsubject = s._key and a._fk_adminsubject = p._fk_adminsubject 
            and a._fk_item = p._fk_item and propname = 'language' and p.isactive = 1;
	end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updatetdsconfigs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `updatetdsconfigs`(

	v_testpackagekey  varchar(350)
)
begin

    declare v_client 	varchar(100);
	declare v_testkey	varchar(250);
    declare v_testname 	varchar(250);
    declare v_segmented bit;
	declare v_algorithm varchar(50);

	drop temporary table if exists tmp_tests;
    create temporary table tmp_tests(
		`client` 	varchar(100)
	  , test 		varchar(150)
	  , testkey 	varchar(250)
	  , `subject` 	varchar(100)
	  , issegmented bit
	  , selectionalgorithm varchar(50)
	  , instrument  varchar(100)
	  , done 		bit default 0
	);
    
	drop temporary table if exists tmp_segments;
	create temporary table tmp_segments(
		`client` 	varchar(100)
	  , segment 	varchar(150)
	  , segkey 		varchar(250)
	  , pos 		int
	  , virtualtest varchar(200)
	  , vtestkey 	varchar(250)
	);


	
	
	insert into tmp_tests (`client`, test, testkey, `subject`, issegmented)		
	select distinct tp.publisher
		 , s.testid
		 , s._key
		 , tp.subjectname
		 , s.issegmented      
	  from tblsetofadminsubjects s 
	  join loader_testpackage tp on tp.testkey = s._key
	 where s.virtualtest is null
	   and packagekey = v_testpackagekey;

	insert into tmp_segments (`client`, segment, segkey, pos, virtualtest, vtestkey)       
    select distinct tp.publisher
		 , s.testid
		 , s._key
		 , s.testposition
		 , (select testid from tblsetofadminsubjects where _key = s.virtualtest)
		 , s.virtualtest
	  from tblsetofadminsubjects s 
	  join loader_testpackage tp on tp.testkey = s.virtualtest
     where s.virtualtest is not null
	   and packagekey = v_testpackagekey;


	
	drop temporary table if exists tmp_langs;
    create temporary table tmp_langs(
		`client` 	varchar(100)
	  , testkey 	varchar(200)
	  , testname 	varchar(200)
	  , lang 		varchar(50)
	  , descrip 	varchar(200)
	);

	drop temporary table if exists tmp_result;
	create temporary table tmp_result(
		`code` 	varchar(100)
	  , label 	varchar(200)
	);

	
    set v_client = (select distinct `client` from tmp_tests);

	
    while (exists (select * from tmp_tests where done = 0)) do
	begin
        select testkey, test, issegmented, selectionalgorithm
		  into v_testkey, v_testname, v_segmented, v_algorithm
          from tmp_tests 
		 where done = 0 limit 1;

		if (v_segmented = 0) then
		begin
			if (v_algorithm = 'fixedform') then
			begin
				insert into tmp_result (`code`, label)
				select distinct  propvalue, propdescription
				  from tblitemprops p
				  join testform f on f._fk_adminsubject = p._fk_adminsubject and f.`language` = p.propvalue
				 where propname = 'language'
				   and p.isactive = 1
				   and f._fk_adminsubject = v_testkey;
			end;
			else begin
				insert into tmp_result (`code`, label)
				select distinct  propvalue, propdescription
				  from tblitemprops p
				 where propname = 'language' 
				   and isactive = 1
				   and p._fk_adminsubject = v_testkey;
			end;
			end if;
		end;
		else begin
			insert into tmp_result (`code`, label)
			select distinct propvalue, propdescription
			  from tblsetofadminitems a
			  join tblitemprops p on a._fk_item = p._fk_item and a._fk_adminsubject = p._fk_adminsubject 
			  join tblsetofadminsubjects s on a._fk_adminsubject = s._key
			 where propname = 'language' 
			   and p.isactive = 1
			   and s.virtualtest = v_testkey;
		end;
		end if;

		
        insert into tmp_langs (client, testkey, testname, lang, descrip)
        select distinct v_client, v_testkey, v_testname, `code`, label
          from tmp_result;

		
		delete from tmp_result;
		update tmp_tests set done = 1 where testkey = v_testkey;
	end;
	end while;

    
    insert into configs.client_testeeattribute (clientname, tds_id, rtsname, `type`, label, reportname, atlogin, sortorder)
    select v_client, tds_id, rtsname, `type`, label, reportname, atlogin, sortorder
      from configs.tds_testeeattribute
     where not exists (select * from configs.client_testeeattribute 
						where clientname = v_client);

    insert into configs.client_testeerelationshipattribute (clientname, tds_id, rtsname, label, reportname, atlogin, sortorder, relationshiptype)
    select v_client, tds_id, rtsname, label, reportname, atlogin, sortorder, relationshiptype
      from configs.tds_testeerelationshipattribute
     where not exists (select * from configs.client_testeerelationshipattribute 
						where clientname = v_client);
    
    insert into configs.`client` (`name`)
    select v_client
	  from dual
     where not exists (select * from configs.`client` 
						where `name` = v_client);

    insert into configs.client_timewindow(clientname, windowid, startdate, enddate)
    select v_client, 'ANNUAL', now(), date_add(now(), interval 1 year)
      from dual
     where not exists (select * from configs.client_timewindow 
						where clientname = v_client and windowid = 'ANNUAL');
    
    insert into configs.client_fieldtestpriority(clientname, tds_id, priority, testid)
    select v_client, p.tds_id, priority, '*'
      from configs.tds_fieldtestpriority p
	  join configs.client_testeeattribute a on a.tds_id = p.tds_id
    where a.clientname = v_client 
      and not exists (select * from configs.client_fieldtestpriority
					   where clientname = v_client);

    insert into configs.client_grade(clientname, gradecode, grade)
    select distinct `client`, grade, concat('Grade ', cast(grade as char(4))) gradelabel
      from tmp_tests t
	  join setoftestgrades s on s._fk_adminsubject = t.testkey 
     where t.testkey not like '%student help%'
	   and not exists (select * from configs.client_grade c 
					    where c.clientname = t.`client` and c.gradecode = s.grade);

    insert into configs.client_subject(clientname, `subject`, subjectcode)
    select distinct t.`client`
		 , t.`subject`
         , t.`subject`
      from tmp_tests t
     where t.testkey not like '%student help%'
       and not exists (select * from configs.client_subject c 
					    where c.clientname = t.`client` and c.`subject` = t.`subject`);

    insert into configs.client_accommodationfamily (clientname, family, label)
    select distinct t.`client`, t.`subject`, t.`subject`
      from tmp_tests t
     where not exists (select * from configs.client_accommodationfamily f 
						where f.clientname = t.`client` and f.family = t.`subject`);

	
    insert into configs.client_testproperties 
        (clientname, testid, isselectable, label, subjectname, maxopportunities, scorebytds, accommodationfamily,  reportinginstrument, tide_id, gradetext)
    select distinct `client`
		 , test
		 , isselectable(testkey)
		 , _maketestlabel(testkey) as label
		 , t.`subject`
		 , 3
		 , isselectable(testkey)
		 , (select family from configs.client_accommodationfamily f where t.`client` = f.clientname and t.`subject` = f.label)
         , instrument
		 , case when instrument is not null then concat(instrument, '-', `subject`) else null end
         , _maketestgradelabel(testkey)
      from tmp_tests t
     where not exists (select * from configs.client_testproperties 
						where clientname = `client` and testid = test);

	
    insert into configs.client_testmode(clientname, testid, testkey, `mode`, sessiontype, _key)
    select client, test, testkey, 'online', 0
		 , unhex(replace(uuid(), '-', ''))
      from tmp_tests t
	 where not exists (select * from configs.client_testmode 
						where clientname = `client` and testid = test);

    update configs.client_testmode tm
	  join tmp_tests t on t.testkey = tm.testkey
	   set tm.issegmented = t.issegmented;

    update configs.client_testmode tm 
	  join tblsetofadminsubjects s on s._key = tm.testkey
	  join tmp_tests t on t.testkey = s._key
	   set tm.`algorithm` = s.selectionalgorithm;

	
    delete 
	  from configs.client_segmentproperties 
	 where exists (select * from tmp_tests 
					where clientname = `client` and parenttest = test)
       and not exists (select * from tmp_segments 
						where `client` = clientname and segment = segmentid and virtualtest = parenttest);

    insert into configs.client_segmentproperties (clientname, segmentid, segmentposition, parenttest, ispermeable, entryapproval, exitapproval, itemreview, label, modekey)
    select client, segment, pos, virtualtest, 1, 0, 0, 0, concat(_maketestlabel(segkey), ' segment'), vtestkey
      from tmp_segments t
     where not exists (select * 
						 from configs.client_segmentproperties s 
						where s.clientname = t.`client` and s.segmentid = t.segment  and s.parenttest = t.virtualtest);

    update configs.client_segmentproperties s
      join tmp_segments t on 
      s.clientname = t.`client` and s.segmentid = t.segment and s.parenttest = t.virtualtest
      set s.segmentposition = t.pos
        , s.modekey = t.vtestkey;	 

	
	
    insert into configs.client_testformproperties (clientname, _efk_testform, formid, testid, `language`, startdate, enddate, testkey)
    select `client`, _key, formid, test, `language`, null, null, t.testkey
      from tmp_tests t
	  join testform f on f._fk_adminsubject = t.testkey
     where not exists (select * from configs.client_testformproperties p 
					    where p.clientname = `client` and p._efk_testform = f._key and p.testkey = t.testkey);

	
    insert into configs.client_testformproperties (clientname, _efk_testform, formid, testid, `language`, startdate, enddate, testkey)
    select `client`, _key, formid, segment, `language`, null, null, t.segkey
      from tmp_segments t
	  join testform f on f._fk_adminsubject = t.segkey
     where not exists (select * from configs.client_testformproperties p 
					    where p.clientname = `client` and p._efk_testform = f._key and p.testkey = t.segkey);

    insert into configs.client_testwindow (clientname, testid, windowid, numopps, startdate, enddate, _key, origin, source)
    select `client`, test, 'ANNUAL', 3, now()
		 , date_add(now(), interval 1 year)
		 , unhex(replace(uuid(), '-', '')), null, null
      from tmp_tests 
	 where not exists (select * from configs.client_testwindow 
						where clientname = `client` and testid = test);

    delete 
	  from configs.client_testgrades
     where exists (select * from tmp_tests 
					where clientname = `client` and testid = test);

    insert into configs.client_testgrades (clientname, testid, grade)
    select distinct `client`, s.testid, g.grade
      from setoftestgrades g
	  join tmp_tests t on t.testkey = g._fk_adminsubject
	  join tblsetofadminsubjects s on s._key = t.testkey
     where s.virtualtest is null;

	
    insert into configs.client_testeligibility (_key, clientname, testid, rtsname, enables, disables, rtsvalue, _efk_entitytype, eligibilitytype, matchtype)
	select unhex(replace(uuid(), '-', '')), t.*
	  from (
			select distinct t.client, t.test
				 , 'EnrlGrdCd' as rtsname
				 , 1 as enables
				 , 0 as disables
				   
				 , case when g.grade regexp'^([+-]?[0-9]+\.?[0-9]*e?[0-9]+)|(0x[0-9A-F]+)$' is not null and length(g.grade) = 1 then concat('0', g.grade) else g.grade end as rtsvalue
				 , 6 as _efk_entitytype
				 , 'ATTRIBUTE' as eligibilitytype
				 , 0 matchtype
			  from tmp_tests t
			  join configs.client_testgrades g on t.`client` = g.clientname and t.test = g.testid
			 where not exists (select * from configs.client_testeligibility e 
								where e.clientname = g.clientname and e.testid = g.testid)
		) t;

	
    delete 
	  from configs.client_test_itemtypes
     where exists (select * from tmp_tests 
					where clientname = `client` and testid = test);

	
    insert into configs.client_test_itemtypes (clientname, testid, itemtype)
    select distinct `client`, test, itemtype
      from tblsetofadminitems a 
	  join tmp_tests t on t.testkey = a._fk_adminsubject
	  join tblitem i on i._key = a._fk_item
     where test not like '%student help%' 
	   and t.issegmented = 0;

	
    insert into configs.client_test_itemtypes (clientname, testid, itemtype)
    select distinct t.`client`, t.test, itemtype
      from tmp_segments s, tblitem i, tblsetofadminitems a, tmp_tests t
     where t.issegmented = 1 
	   and s.virtualtest = t.test
       and a._fk_adminsubject = s.segkey and a._fk_item = i._key
       and not exists (select * from configs.client_test_itemtypes x 
						where x.clientname = t.`client` and x.testid = t.test and x.itemtype = i.itemtype);


	
    
	drop temporary table if exists tmp_tests2;
	create temporary table tmp_tests2 (
		select * from tmp_tests
	);

	drop temporary table if exists tmp_segments2;
	create temporary table tmp_segments2 (
		select * from tmp_segments
	);
	
    delete tic
	  from configs.client_test_itemconstraint tic
     where exists (select * from tmp_tests2 t 
					where tic.clientname = t.`client` 
					  and tic.testid = t.test and t.issegmented = 0)
	   and not exists (select * from tblitemprops p, tmp_tests t 
						where p._fk_adminsubject = t.testkey 
						  and t.`client` = clientname and t.test = testid
                          and p.propname = tic.propname and p.propvalue = tic.propvalue);

    delete tic
	  from configs.client_test_itemconstraint tic
     where exists (select * from tmp_segments2 s 
					where clientname = s.`client` and testid = s.virtualtest )
       and not exists (select * from tblitemprops p, tmp_segments s 
						where p._fk_adminsubject = s.segkey and s.`client` = clientname and s.virtualtest = testid
                          and p.propname = tic.propname
                          and p.propvalue = tic.propvalue);

	
    insert into configs.client_test_itemconstraint (clientname, testid, propname, propvalue, tooltype, toolvalue, item_in)
    select distinct t.`client`, t.test
		 , p.propname, propvalue, p.propname
		 , concat(propvalue, case p.propname when 'TDSPoolFilter' then ' in' else '' end)
		 , 1
      from tblitemprops p
	  join tmp_tests t on t.testkey = p._fk_adminsubject
     where t.issegmented = 0 
	   and t.test not like '%student help%'
	   and p.propname in ('language', 'TDSPoolFilter')
       and not exists (select * from configs.client_test_itemconstraint c 
						where c.clientname = t.`client` and c.testid = t.test 
						  and c.propname = p.propname and c.propvalue = p.propvalue and c.item_in = 1);

    
    insert into configs.client_test_itemconstraint (clientname, testid, propname, propvalue, tooltype, toolvalue, item_in)
    select distinct t.`client`, t.test, p.propname, p.propvalue
         , case p.propname when '--ITEMTYPE--' then 'Item Types Exclusion' else p.propname end 
         , case p.propname when '--ITEMTYPE--' then concat('TDS_ItemTypeExcl_', propvalue) else concat(propvalue, ' OUT') end 
         , 0
      from tblitemprops p
	  join tmp_tests t on t.testkey = p._fk_adminsubject 
     where t.issegmented = 0 
	   and t.test not like '%student help%' 
	   and p.propname in ('TDSPoolFilter', '--ITEMTYPE--')
	   and not exists (select * from configs.client_test_itemconstraint c 
						where c.clientname = t.`client` and c.testid = t.test 
					      and c.propname = p.propname and c.propvalue = p.propvalue and c.item_in = 0);

 
	
    insert into configs.client_test_itemconstraint (clientname, testid, propname, propvalue, tooltype, toolvalue, item_in)
    select distinct s.`client`, s.virtualtest, p.propname, propvalue, p.propname
         , concat(propvalue, case p.propname when 'TDSPoolFilter' then ' IN' else '' end), 1
    from tblitemprops p, tmp_segments s
    where s.segkey = p._fk_adminsubject and p.propname in ('Language', 'TDSPoolFilter')
    and not exists (select * from configs.client_test_itemconstraint c 
					 where c.clientname = s.client and c.testid = s.virtualtest
					   and c.propname = p.propname and c.propvalue = p.propvalue and c.item_in = 1);
    
    insert into configs.client_test_itemconstraint (clientname, testid, propname, propvalue, item_in, tooltype, toolvalue)
    select distinct s.`client`, s.virtualtest, p.propname, propvalue, 0
		 , case when p.propname = '--ITEMTYPE--' then 'Item Types Exclusion' else p.propname end 
         , case p.propname when '--ITEMTYPE--' then concat('TDS_ItemTypeExcl_', propvalue) else concat(propvalue, ' OUT') end
    from tblitemprops p, tmp_segments s
    where  s.segkey = p._fk_adminsubject and p.propname in ('TDSPoolFilter', '--ITEMTYPE--')
    and not exists 
        (select * from configs.client_test_itemconstraint c where c.clientname = s.`client` and c.testid = s.virtualtest
            and c.propname = p.propname and c.propvalue = p.propvalue and c.item_in = 0);

	
    insert into configs.client_testtooltype (clientname, dateentered, `context`, contexttype, toolname, allowchange, isselectable, isvisible
            , studentcontrol, isfunctional, rtsfieldname, isrequired, tideselectable, tideselectablebysubject)
    select distinct p.clientname, now(3), p.testid, 'TEST', p.tooltype, allowchange, 0, 0
		 , 0, 0, rtsfieldname, 0, tideselectable, tideselectablebysubject
    from configs.client_test_itemconstraint p
	join configs.tds_testtooltype l on l.toolname = p.tooltype
	join tmp_tests s on p.testid = s.test and p.clientname = s.`client`
    where p.propname = 'TDSPoolFilter'
	  and not exists (select * from configs.client_testtooltype c
                       where c.clientname = s.`client` and c.contexttype = 'TEST' and c.`context` = testid and c.toolname = p.tooltype);

    insert into configs.client_testtool (clientname, `type`, `code`, `value`, isdefault, allowcombine, valuedescription, `context`, contexttype)
    select distinct c.clientname, c.tooltype, c.toolvalue, c.toolvalue
		 , case when c.toolvalue like 'offgrade % out' then 1 else 0 end   
		 , 1, 'Item Pool Filter', c.testid, 'TEST'
      from tmp_tests t
	  join configs.client_test_itemconstraint c on t.`client` = c.clientname and t.test = c.testid
     where c.propname = 'TDSPoolFilter'    
       and not exists (select * from configs.client_testtool tt
					    where tt.clientname = c.clientname and tt.contexttype = 'TEST' and tt.`context` = c.testid and tt.`type` = c.tooltype and tt.`code` = c.toolvalue);

	
    insert into configs.client_testtooltype (clientname, dateentered, `context`, contexttype, toolname, allowchange, rtsfieldname, isrequired, tideselectable, tideselectablebysubject)
    select v_client, now(3), '*' , 'TEST', toolname, allowchange, rtsfieldname, isrequired, tideselectable, tideselectablebysubject
    from configs.tds_testtooltype t
    where t.isrequired = 1 
	  and t.toolname not in  ('language', 'TDSPoolFilter')
      and not exists (select * from configs.client_testtooltype c
                       where c.clientname = v_client and c.contexttype = 'TEST' and c.`context` = '*' and c.toolname = t.toolname);

    insert into configs.client_testtool (clientname, `type`, `code`, `value`, isdefault, allowcombine, valuedescription, `context`, contexttype)
    select v_client, `type`, `code`, `value`, isdefault, allowcombine, valuedescription, '*', 'test'
      from configs.tds_testtool 
	  join configs.tds_testtooltype t on `type` = toolname
    where isrequired = 1 
	  and toolname not in  ('language', 'TDSPoolFilter')
      and not exists (select * from configs.client_testtool c 
                    where c.clientname = v_client and c.contexttype = 'TEST' and c.`context` = '*' and c.`type` = t.toolname);

	drop temporary table if exists tmp_langs2;
	create temporary table tmp_langs2 (
		select * from tmp_langs
	);

    
    delete 
	  from configs.client_testtool
     where `type` = 'language'
	   and exists (select * from tmp_langs where `client` = clientname and testname = `context` and contexttype = 'TEST')
	   and not exists (select * from tmp_langs2 where `client` = clientname and testname = `context` and contexttype = 'TEST' and `code` = lang);

    insert into configs.client_testtooltype (clientname, dateentered, `context`, contexttype, toolname, allowchange, isrequired, rtsfieldname
        , isselectable, isvisible, tideselectable, tideselectablebysubject, studentcontrol)
    select distinct `client`
    	 , now(3)
		 , testname, 'TEST', toolname
		 , allowchange, isrequired, rtsfieldname
         , isselectable(testkey) as isselectable
         , isselectable(testkey) as isvisible
         , isselectable(testkey) as tideselectable     
         , isselectable(testkey) as tideselectablebysubject  
         , case when isselectable(testname) = 1 and l.`client` like '%_PT' then 1 else 0 end as studentcontrol
      from tmp_langs l, configs.tds_testtooltype t
     where t.toolname = 'language' 
       and not exists (select * from configs.client_testtooltype c 
						where clientname = l.`client` and contexttype = 'TEST' 
						  and `context` = l.testname and c.toolname = 'language');

    
    insert into configs.client_testtool (clientname, `context`, contexttype, `type`, `code`, `value`, valuedescription, isdefault, allowcombine)
    select distinct `client`, testname, 'test', 'language' , lang, descrip, concat(descrip, ' language test') valuedescription
         , case lang when 'enu' then 1 else 0 end as isdefault
		 , 0 as allowcombine
      from tmp_langs t
     where not exists (select * from configs.client_testtool 
                        where clientname = t.client and contexttype = 'test' and context = t.testname and code = lang and type = 'language');


    
    insert into configs.client_language (clientname, language, languagecode)
    select distinct `client`, descrip, lang 
	  from tmp_langs l
     where not exists (select * from configs.client_language c 
						where c.clientname = l.client and c.languagecode = l.lang);














	
	drop temporary table tmp_langs;
	drop temporary table tmp_result;
	drop temporary table tmp_tests;
	drop temporary table tmp_segments;

 	drop temporary table tmp_langs2;
	drop temporary table tmp_tests2;
	drop temporary table tmp_segments2;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-05 14:54:30
