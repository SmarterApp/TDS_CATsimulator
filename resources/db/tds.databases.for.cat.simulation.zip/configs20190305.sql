CREATE DATABASE  IF NOT EXISTS `configs` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `configs`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: configs
-- ------------------------------------------------------
-- Server version	5.7.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `__accommodationcache`
--

DROP TABLE IF EXISTS `__accommodationcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__accommodationcache` (
  `_key` bigint(20) NOT NULL AUTO_INCREMENT,
  `testkey` varchar(250) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `_date` datetime NOT NULL,
  `dategenerated` datetime DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `ix_accomcache` (`testkey`,`clientname`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `__appmessagecontexts`
--

DROP TABLE IF EXISTS `__appmessagecontexts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__appmessagecontexts` (
  `clientname` varchar(100) NOT NULL,
  `systemid` varchar(100) NOT NULL,
  `language` varchar(30) DEFAULT NULL,
  `contextlist` text,
  `_key` bigint(20) NOT NULL AUTO_INCREMENT,
  `dategenerated` datetime(3) DEFAULT NULL,
  `soundx` char(4) DEFAULT NULL,
  `contextindex` varchar(50) DEFAULT NULL,
  `delim` char(1) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `ix_messagecontext` (`clientname`,`systemid`,`language`,`contextindex`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `__appmessages`
--

DROP TABLE IF EXISTS `__appmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__appmessages` (
  `_fk_appmessagecontext` bigint(20) DEFAULT NULL,
  `msgkey` bigint(20) DEFAULT NULL,
  `msgsource` varchar(100) DEFAULT NULL,
  `messageid` int(11) DEFAULT NULL,
  `contexttype` varchar(50) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `appkey` varchar(255) DEFAULT NULL,
  `language` varchar(30) DEFAULT NULL,
  `grade` varchar(25) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `paralabels` varchar(255) DEFAULT NULL,
  `message` text,
  KEY `fk_appmessagecontext` (`_fk_appmessagecontext`),
  CONSTRAINT `fk_appmessagecontext` FOREIGN KEY (`_fk_appmessagecontext`) REFERENCES `__appmessagecontexts` (`_key`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `__cachedaccomdepends`
--

DROP TABLE IF EXISTS `__cachedaccomdepends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__cachedaccomdepends` (
  `_fk_accommodationcache` bigint(20) NOT NULL,
  `contexttype` varchar(100) DEFAULT NULL,
  `context` varchar(100) DEFAULT NULL,
  `testmode` varchar(50) DEFAULT NULL,
  `iftype` varchar(200) DEFAULT NULL,
  `ifvalue` varchar(200) DEFAULT NULL,
  `thentype` varchar(200) DEFAULT NULL,
  `thenvalue` varchar(200) DEFAULT NULL,
  `isdefault` bit(1) DEFAULT NULL,
  KEY `ix_cachedaccomdeps` (`_fk_accommodationcache`),
  CONSTRAINT `fk_accdep_cache` FOREIGN KEY (`_fk_accommodationcache`) REFERENCES `__accommodationcache` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `__cachedaccommodations`
--

DROP TABLE IF EXISTS `__cachedaccommodations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__cachedaccommodations` (
  `_fk_accommodationcache` bigint(20) NOT NULL,
  `segment` int(11) DEFAULT NULL,
  `disableonguestsession` bit(1) DEFAULT NULL,
  `tooltypesortorder` int(11) DEFAULT NULL,
  `toolvaluesortorder` int(11) DEFAULT NULL,
  `typemode` varchar(100) DEFAULT NULL,
  `toolmode` varchar(100) DEFAULT NULL,
  `acctype` varchar(200) DEFAULT NULL,
  `accvalue` varchar(200) DEFAULT NULL,
  `acccode` varchar(200) DEFAULT NULL,
  `isdefault` bit(1) DEFAULT NULL,
  `allowcombine` bit(1) DEFAULT NULL,
  `isfunctional` bit(1) DEFAULT NULL,
  `allowchange` bit(1) DEFAULT NULL,
  `isselectable` bit(1) DEFAULT NULL,
  `isvisible` bit(1) DEFAULT NULL,
  `studentcontrol` bit(1) DEFAULT NULL,
  `valcount` int(11) DEFAULT NULL,
  `dependsontooltype` varchar(100) DEFAULT NULL,
  KEY `ix_cachedaccoms` (`_fk_accommodationcache`),
  KEY `ix_accomcode` (`_fk_accommodationcache`,`acccode`,`segment`,`isdefault`),
  CONSTRAINT `fk_accom_cache` FOREIGN KEY (`_fk_accommodationcache`) REFERENCES `__accommodationcache` (`_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `_messageid`
--

DROP TABLE IF EXISTS `_messageid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_messageid` (
  `_key` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `name` varchar(100) NOT NULL,
  `origin` varchar(50) DEFAULT NULL,
  `internationalize` bit(1) NOT NULL DEFAULT b'1',
  `defaultlanguage` varchar(50) NOT NULL DEFAULT 'enu',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_accommodationfamily`
--

DROP TABLE IF EXISTS `client_accommodationfamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_accommodationfamily` (
  `clientname` varchar(100) NOT NULL,
  `family` varchar(50) NOT NULL,
  `label` varchar(200) NOT NULL,
  PRIMARY KEY (`clientname`,`family`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_accommodations`
--

DROP TABLE IF EXISTS `client_accommodations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_accommodations` (
  `clientname` varchar(100) NOT NULL,
  `type` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `isdefault` bit(1) NOT NULL,
  `allowcombine` bit(1) NOT NULL,
  `allowchange` bit(1) NOT NULL,
  `isselectable` bit(1) NOT NULL,
  `isvisible` bit(1) NOT NULL DEFAULT b'1',
  `valuedescription` varchar(500) DEFAULT NULL,
  `tideselectable` bit(1) DEFAULT NULL,
  `rtsfieldname` varchar(100) NOT NULL,
  PRIMARY KEY (`clientname`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_allowips`
--

DROP TABLE IF EXISTS `client_allowips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_allowips` (
  `clientname` varchar(100) NOT NULL,
  `applicationname` varchar(50) NOT NULL,
  `allowip` varchar(25) NOT NULL,
  `datebegin` datetime(3) NOT NULL,
  `dateend` datetime(3) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `userid` varchar(50) DEFAULT NULL,
  `environment` varchar(100) NOT NULL,
  `message` text,
  `datecreated` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`applicationname`,`allowip`,`environment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_externs`
--

DROP TABLE IF EXISTS `client_externs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_externs` (
  `_key` varbinary(16) NOT NULL,
  `testeedb` varchar(255) NOT NULL,
  `proctordb` varchar(255) NOT NULL,
  `testdb` varchar(255) NOT NULL,
  `scorerdb` varchar(255) DEFAULT NULL,
  `archivedb` varchar(255) DEFAULT NULL,
  `testeetype` varchar(255) NOT NULL DEFAULT 'rts',
  `proctortype` varchar(255) NOT NULL DEFAULT 'rts',
  `scorertype` varchar(255) NOT NULL DEFAULT 'rts',
  `sessiondb` varchar(255) DEFAULT NULL,
  `errorsserver` varchar(255) DEFAULT NULL,
  `errorsdb` varchar(255) DEFAULT NULL,
  `clientname` varchar(100) NOT NULL,
  `bankadminkey` varchar(150) DEFAULT NULL,
  `clientstylepath` varchar(500) DEFAULT NULL,
  `qaxmlpath` varchar(500) DEFAULT NULL,
  `environment` varchar(100) NOT NULL,
  `ispracticetest` bit(1) NOT NULL,
  `timezoneoffset` int(11) NOT NULL DEFAULT '0',
  `publishurl` varchar(255) DEFAULT NULL,
  `initialreportingid` bigint(20) NOT NULL DEFAULT '1',
  `initialsessionid` bigint(20) NOT NULL DEFAULT '1',
  `qabrokerguid` varbinary(16) DEFAULT NULL,
  `expiresatminutes` int(11) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  UNIQUE KEY `ix_clientexterns` (`clientname`,`environment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_fieldtestpriority`
--

DROP TABLE IF EXISTS `client_fieldtestpriority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_fieldtestpriority` (
  `tds_id` varchar(50) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `priority` int(11) NOT NULL,
  `testid` varchar(200) NOT NULL,
  PRIMARY KEY (`clientname`,`testid`,`tds_id`,`priority`),
  KEY `fk_ft_testeeatt` (`clientname`,`tds_id`),
  CONSTRAINT `fk_ft_testeeatt` FOREIGN KEY (`clientname`, `tds_id`) REFERENCES `client_testeeattribute` (`clientname`, `tds_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_forbiddenappsexcludeschools`
--

DROP TABLE IF EXISTS `client_forbiddenappsexcludeschools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_forbiddenappsexcludeschools` (
  `districtname` varchar(150) DEFAULT NULL,
  `districtid` varchar(150) NOT NULL,
  `schoolname` varchar(150) DEFAULT NULL,
  `schoolid` varchar(150) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  PRIMARY KEY (`districtid`,`schoolid`,`clientname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_forbiddenappslist`
--

DROP TABLE IF EXISTS `client_forbiddenappslist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_forbiddenappslist` (
  `os_id` varchar(25) NOT NULL,
  `processname` varchar(150) NOT NULL,
  `processdescription` varchar(150) DEFAULT NULL,
  `clientname` varchar(100) NOT NULL,
  PRIMARY KEY (`os_id`,`processname`,`clientname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_grade`
--

DROP TABLE IF EXISTS `client_grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_grade` (
  `gradecode` varchar(25) NOT NULL,
  `grade` varchar(64) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `origin` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`gradecode`,`clientname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_itemscoringconfig`
--

DROP TABLE IF EXISTS `client_itemscoringconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_itemscoringconfig` (
  `clientname` varchar(100) NOT NULL,
  `servername` varchar(255) NOT NULL DEFAULT '*',
  `siteid` varchar(255) NOT NULL DEFAULT '*',
  `context` varchar(255) NOT NULL DEFAULT '*',
  `itemtype` varchar(50) NOT NULL DEFAULT '*',
  `item_in` bit(1) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  `serverurl` varchar(255) NOT NULL DEFAULT '*',
  `environment` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_language`
--

DROP TABLE IF EXISTS `client_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_language` (
  `clientname` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `languagecode` varchar(25) NOT NULL,
  `origin` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`languagecode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_message`
--

DROP TABLE IF EXISTS `client_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_message` (
  `clientname` varchar(100) NOT NULL,
  `messageid` int(11) NOT NULL,
  `translationid` int(11) NOT NULL DEFAULT '0',
  `systemid` varchar(25) NOT NULL,
  `contexttype` varchar(25) NOT NULL,
  `context` varchar(100) NOT NULL,
  `defaultmessage` varchar(255) NOT NULL,
  `clientmessage` text,
  `paralabels` varchar(255) DEFAULT NULL,
  `languagecode` varchar(25) DEFAULT 'enu',
  `gradecode` varchar(25) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `usefilepath` bit(1) NOT NULL DEFAULT b'0',
  `datechanged` datetime(3) NOT NULL,
  `datepublished` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`messageid`,`translationid`,`systemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_messagearchive`
--

DROP TABLE IF EXISTS `client_messagearchive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_messagearchive` (
  `clientname` varchar(100) NOT NULL,
  `messageid` int(11) NOT NULL,
  `translationid` int(11) NOT NULL DEFAULT '0',
  `systemid` varchar(25) NOT NULL,
  `contexttype` varchar(25) NOT NULL,
  `context` varchar(100) NOT NULL,
  `defaultmessage` varchar(255) NOT NULL,
  `clientmessage` text,
  `paralabels` varchar(255) DEFAULT NULL,
  `languagecode` varchar(25) DEFAULT NULL,
  `gradecode` varchar(25) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `usefilepath` bit(1) NOT NULL DEFAULT b'0',
  `datechanged` datetime(3) NOT NULL,
  `datepublished` datetime(3) DEFAULT NULL,
  `_date` datetime(3) NOT NULL,
  `username` varchar(128) DEFAULT NULL,
  `action` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`messageid`,`translationid`,`systemid`,`_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_messagetranslation`
--

DROP TABLE IF EXISTS `client_messagetranslation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_messagetranslation` (
  `_fk_coremessageobject` bigint(20) NOT NULL,
  `client` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `language` varchar(30) NOT NULL,
  `grade` varchar(25) NOT NULL DEFAULT '--any--',
  `subject` varchar(50) NOT NULL DEFAULT '--any--',
  `_key` varbinary(16) NOT NULL,
  `datealtered` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `ix_msgtrans` (`_fk_coremessageobject`,`client`,`language`),
  CONSTRAINT `fk_clientmsgtranslation` FOREIGN KEY (`_fk_coremessageobject`) REFERENCES `tds_coremessageobject` (`_key`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_messagetranslationaudit`
--

DROP TABLE IF EXISTS `client_messagetranslationaudit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_messagetranslationaudit` (
  `_fk_coremessageobject` bigint(20) NOT NULL,
  `context` varchar(100) NOT NULL,
  `contexttype` varchar(50) NOT NULL,
  `client` varchar(100) NOT NULL,
  `appkey` varchar(255) NOT NULL,
  `message` text,
  `messageid` int(11) NOT NULL,
  `language` varchar(30) NOT NULL,
  `grade` varchar(25) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `datealtered` datetime(3) NOT NULL,
  `username` varchar(128) NOT NULL,
  `_date` datetime(3) NOT NULL,
  `action` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_pilotschools`
--

DROP TABLE IF EXISTS `client_pilotschools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_pilotschools` (
  `clientname` varchar(100) NOT NULL,
  `_efk_testid` varchar(50) NOT NULL,
  `schoolid` varchar(50) NOT NULL,
  `schoolname` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`_efk_testid`,`schoolid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_rtsroles`
--

DROP TABLE IF EXISTS `client_rtsroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_rtsroles` (
  `tds_role` varchar(100) NOT NULL,
  `rts_role` varchar(100) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `datechanged` datetime(3) DEFAULT NULL,
  `datepublished` datetime(3) DEFAULT NULL,
  `sessiontype` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`clientname`,`tds_role`,`rts_role`,`sessiontype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_segmentproperties`
--

DROP TABLE IF EXISTS `client_segmentproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_segmentproperties` (
  `ispermeable` int(11) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `entryapproval` int(11) NOT NULL,
  `exitapproval` int(11) NOT NULL,
  `itemreview` bit(1) NOT NULL DEFAULT b'1',
  `segmentid` varchar(255) NOT NULL,
  `segmentposition` int(11) NOT NULL,
  `parenttest` varchar(255) NOT NULL,
  `ftstartdate` datetime(3) DEFAULT NULL,
  `ftenddate` datetime(3) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `modekey` varchar(250) DEFAULT NULL,
  `restart` int(11) DEFAULT NULL,
  `graceperiodminutes` int(11) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`parenttest`,`segmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_server`
--

DROP TABLE IF EXISTS `client_server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_server` (
  `_key` varbinary(16) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `applicationname` varchar(100) NOT NULL,
  `serverip` varchar(100) NOT NULL,
  `serverid` varchar(100) NOT NULL,
  `servertype` varchar(100) NOT NULL,
  `virtualdirname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_subject`
--

DROP TABLE IF EXISTS `client_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_subject` (
  `subjectcode` varchar(25) DEFAULT NULL,
  `subject` varchar(100) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `origin` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`subject`,`clientname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_systemflags`
--

DROP TABLE IF EXISTS `client_systemflags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_systemflags` (
  `auditobject` varchar(255) NOT NULL,
  `ison` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `clientname` varchar(100) NOT NULL,
  `ispracticetest` bit(1) NOT NULL,
  `datechanged` datetime(3) DEFAULT NULL,
  `datepublished` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`auditobject`,`ispracticetest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_tds_rtsattribute`
--

DROP TABLE IF EXISTS `client_tds_rtsattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_tds_rtsattribute` (
  `clientname` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `fieldname` varchar(35) NOT NULL,
  `datatype` varchar(50) DEFAULT 'codelist',
  `_efk_entitytype` bigint(20) NOT NULL DEFAULT '6',
  `type` varchar(25) NOT NULL DEFAULT 'attribute',
  `entitytype` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`fieldname`,`_efk_entitytype`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_tds_rtsattributevalues`
--

DROP TABLE IF EXISTS `client_tds_rtsattributevalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_tds_rtsattributevalues` (
  `clientname` varchar(100) NOT NULL,
  `fieldname` varchar(35) NOT NULL,
  `value` varchar(365) NOT NULL,
  `allowcombine` bit(1) NOT NULL DEFAULT b'1',
  `_efk_entitytype` bigint(20) NOT NULL DEFAULT '6',
  `type` varchar(25) NOT NULL DEFAULT 'attribute',
  PRIMARY KEY (`clientname`(50),`fieldname`,`value`(100),`_efk_entitytype`,`type`),
  KEY `fk_client_tds_rtsattributevalues_client_tds_rtsattribute` (`clientname`,`fieldname`,`_efk_entitytype`,`type`),
  CONSTRAINT `fk_client_tds_rtsattributevalues_client_tds_rtsattribute` FOREIGN KEY (`clientname`, `fieldname`, `_efk_entitytype`, `type`) REFERENCES `client_tds_rtsattribute` (`clientname`, `fieldname`, `_efk_entitytype`, `type`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_test_itemconstraint`
--

DROP TABLE IF EXISTS `client_test_itemconstraint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_test_itemconstraint` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(255) NOT NULL,
  `propname` varchar(100) NOT NULL,
  `propvalue` varchar(100) NOT NULL,
  `tooltype` varchar(255) NOT NULL,
  `toolvalue` varchar(255) NOT NULL,
  `item_in` bit(1) NOT NULL,
  PRIMARY KEY (`clientname`,`testid`,`propname`,`propvalue`,`item_in`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_test_itemtypes`
--

DROP TABLE IF EXISTS `client_test_itemtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_test_itemtypes` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(255) NOT NULL,
  `itemtype` varchar(25) NOT NULL,
  `origin` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`testid`,`itemtype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testeeattribute`
--

DROP TABLE IF EXISTS `client_testeeattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testeeattribute` (
  `rtsname` varchar(50) NOT NULL,
  `tds_id` varchar(50) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `reportname` varchar(100) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `atlogin` varchar(25) DEFAULT NULL,
  `sortorder` int(11) DEFAULT NULL,
  `islatencysite` bit(1) NOT NULL DEFAULT b'0',
  `showonproctor` bit(1) DEFAULT b'1',
  PRIMARY KEY (`clientname`,`tds_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testeerelationshipattribute`
--

DROP TABLE IF EXISTS `client_testeerelationshipattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testeerelationshipattribute` (
  `clientname` varchar(50) NOT NULL,
  `relationshiptype` varchar(50) NOT NULL,
  `rtsname` varchar(50) NOT NULL,
  `tds_id` varchar(50) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `atlogin` varchar(25) DEFAULT NULL,
  `sortorder` int(11) DEFAULT NULL,
  `reportname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`tds_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testeligibility`
--

DROP TABLE IF EXISTS `client_testeligibility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testeligibility` (
  `_key` varbinary(16) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(150) NOT NULL,
  `rtsname` varchar(100) NOT NULL,
  `enables` bit(1) NOT NULL,
  `disables` bit(1) NOT NULL,
  `rtsvalue` varchar(400) NOT NULL,
  `_efk_entitytype` bigint(20) NOT NULL,
  `eligibilitytype` varchar(50) DEFAULT NULL,
  `matchtype` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`_key`),
  KEY `ix_testeligibility` (`clientname`,`testid`,`enables`,`rtsname`,`rtsvalue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testformproperties`
--

DROP TABLE IF EXISTS `client_testformproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testformproperties` (
  `clientname` varchar(100) NOT NULL,
  `_efk_testform` varchar(50) NOT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `language` varchar(25) NOT NULL,
  `formid` varchar(200) DEFAULT NULL,
  `testid` varchar(150) NOT NULL,
  `testkey` varchar(250) DEFAULT NULL,
  `clientformid` varchar(25) DEFAULT NULL,
  `accommodations` text,
  PRIMARY KEY (`clientname`,`_efk_testform`),
  KEY `ix_form_testkey` (`testkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testgrades`
--

DROP TABLE IF EXISTS `client_testgrades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testgrades` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(150) NOT NULL,
  `grade` varchar(25) NOT NULL,
  `requireenrollment` bit(1) NOT NULL DEFAULT b'0',
  `enrolledsubject` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`testid`,`grade`),
  KEY `ix_testgrade_test` (`testid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testkey`
--

DROP TABLE IF EXISTS `client_testkey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testkey` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(255) NOT NULL,
  `_efk_adminsubject` varchar(250) NOT NULL,
  `isactive` bit(1) NOT NULL,
  `_date` datetime(3) NOT NULL,
  `source` varchar(100) NOT NULL,
  `origin` varchar(100) NOT NULL,
  PRIMARY KEY (`clientname`,`testid`,`_efk_adminsubject`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testmode`
--

DROP TABLE IF EXISTS `client_testmode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testmode` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(200) NOT NULL,
  `mode` varchar(50) NOT NULL DEFAULT 'online',
  `algorithm` varchar(50) DEFAULT NULL,
  `formtideselectable` bit(1) NOT NULL DEFAULT b'0',
  `issegmented` bit(1) NOT NULL DEFAULT b'0',
  `maxopps` int(11) NOT NULL DEFAULT '50',
  `requirertsform` bit(1) NOT NULL DEFAULT b'0',
  `requirertsformwindow` bit(1) NOT NULL DEFAULT b'0',
  `requirertsformifexists` bit(1) NOT NULL DEFAULT b'1',
  `sessiontype` int(11) NOT NULL DEFAULT '-1',
  `testkey` varchar(250) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`),
  UNIQUE KEY `ix_clienttestmode` (`testkey`,`sessiontype`),
  KEY `ix_testmode` (`clientname`,`testid`,`sessiontype`),
  KEY `ix_testmodekey` (`testkey`),
  KEY `ix_testmode_test` (`testid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testprerequisite`
--

DROP TABLE IF EXISTS `client_testprerequisite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testprerequisite` (
  `clientname` varchar(100) NOT NULL,
  `isactive` bit(1) NOT NULL DEFAULT b'1',
  `prereqtestid` varchar(255) NOT NULL,
  `testid` varchar(255) NOT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testproperties`
--

DROP TABLE IF EXISTS `client_testproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testproperties` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(255) NOT NULL,
  `maxopportunities` int(11) DEFAULT NULL,
  `handscoreproject` int(11) DEFAULT NULL,
  `prefetch` int(11) NOT NULL DEFAULT '2',
  `datechanged` datetime(3) DEFAULT NULL,
  `isprintable` bit(1) NOT NULL DEFAULT b'0',
  `isselectable` bit(1) NOT NULL DEFAULT b'1',
  `label` varchar(255) DEFAULT NULL,
  `printitemtypes` varchar(1000) DEFAULT '',
  `scorebytds` bit(1) NOT NULL DEFAULT b'1',
  `batchmodereport` bit(1) NOT NULL DEFAULT b'0',
  `subjectname` varchar(100) DEFAULT NULL,
  `origin` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `maskitemsbysubject` bit(1) NOT NULL DEFAULT b'1',
  `initialabilitybysubject` bit(1) NOT NULL DEFAULT b'1',
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `ftstartdate` datetime(3) DEFAULT NULL,
  `ftenddate` datetime(3) DEFAULT NULL,
  `accommodationfamily` varchar(50) DEFAULT NULL,
  `sortorder` int(11) DEFAULT NULL,
  `rtsformfield` varchar(50) NOT NULL DEFAULT 'tds-testform',
  `rtswindowfield` varchar(50) NOT NULL DEFAULT 'tds-testwindow',
  `windowtideselectable` bit(1) NOT NULL DEFAULT b'0',
  `requirertswindow` bit(1) NOT NULL DEFAULT b'0',
  `reportinginstrument` varchar(50) DEFAULT NULL,
  `tide_id` varchar(100) DEFAULT NULL,
  `forcecomplete` bit(1) NOT NULL DEFAULT b'1',
  `rtsmodefield` varchar(50) NOT NULL DEFAULT 'tds-testmode',
  `modetideselectable` bit(1) NOT NULL DEFAULT b'0',
  `requirertsmode` bit(1) NOT NULL DEFAULT b'0',
  `requirertsmodewindow` bit(1) NOT NULL DEFAULT b'0',
  `deleteunanswereditems` bit(1) NOT NULL DEFAULT b'0',
  `abilityslope` float NOT NULL DEFAULT '1',
  `abilityintercept` float NOT NULL DEFAULT '0',
  `validatecompleteness` bit(1) NOT NULL DEFAULT b'0',
  `gradetext` varchar(50) DEFAULT NULL,
  `initialabilitytestid` varchar(100) DEFAULT NULL,
  `proctoreligibility` int(11) NOT NULL DEFAULT '0',
  `category` varchar(50) DEFAULT NULL,
  `msb` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`clientname`,`testid`),
  KEY `ix_testprops_test` (`testid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testrtsspecs`
--

DROP TABLE IF EXISTS `client_testrtsspecs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testrtsspecs` (
  `_key` varbinary(16) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(150) NOT NULL,
  `rtsfieldname` varchar(50) NOT NULL,
  `enables` bit(1) NOT NULL,
  `disables` bit(1) NOT NULL,
  `attrvalues` text NOT NULL,
  PRIMARY KEY (`_key`),
  KEY `ix_testrtsspecs` (`clientname`,`testid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testscorefeatures`
--

DROP TABLE IF EXISTS `client_testscorefeatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testscorefeatures` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(255) NOT NULL,
  `measureof` varchar(250) NOT NULL,
  `measurelabel` varchar(200) NOT NULL,
  `reporttostudent` bit(1) NOT NULL DEFAULT b'0',
  `reporttoproctor` bit(1) NOT NULL DEFAULT b'0',
  `reporttoparticipation` bit(1) NOT NULL DEFAULT b'0',
  `useforability` bit(1) NOT NULL DEFAULT b'0',
  `reportlabel` text,
  `reportorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`testid`,`measureof`,`measurelabel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testtool`
--

DROP TABLE IF EXISTS `client_testtool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testtool` (
  `clientname` varchar(100) NOT NULL,
  `type` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `isdefault` bit(1) NOT NULL,
  `allowcombine` bit(1) NOT NULL,
  `valuedescription` varchar(255) DEFAULT NULL,
  `context` varchar(255) NOT NULL,
  `sortorder` int(11) NOT NULL DEFAULT '0',
  `origin` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `contexttype` varchar(50) NOT NULL,
  `testmode` varchar(25) NOT NULL DEFAULT 'all',
  `equivalentclientcode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`context`,`contexttype`,`type`,`code`),
  KEY `ix_clienttooltestid` (`context`),
  CONSTRAINT `fk_clienttool_tooltype` FOREIGN KEY (`clientname`, `context`, `contexttype`, `type`) REFERENCES `client_testtooltype` (`clientname`, `context`, `contexttype`, `toolname`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testtoolrule`
--

DROP TABLE IF EXISTS `client_testtoolrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testtoolrule` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(200) NOT NULL,
  `tooltype` varchar(255) NOT NULL,
  `toolcode` varchar(255) NOT NULL,
  `rule` varchar(100) NOT NULL,
  `rulevalue` varchar(255) NOT NULL,
  PRIMARY KEY (`clientname`,`testid`,`toolcode`,`rule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testtooltype`
--

DROP TABLE IF EXISTS `client_testtooltype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testtooltype` (
  `clientname` varchar(100) NOT NULL,
  `toolname` varchar(255) NOT NULL,
  `allowchange` bit(1) NOT NULL DEFAULT b'1',
  `tideselectable` bit(1) DEFAULT NULL,
  `rtsfieldname` varchar(100) DEFAULT NULL,
  `isrequired` bit(1) NOT NULL DEFAULT b'0',
  `tideselectablebysubject` bit(1) NOT NULL DEFAULT b'0',
  `isselectable` bit(1) NOT NULL DEFAULT b'1',
  `isvisible` bit(1) NOT NULL DEFAULT b'1',
  `studentcontrol` bit(1) NOT NULL DEFAULT b'1',
  `tooldescription` varchar(255) DEFAULT NULL,
  `sortorder` int(11) NOT NULL DEFAULT '0',
  `dateentered` datetime(3) NOT NULL,
  `origin` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `contexttype` varchar(50) NOT NULL,
  `context` varchar(255) NOT NULL,
  `dependsontooltype` varchar(50) DEFAULT NULL,
  `disableonguestsession` bit(1) NOT NULL DEFAULT b'0',
  `isfunctional` bit(1) NOT NULL DEFAULT b'1',
  `testmode` varchar(25) NOT NULL DEFAULT 'all',
  `isentrycontrol` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`clientname`,`context`,`contexttype`,`toolname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_testwindow`
--

DROP TABLE IF EXISTS `client_testwindow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_testwindow` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(200) NOT NULL,
  `window` int(11) NOT NULL DEFAULT '1',
  `numopps` int(11) NOT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `origin` varchar(100) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `windowid` varchar(50) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  `sessiontype` int(11) NOT NULL DEFAULT '-1',
  `sortorder` int(11) DEFAULT '1',
  PRIMARY KEY (`_key`),
  KEY `fk_timewindow` (`clientname`,`windowid`),
  KEY `ix_clienttestwindow` (`clientname`,`testid`),
  KEY `ix_testwindow_test` (`testid`),
  CONSTRAINT `fk_timewindow` FOREIGN KEY (`clientname`, `windowid`) REFERENCES `client_timewindow` (`clientname`, `windowid`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_timelimits`
--

DROP TABLE IF EXISTS `client_timelimits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_timelimits` (
  `_key` varbinary(16) NOT NULL,
  `_efk_testid` varchar(255) DEFAULT NULL,
  `oppexpire` int(11) NOT NULL,
  `opprestart` int(11) NOT NULL,
  `oppdelay` int(11) NOT NULL,
  `interfacetimeout` int(11) DEFAULT NULL,
  `clientname` varchar(100) DEFAULT NULL,
  `ispracticetest` bit(1) NOT NULL DEFAULT b'0',
  `refreshvalue` int(11) DEFAULT NULL,
  `tainterfacetimeout` int(11) DEFAULT NULL,
  `tacheckintime` int(11) DEFAULT NULL,
  `datechanged` datetime(3) DEFAULT NULL,
  `datepublished` datetime(3) DEFAULT NULL,
  `environment` varchar(100) DEFAULT NULL,
  `sessionexpire` int(11) NOT NULL DEFAULT '8',
  `requestinterfacetimeout` int(11) NOT NULL DEFAULT '120',
  `refreshvaluemultiplier` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`_key`),
  KEY `ix_clienttimelimits` (`clientname`,`_efk_testid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_timewindow`
--

DROP TABLE IF EXISTS `client_timewindow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_timewindow` (
  `clientname` varchar(100) NOT NULL,
  `windowid` varchar(50) NOT NULL,
  `startdate` datetime(3) DEFAULT NULL,
  `enddate` datetime(3) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`windowid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_tooldependencies`
--

DROP TABLE IF EXISTS `client_tooldependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_tooldependencies` (
  `context` varchar(250) NOT NULL,
  `contexttype` varchar(50) NOT NULL,
  `iftype` varchar(50) NOT NULL,
  `ifvalue` varchar(255) NOT NULL,
  `isdefault` bit(1) NOT NULL DEFAULT b'0',
  `thentype` varchar(50) NOT NULL,
  `thenvalue` varchar(255) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `_key` varbinary(16) NOT NULL,
  `testmode` varchar(25) NOT NULL DEFAULT 'all',
  PRIMARY KEY (`_key`),
  KEY `ix_clienttooldependencies` (`clientname`,`contexttype`,`context`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_toolusage`
--

DROP TABLE IF EXISTS `client_toolusage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_toolusage` (
  `clientname` varchar(100) NOT NULL,
  `testid` varchar(150) NOT NULL,
  `tooltype` varchar(100) NOT NULL,
  `recordusage` bit(1) NOT NULL,
  `reportusage` bit(1) NOT NULL,
  PRIMARY KEY (`clientname`,`testid`,`tooltype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_voicepack`
--

DROP TABLE IF EXISTS `client_voicepack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_voicepack` (
  `os_id` varchar(25) NOT NULL,
  `voicepackname` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL,
  `languagecode` varchar(25) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  PRIMARY KEY (`os_id`,`voicepackname`,`clientname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `geo_clientapplication`
--

DROP TABLE IF EXISTS `geo_clientapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_clientapplication` (
  `clientname` varchar(100) NOT NULL,
  `environment` varchar(100) NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  `appname` varchar(100) NOT NULL,
  `servicetype` varchar(50) NOT NULL,
  `_fk_geo_database` varbinary(16) NOT NULL,
  `_key` varbinary(16) NOT NULL,
  `isactive` bit(1) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  KEY `fk_geoapp_db` (`_fk_geo_database`),
  KEY `ix_geoclientapp` (`clientname`,`environment`,`appname`,`servicetype`),
  CONSTRAINT `fk_geoapp_db` FOREIGN KEY (`_fk_geo_database`) REFERENCES `geo_database` (`_key`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `geo_database`
--

DROP TABLE IF EXISTS `geo_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `geo_database` (
  `servername` varchar(100) NOT NULL,
  `dbname` varchar(100) NOT NULL,
  `brokerguid` varbinary(16) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  `tds_id` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_client_testtool`
--

DROP TABLE IF EXISTS `loader_client_testtool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_client_testtool` (
  `clientname` varchar(100) NOT NULL,
  `type` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `isdefault` bit(1) NOT NULL,
  `allowcombine` bit(1) NOT NULL,
  `valuedescription` varchar(255) DEFAULT NULL,
  `context` varchar(255) NOT NULL,
  `sortorder` int(11) NOT NULL DEFAULT '0',
  `origin` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `contexttype` varchar(50) NOT NULL,
  `testmode` varchar(25) NOT NULL DEFAULT 'all',
  `equivalentclientcode` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_client_testtooltype`
--

DROP TABLE IF EXISTS `loader_client_testtooltype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_client_testtooltype` (
  `clientname` varchar(100) NOT NULL,
  `toolname` varchar(255) NOT NULL,
  `allowchange` bit(1) NOT NULL DEFAULT b'1',
  `tideselectable` bit(1) DEFAULT NULL,
  `rtsfieldname` varchar(100) DEFAULT NULL,
  `isrequired` bit(1) NOT NULL DEFAULT b'0',
  `tideselectablebysubject` bit(1) NOT NULL DEFAULT b'0',
  `isselectable` bit(1) NOT NULL DEFAULT b'1',
  `isvisible` bit(1) NOT NULL DEFAULT b'1',
  `studentcontrol` bit(1) NOT NULL DEFAULT b'1',
  `tooldescription` varchar(255) DEFAULT NULL,
  `sortorder` int(11) NOT NULL DEFAULT '0',
  `dateentered` datetime(3) NOT NULL,
  `origin` varchar(50) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `contexttype` varchar(50) NOT NULL,
  `context` varchar(255) NOT NULL,
  `dependsontooltype` varchar(50) DEFAULT NULL,
  `disableonguestsession` bit(1) NOT NULL DEFAULT b'0',
  `isfunctional` bit(1) NOT NULL DEFAULT b'1',
  `testmode` varchar(25) NOT NULL DEFAULT 'all',
  `isentrycontrol` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loader_client_tooldependencies`
--

DROP TABLE IF EXISTS `loader_client_tooldependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loader_client_tooldependencies` (
  `context` varchar(250) NOT NULL,
  `contexttype` varchar(50) NOT NULL,
  `iftype` varchar(50) NOT NULL,
  `ifvalue` varchar(255) NOT NULL,
  `isdefault` bit(1) NOT NULL DEFAULT b'0',
  `thentype` varchar(50) NOT NULL,
  `thenvalue` varchar(255) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `_key` varbinary(16) NOT NULL,
  `testmode` varchar(25) NOT NULL DEFAULT 'all'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rts_role`
--

DROP TABLE IF EXISTS `rts_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rts_role` (
  `clientname` varchar(100) NOT NULL,
  `rolename` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`clientname`,`rolename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `statuscodes`
--

DROP TABLE IF EXISTS `statuscodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statuscodes` (
  `usage` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `stage` varchar(50) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_applicationsettings`
--

DROP TABLE IF EXISTS `system_applicationsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_applicationsettings` (
  `clientname` varchar(100) NOT NULL,
  `environment` varchar(100) NOT NULL,
  `appname` varchar(100) NOT NULL,
  `property` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `_fk_tds_applicationsettings` varbinary(16) NOT NULL,
  `servername` varchar(256) NOT NULL DEFAULT '*',
  `siteid` varchar(256) NOT NULL DEFAULT '*',
  PRIMARY KEY (`clientname`,`servername`,`siteid`,`_fk_tds_applicationsettings`),
  KEY `tds_applicationsettings_client_applicationsettings` (`_fk_tds_applicationsettings`),
  CONSTRAINT `tds_applicationsettings_client_applicationsettings` FOREIGN KEY (`_fk_tds_applicationsettings`) REFERENCES `tds_applicationsettings` (`_key`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_browserwhitelist`
--

DROP TABLE IF EXISTS `system_browserwhitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_browserwhitelist` (
  `clientname` varchar(100) NOT NULL,
  `appname` varchar(100) NOT NULL,
  `environment` varchar(100) NOT NULL,
  `browsername` varchar(100) NOT NULL,
  `osname` varchar(100) DEFAULT NULL,
  `hw_arch` varchar(100) DEFAULT NULL,
  `browsermaxversion` float DEFAULT NULL,
  `action` varchar(150) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `osmaxversion` float NOT NULL,
  `_fk_tds_browserwhitelist` varbinary(16) NOT NULL,
  `browserminversion` float DEFAULT NULL,
  `osminversion` float NOT NULL,
  `messagekey` varchar(255) DEFAULT NULL,
  `context` varchar(255) NOT NULL DEFAULT '*',
  `contexttype` varchar(50) NOT NULL DEFAULT 'GLOBAL',
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`),
  UNIQUE KEY `unq_sys_browserwhitelist` (`_fk_tds_browserwhitelist`,`clientname`,`context`,`contexttype`,`action`,`priority`,`osmaxversion`,`osminversion`),
  KEY `clus_brwhtlist` (`clientname`,`appname`,`environment`,`context`),
  CONSTRAINT `tds_sys_browserwhitelist` FOREIGN KEY (`_fk_tds_browserwhitelist`) REFERENCES `tds_browserwhitelist` (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_networkdiagnostics`
--

DROP TABLE IF EXISTS `system_networkdiagnostics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_networkdiagnostics` (
  `clientname` varchar(100) NOT NULL,
  `appname` varchar(100) NOT NULL,
  `testlabel` varchar(100) NOT NULL,
  `mindataratereqd` int(11) DEFAULT NULL,
  `aveitemsize` int(11) DEFAULT NULL,
  `responsetime` int(11) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemerrors`
--

DROP TABLE IF EXISTS `systemerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemerrors` (
  `application` varchar(50) DEFAULT 'database',
  `procname` varchar(150) NOT NULL,
  `_efk_testee` bigint(20) DEFAULT NULL,
  `_efk_testid` varchar(150) DEFAULT NULL,
  `opportunity` int(11) DEFAULT NULL,
  `errormessage` text NOT NULL,
  `daterecorded` datetime(3) NOT NULL,
  `serverid` varchar(50) DEFAULT NULL,
  `ipaddress` varchar(50) DEFAULT NULL,
  `applicationcontextid` varbinary(16) DEFAULT NULL,
  `stacktrace` text,
  `_fk_testopportunity` varbinary(16) DEFAULT NULL,
  `clientname` varchar(100) DEFAULT NULL,
  `_fk_session` varbinary(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_application`
--

DROP TABLE IF EXISTS `tds_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_application` (
  `_key` varbinary(16) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_applicationsettings`
--

DROP TABLE IF EXISTS `tds_applicationsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_applicationsettings` (
  `_key` varbinary(16) NOT NULL,
  `environment` varchar(100) NOT NULL,
  `appname` varchar(100) NOT NULL,
  `property` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `isoperational` bit(1) NOT NULL DEFAULT b'1',
  `value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  UNIQUE KEY `un_tds_applicationsettings` (`environment`,`appname`,`property`,`type`,`isoperational`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_browserwhitelist`
--

DROP TABLE IF EXISTS `tds_browserwhitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_browserwhitelist` (
  `_key` varbinary(16) NOT NULL,
  `appname` varchar(100) NOT NULL,
  `environment` varchar(100) NOT NULL,
  `browsername` varchar(100) NOT NULL,
  `osname` varchar(100) DEFAULT NULL,
  `hw_arch` varchar(100) DEFAULT NULL,
  `browserminversion` float DEFAULT NULL,
  `browsermaxversion` float DEFAULT NULL,
  `action` varchar(150) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `osminversion` float DEFAULT NULL,
  `isoperational` bit(1) DEFAULT NULL,
  `osmaxversion` float DEFAULT NULL,
  `messagekey` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  UNIQUE KEY `un_tds_browserwhitelist` (`appname`,`environment`,`browsername`,`osname`,`hw_arch`,`isoperational`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_clientaccommodationtype`
--

DROP TABLE IF EXISTS `tds_clientaccommodationtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_clientaccommodationtype` (
  `toolname` varchar(255) NOT NULL,
  `clientname` varchar(100) NOT NULL,
  `allowchange` bit(1) NOT NULL,
  `tideselectable` bit(1) DEFAULT NULL,
  `rtsfieldname` varchar(100) DEFAULT NULL,
  `isrequired` bit(1) NOT NULL,
  `tideselectablebysubject` bit(1) NOT NULL,
  PRIMARY KEY (`toolname`,`clientname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_clientaccommodationvalue`
--

DROP TABLE IF EXISTS `tds_clientaccommodationvalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_clientaccommodationvalue` (
  `clientname` varchar(100) NOT NULL,
  `type` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `isdefault` bit(1) NOT NULL,
  `valuedescription` varchar(255) DEFAULT NULL,
  `allowcombine` bit(1) NOT NULL,
  `allowadd` bit(1) NOT NULL,
  `sortorder` int(11) NOT NULL,
  PRIMARY KEY (`clientname`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_configtype`
--

DROP TABLE IF EXISTS `tds_configtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_configtype` (
  `configtype` varchar(25) NOT NULL,
  `pagename` varchar(50) NOT NULL,
  `pagedescription` varchar(100) DEFAULT NULL,
  `pagepath` varchar(100) NOT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_coremessageobject`
--

DROP TABLE IF EXISTS `tds_coremessageobject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_coremessageobject` (
  `context` varchar(100) NOT NULL,
  `contexttype` varchar(50) NOT NULL,
  `messageid` int(11) NOT NULL,
  `ownerapp` varchar(100) NOT NULL,
  `appkey` varchar(255) NOT NULL,
  `message` text,
  `paralabels` varchar(255) DEFAULT NULL,
  `_key` bigint(20) NOT NULL AUTO_INCREMENT,
  `fromclient` varchar(100) DEFAULT NULL,
  `datealtered` datetime(3) DEFAULT NULL,
  `nodes` text,
  `ismessageshowtouser` bit(1) DEFAULT NULL,
  PRIMARY KEY (`_key`),
  UNIQUE KEY `ix_uniqueappmsg` (`ownerapp`,`messageid`,`contexttype`,`context`),
  KEY `ix_coremsgcontext` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=4046 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_coremessageuser`
--

DROP TABLE IF EXISTS `tds_coremessageuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_coremessageuser` (
  `_fk_coremessageobject` bigint(20) NOT NULL,
  `systemid` varchar(100) NOT NULL,
  PRIMARY KEY (`_fk_coremessageobject`,`systemid`),
  CONSTRAINT `fk_msguser_msgobj` FOREIGN KEY (`_fk_coremessageobject`) REFERENCES `tds_coremessageobject` (`_key`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_fieldtestpriority`
--

DROP TABLE IF EXISTS `tds_fieldtestpriority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_fieldtestpriority` (
  `tds_id` varchar(50) NOT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY (`tds_id`,`priority`),
  CONSTRAINT `fk_tds_testeeatt` FOREIGN KEY (`tds_id`) REFERENCES `tds_testeeattribute` (`tds_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_role`
--

DROP TABLE IF EXISTS `tds_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_role` (
  `rolename` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_systemflags`
--

DROP TABLE IF EXISTS `tds_systemflags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_systemflags` (
  `auditobject` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `ison` int(11) NOT NULL,
  `ispracticetest` bit(1) NOT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_testeeattribute`
--

DROP TABLE IF EXISTS `tds_testeeattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_testeeattribute` (
  `rtsname` varchar(50) NOT NULL,
  `tds_id` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `atlogin` varchar(25) DEFAULT NULL,
  `sortorder` int(11) DEFAULT NULL,
  `reportname` varchar(50) DEFAULT NULL,
  `islatencysite` bit(1) NOT NULL DEFAULT b'0',
  `showonproctor` bit(1) DEFAULT b'1',
  PRIMARY KEY (`tds_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_testeerelationshipattribute`
--

DROP TABLE IF EXISTS `tds_testeerelationshipattribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_testeerelationshipattribute` (
  `relationshiptype` varchar(50) NOT NULL,
  `rtsname` varchar(50) NOT NULL,
  `tds_id` varchar(50) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `atlogin` varchar(25) DEFAULT NULL,
  `sortorder` int(11) DEFAULT NULL,
  `reportname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`tds_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_testproperties`
--

DROP TABLE IF EXISTS `tds_testproperties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_testproperties` (
  `fieldname` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `isrequired` bit(1) NOT NULL,
  `_key` varbinary(16) NOT NULL,
  PRIMARY KEY (`_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_testtool`
--

DROP TABLE IF EXISTS `tds_testtool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_testtool` (
  `type` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `isdefault` bit(1) NOT NULL,
  `valuedescription` varchar(255) DEFAULT NULL,
  `allowcombine` bit(1) NOT NULL,
  `allowadd` bit(1) NOT NULL,
  `sortorder` int(11) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_testtoolrule`
--

DROP TABLE IF EXISTS `tds_testtoolrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_testtoolrule` (
  `tooltype` varchar(255) NOT NULL,
  `toolcode` varchar(255) NOT NULL,
  `rule` varchar(100) NOT NULL,
  PRIMARY KEY (`tooltype`,`toolcode`,`rule`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tds_testtooltype`
--

DROP TABLE IF EXISTS `tds_testtooltype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tds_testtooltype` (
  `toolname` varchar(255) NOT NULL,
  `allowchange` bit(1) NOT NULL,
  `tideselectable` bit(1) DEFAULT NULL,
  `rtsfieldname` varchar(100) DEFAULT NULL,
  `isrequired` bit(1) NOT NULL,
  `tideselectablebysubject` bit(1) NOT NULL,
  PRIMARY KEY (`toolname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'configs'
--
/*!50003 DROP FUNCTION IF EXISTS `bigtoint` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `bigtoint`(n BIGINT) RETURNS int(11)
    NO SQL
    DETERMINISTIC
RETURN n ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `tds_getmessagekey` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` FUNCTION `tds_getmessagekey`(

	v_client varchar(100)
  , v_application varchar(100)
  , v_contexttype varchar(50)
  , v_context varchar(500)
  , v_appkey varchar(255)
  , v_language varchar(50)
  , v_grade varchar(50)
  , v_subject varchar(50)
) RETURNS varchar(64) CHARSET utf8
    SQL SECURITY INVOKER
begin

    declare v_altmsg varchar(64);
    declare v_msgkey bigint;
    declare v_default varchar(50);
	declare v_inter bit;

    select _fk_coremessageobject
	into v_msgkey
    from tds_coremessageuser, tds_coremessageobject
    where systemid = v_application 
		and `context` = v_context 
		and _fk_coremessageobject = _key 
        and contexttype = v_contexttype 
		and appkey = v_appkey;

    if (v_msgkey is null) then return null; end if;

    if (v_client is null) then set v_client = 'air'; end if;
    if (v_language is null) then set v_language = 'enu'; end if;
    if (v_grade is null) then set v_grade = '--any--'; end if;
    if (v_subject is null) then set v_subject = '--any--'; end if;

	
    select defaultlanguage, internationalize
	into v_default, v_inter
    from `client`
	where `name` = v_client ;

    if (v_inter = 0) then set v_language = v_default; end if;

    select _key
	into v_altmsg
    from client_messagetranslation 
    where _fk_coremessageobject = v_msgkey 
		and (`language` = v_language or `language` = v_default)
        and (`client` = v_client or `client` = 'air')
		and (grade = v_grade or grade = '--any--') and (`subject` = v_subject or `subject` = '--any--');

    if (v_altmsg is not null) then
		return v_altmsg;
	else
		return v_msgkey;
	end if;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `_dm_clearaccomcache` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `_dm_clearaccomcache`(

)
    SQL SECURITY INVOKER
begin

    declare v_client varchar(100);    

	drop temporary table if exists tmp_tblclients;
    create temporary table tmp_tblclients (
		cname varchar(100)
	) engine = memory;


    delete from __accommodationcache;

    insert into tmp_tblclients (cname)
    select distinct clientname from session._externs;


    while (exists (select * from tmp_tblclients)) do
	begin

        select cname into v_client from tmp_tblclients limit 1;
        delete from tmp_tblclients where cname = v_client;

		insert into __accommodationcache (clientname, testkey, _date)
		select '--none--' 
			 , m.testkey, now(3) 
         from client_testwindow w, client_testmode m, client_testproperties p
 	        , session._externs e, itembank.tblsetofadminsubjects bank    
		where 
			p.clientname = v_client and e.clientname = v_client
			and w.clientname = v_client and w.testid = p.testid 
			and now(3) between case when w.startdate is null then now(3) else date_add(w.startdate, interval shiftwindowstart day) end
							  and case when w.enddate is null then now(3) else date_add(w.enddate, interval shiftwindowend day) end
			and m.clientname = v_client and m.testid = p.testid        
			and isselectable = 1
			and bank._key = m.testkey;
			

			
    end;
	end while;

	
	
	drop temporary table if exists tmp_tblclients;
	
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `__slugtestaccoms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`dbsbac`@`%` PROCEDURE `__slugtestaccoms`(

	v_contextkey bigint
)
    SQL SECURITY INVOKER
proc: begin

    declare v_client varchar(100);
	declare v_testkey varchar(250);  
    declare v_segmented bit; 
	declare v_algorithm varchar(50);

    if (v_contextkey is null) then
	begin
        select _key into v_contextkey
		  from __accommodationcache 
		 where dategenerated is null 
		 order by _key
		 limit 1;
        
		if (v_contextkey is null) then leave proc; end if;
    end;
	end if;

	drop temporary table if exists tmp_tblresult;
	create temporary table tmp_tblresult (
		`code` varchar(100)
	  , label  varchar(200)
	) engine = Memory;		
    

    while (v_contextkey is not null) do
	begin

        select clientname, testkey into v_client, v_testkey
		  from __accommodationcache where _key = v_contextkey;
        
		
		select issegmented, selectionalgorithm into v_segmented, v_algorithm
		  from itembank.tblsetofadminsubjects
		 where _key = v_testkey;

		if (v_segmented = 0) then 
		begin
			if (v_algorithm = 'fixedform') then 
			begin
				insert into tmp_tblresult (`code`, label)
				select distinct  propvalue, propdescription
				  from itembank.tblitemprops p, itembank.testform f
				 where p._fk_adminsubject = v_testkey and propname = 'language' and f._fk_adminsubject = v_testkey and f.`language` = p.propvalue
				   and p.isactive = 1;
			end;
			else 
			begin
				insert into tmp_tblresult (`code`, label)
				select distinct  propvalue, propdescription
				  from itembank.tblitemprops p
				 where p._fk_adminsubject = v_testkey and propname = 'language' and isactive = 1;
			end;
			end if;
		end;
		else 
		begin
			insert into tmp_tblresult (`code`, label)
			select distinct propvalue, propdescription
			  from itembank.tblsetofadminitems a, itembank.tblitemprops p, itembank.tblsetofadminsubjects s
			 where s.virtualtest = v_testkey and a._fk_adminsubject = s._key and a._fk_adminsubject = p._fk_adminsubject 
			   and a._fk_item = p._fk_item and propname = 'language' and p.isactive = 1;
		end;
		end if;
	

		insert into __cachedaccommodations(_fk_accommodationcache, segment, disableonguestsession, tooltypesortorder, toolvaluesortorder, typemode, toolmode, acctype, accvalue, acccode, isdefault, allowcombine, isfunctional, allowchange, isselectable, isvisible, studentcontrol, valcount, dependsontooltype) 
		select v_contextkey, segment, disableonguestsession, tooltypesortorder, toolvaluesortorder, typemode, toolmode, acctype, accvalue, acccode, isdefault, allowcombine, isfunctional, allowchange, isselectable, isvisible, studentcontrol, valcount, dependsontooltype
		  from (
			
			select distinct 0 as segment,ttype.disableonguestsession, ttype.sortorder as tooltypesortorder, tt.sortorder as toolvaluesortorder, ttype.testmode
				 as typemode, tt.testmode as toolmode, type as acctype, value as accvalue, code as acccode, isdefault, allowcombine
				, isfunctional, allowchange, isselectable, isvisible, studentcontrol,
				(select count(*) from client_testtool tool 
					where tool.contexttype = 'test' and tool.context = md.testid  and tool.clientname = md.clientname and tool.type = tt.type) as valcount
				, dependsontooltype
				from client_testtooltype ttype, client_testtool tt, client_testmode md
				where md.testkey = v_testkey
					and ttype.contexttype = 'test' and ttype.context = md.testid and ttype.clientname = md.clientname
					and tt.contexttype = 'test' and tt.context = md.testid and tt.clientname = md.clientname and tt.type = ttype.toolname
					and (tt.type <> 'language' or tt.code in (select `code` from tmp_tblresult))
					and (ttype.testmode = 'all' or ttype.testmode = md.mode) and (tt.testmode = 'all' or tt.testmode = md.mode)
			
			union all
			select distinct segmentposition ,ttype.disableonguestsession, ttype.sortorder , tt.sortorder, ttype.testmode , tt.testmode 
				, type , value , code , isdefault, allowcombine, isfunctional, allowchange
				, isselectable, isvisible, studentcontrol,
				(select count(*) from client_testtool tool 
					where tool.contexttype = 'test' and tool.context = md.testid and tool.clientname = md.clientname and tool.type = tt.type) as valcount
				, null  
				from client_testtooltype ttype, client_testtool tt, client_segmentproperties seg, client_testmode md
				where parenttest = md.testid and md.testkey = v_testkey and seg.modekey = v_testkey
					and ttype.contexttype = 'segment' and ttype.context = segmentid and ttype.clientname = md.clientname
					and tt.contexttype = 'segment' and tt.context = segmentid and tt.clientname = md.clientname and tt.type = ttype.toolname
					and (ttype.testmode = 'all' or ttype.testmode = md.mode) and (tt.testmode = 'all' or tt.testmode = md.mode)
			
			union all  
				select distinct 0,ttype.disableonguestsession,  ttype.sortorder , tt.sortorder, ttype.testmode , tt.testmode 
				, type , value , code , isdefault, allowcombine
				, isfunctional, allowchange, isselectable, isvisible, studentcontrol,
				(select count(*) from client_testtool tool 
					where tool.contexttype = 'test' and tool.context = '*' and tool.clientname = md.clientname and tool.type = tt.type) as valcount
				, dependsontooltype
				from  client_testtooltype ttype, client_testtool tt, client_testmode md
				where md.testkey = v_testkey and ttype.contexttype = 'test' and ttype.context = '*' and ttype.clientname = md.clientname
					and tt.contexttype = 'test' and tt.context = '*' and tt.clientname = md.clientname and tt.type = ttype.toolname 
					and (ttype.testmode = 'all' or ttype.testmode = md.mode) and (tt.testmode = 'all' or tt.testmode = md.mode)
					and not exists
							(select * from client_testtooltype tool 
							where tool.contexttype = 'test' and tool.context = md.testid and tool.toolname = ttype.toolname and tool.clientname = md.clientname)    
		) t
		where not exists (select * from __cachedaccommodations where _fk_accommodationcache = v_contextkey);



		insert into __cachedaccomdepends(_fk_accommodationcache, contexttype, `context`, testmode, iftype, ifvalue, thentype, thenvalue, isdefault) 
		select v_contextkey, contexttype, `context`, testmode, iftype, ifvalue, thentype, thenvalue, isdefault
		  from (
			
			select distinct m.clientname, m.testkey, contexttype, m.testid as `context`, testmode, iftype, ifvalue, thentype, thenvalue, isdefault
			  from client_tooldependencies td, client_testmode m
			 where m.testkey = v_testkey and td.contexttype = 'test' and td.context = m.testid and td.clientname = m.clientname 
			union all
			select distinct m.clientname, m.testkey, contexttype, m.testid as context, testmode, iftype, ifvalue, thentype, thenvalue, isdefault
			  from client_tooldependencies td, client_testmode m
			 where m.testkey = v_testkey and td.clientname = m.clientname and contexttype = 'test' and context='*'
			   and (td.testmode = 'all' or td.testmode = m.mode)
			   and not exists (select * from client_tooldependencies td2
								where td2.contexttype = 'test' and td2.context = m.testid and td2.clientname = m.clientname
								  and td.iftype = td2.iftype and td.ifvalue = td2.ifvalue and td.thentype = td2.thentype and td.thenvalue = td2.thenvalue)
		) t
		where not exists (select * from __cachedaccomdepends where _fk_accommodationcache = v_contextkey);


        update __accommodationcache 
		   set dategenerated = now(3) where _key = v_contextkey;

		
		set v_contextkey = null;
		set v_segmented = null; 
		set v_algorithm = null;
		
		delete from tmp_tblresult;

        select _key into v_contextkey 
		  from __accommodationcache where dategenerated is null order by _key limit 1;

    end;  
	end while;


	drop temporary table if exists tmp_tblresult;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-05 14:54:00
